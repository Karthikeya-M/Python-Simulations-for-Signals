import numpy as np
import matplotlib.pyplot as plt
import mpld3
from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('homepage.html')

@app.route('/complex_QAM', methods=['GET', 'POST'])
def complex_QAM():
    plot_html = ""
    error = None

    # Default values
    defaults = {
        "fs": 4096e6,
        "fb1": 64e6,
        "fb2": 64e6,
        "A1": 2,
        "A2": 1,
        "N_fft": 2048,
        "fc": 900e6
    }

    try:
        if request.method == 'POST':
            fs = float(request.form.get("fs", defaults["fs"]))
            fb1 = float(request.form.get("fb1", defaults["fb1"]))
            fb2 = float(request.form.get("fb2", defaults["fb2"]))
            A1 = float(request.form.get("A1", defaults["A1"]))
            A2 = float(request.form.get("A2", defaults["A2"]))
            N_fft = int(request.form.get("N_fft", defaults["N_fft"]))
            fc = float(request.form.get("fc", defaults["fc"]))
        else:
            fs, fb1, fb2, A1, A2, N_fft, fc = defaults.values()

        # Time axis
        t = np.arange(N_fft) / fs

        # Signals
        g_complex = A1 * np.cos(2*np.pi*fb1*t) + 1j*A2*np.cos(2*np.pi*fb2*t)
        g_fft = np.fft.fft(g_complex, N_fft)
        freqs = np.fft.fftfreq(N_fft, 1/fs)

        c_complex = np.exp(1j*2*np.pi*fc*t)
        v = g_complex * c_complex
        y = v.real

        # Demodulation
        demod_carrier = np.exp(-1j*2*np.pi*fc*t)
        x = y * demod_carrier

        # Lowpass filter
        f_cutoff = 0.1
        b = 0.08
        N = int(np.ceil(4/b))
        if N % 2 == 0: N += 1
        n_filter = np.arange(N)
        h = np.sinc(2*f_cutoff*(n_filter-(N-1)/2)) * np.blackman(N)
        h /= np.sum(h)
        z = np.convolve(x, h)
        z_fft = np.fft.fft(z, N_fft)

        figs = []

        # Helper function
        def add_plot(x_data, y_data, title, xlabel='Samples', ylabel='Amplitude', complex_plot=False):
            fig, ax = plt.subplots(figsize=(8,3))
            if complex_plot:
                ax.plot(x_data, y_data.real)
                ax.plot(x_data, y_data.imag)
                ax.legend(['I Component','Q Component'])
            else:
                ax.plot(x_data, y_data)
            ax.set_title(title)
            ax.set_xlabel(xlabel)
            ax.set_ylabel(ylabel)
            fig.tight_layout()
            figs.append(fig)

        # Generate all plots
        add_plot(t[:200], g_complex[:200], 'Time Domain Complex Information Signal', complex_plot=True)
        add_plot(freqs[:N_fft//2]/1e6, np.abs(g_fft[:N_fft//2]), 'One Sided FFT of Complex Information Signal', 'Frequency MHz', 'Magnitude')
        add_plot(freqs/1e6, np.abs(g_fft), 'Two Sided FFT of Complex Information Signal', 'Frequency MHz', 'Magnitude')

        add_plot(t[:100], c_complex[:100], 'Time Domain Complex Carrier', complex_plot=True)
        add_plot(freqs/1e6, np.abs(np.fft.fft(c_complex,N_fft)), 'FFT of Complex Carrier', 'Frequency MHz', 'Magnitude')

        add_plot(t[:200], v[:200], 'Time Domain Complex Modulated Signal', complex_plot=True)
        add_plot(freqs/1e6, np.abs(np.fft.fft(v,N_fft)), 'FFT of Complex Modulated Signal', 'Frequency MHz', 'Magnitude')

        add_plot(t[:200], y[:200], 'Time Domain Real Modulated Signal')
        add_plot(freqs[:N_fft//2]/1e6, np.abs(np.fft.fft(y,N_fft)[:N_fft//2]), 'One Sided FFT of Real Modulated Signal', 'Frequency MHz', 'Magnitude')

        add_plot(t[:200], x[:200], 'Time Domain Complex Demodulated Signal', complex_plot=True)
        add_plot(freqs/1e6, np.abs(np.fft.fft(x,N_fft)), 'FFT of Complex Demodulated Signal', 'Frequency MHz', 'Magnitude')

        add_plot(t[:200], z[:200], 'Lowpass Filtered Complex Demodulated Signal', complex_plot=True)
        add_plot(freqs[:N_fft//2]/1e6, np.abs(z_fft[:N_fft//2]), 'FFT of Lowpass Filtered Signal', 'Frequency MHz', 'Magnitude')

        # Convert figures to HTML
        for f in figs:
            plot_html += mpld3.fig_to_html(f) + "<br><br>"

    except Exception as e:
        error = str(e)

    return render_template('complex_QAM.html', plot_html=plot_html, error=error)

if __name__ == '__main__':
    app.run(debug=True)
