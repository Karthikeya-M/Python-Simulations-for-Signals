import numpy as np
import matplotlib.pyplot as plt
import control as ct
import mpld3
from flask import Flask, render_template, request

app = Flask(__name__)

# Home page
@app.route('/')
def homepage():
    return render_template('homepage.html')

# Vehicle dynamics functions
def vehicle_update(t, x, u, params):
    a = params.get('refoffset', 1.5)
    b = params.get('wheelbase', 3.0)
    maxsteer = params.get('maxsteer', 0.5)
    delta = np.clip(u[1], -maxsteer, maxsteer)
    alpha = np.arctan2(a * np.tan(delta), b)
    return np.array([
        u[0] * np.cos(x[2] + alpha),
        u[0] * np.sin(x[2] + alpha),
        (u[0] / a) * np.sin(alpha)
    ])

def vehicle_output(t, x, u, params):
    return x

@app.route('/control_sys', methods=['GET', 'POST'])
def control_sys():
    plot_html = ""
    error = None

    # Default values
    defaults = {
        "sim_time": 10.0,
        "points": 1000,
        "velocity": 10.0,
        "steer_amp": 0.1,
        "ref_offset": 1.5,
        "wheelbase": 3.0,
        "maxsteer": 0.5
    }

    try:
        if request.method == 'POST':
            sim_time = float(request.form.get("sim_time", defaults["sim_time"]))
            points = int(request.form.get("points", defaults["points"]))
            velocity = float(request.form.get("velocity", defaults["velocity"]))
            steer_amp = float(request.form.get("steer_amp", defaults["steer_amp"]))
            ref_offset = float(request.form.get("ref_offset", defaults["ref_offset"]))
            wheelbase = float(request.form.get("wheelbase", defaults["wheelbase"]))
            maxsteer = float(request.form.get("maxsteer", defaults["maxsteer"]))
        else:
            sim_time, points, velocity, steer_amp, ref_offset, wheelbase, maxsteer = defaults.values()

        # Vehicle system
        vehicle_params = {'refoffset': ref_offset, 'wheelbase': wheelbase, 'velocity': velocity, 'maxsteer': maxsteer}
        vehicle = ct.NonlinearIOSystem(
            vehicle_update, vehicle_output, states=3, name='vehicle',
            inputs=['v','delta'], outputs=['x','y','theta'], params=vehicle_params
        )

        timepts = np.linspace(0, sim_time, points)
        U = [velocity*np.ones_like(timepts), steer_amp*np.sin(timepts*2*np.pi)]

        # Open-loop simulation
        t, outputs = ct.input_output_response(vehicle, timepts, U, 0)
        figs = []

        # 1. Open-loop trajectory
        fig, ax = plt.subplots()
        ax.plot(outputs[0], outputs[1])
        ax.set_xlabel("x [m]")
        ax.set_ylabel("y [m]")
        ax.set_title("Open-loop Vehicle Trajectory")
        fig.tight_layout()
        figs.append(fig)

        # 2. Inputs over time
        fig, ax = plt.subplots()
        ax.plot(timepts, U[0], 'b-', label='Velocity [m/s]')
        ax.set_ylabel('Velocity [m/s]', color='blue')
        ax2 = ax.twinx()
        ax2.plot(timepts, U[1], 'r-', label='Steering [rad]')
        ax2.set_ylabel('Steering angle [rad]', color='red')
        ax.set_xlabel("Time [s]")
        ax.set_title("Open-loop Inputs")
        fig.tight_layout()
        figs.append(fig)

        # LQR design
        Ud = np.array([velocity*np.ones_like(timepts), np.zeros_like(timepts)])
        Xd = np.array([10*timepts, np.zeros_like(timepts), np.zeros_like(timepts)])
        linsys = vehicle.linearize(Xd[:,0], Ud[:,0])
        K, S, E = ct.lqr(linsys, np.diag([1,1,1]), np.diag([1,1]))
        vehicle_control = ct.NonlinearIOSystem(
            None,
            lambda t, x, z, params={'K':K}: z[3:5] - K@(z[5:8]-z[0:3]),
            name='control',
            inputs=['xd','yd','thetad','vd','deltad','x','y','theta'],
            outputs=['v','delta'],
        )
        vehicle_closed = ct.interconnect(
            (vehicle, vehicle_control),
            inputs=['xd','yd','thetad','vd','deltad'],
            outputs=['x','y','theta']
        )

        # Closed-loop desired trajectory
        Xd = np.array([
            10*timepts + 2*(timepts-5)*(timepts>5),
            0.5*np.sin(timepts*2*np.pi),
            np.zeros_like(timepts)
        ])
        resp = ct.input_output_response(vehicle_closed, timepts, np.vstack((Xd, Ud)), 0)
        time, outputs = resp.time, resp.outputs

        # 3. Closed-loop trajectory comparison
        fig, ax = plt.subplots()
        ax.plot(Xd[0], Xd[1], 'b--', label='Desired Trajectory')
        ax.plot(outputs[0], outputs[1], 'r-', label='Actual Trajectory')
        ax.set_xlabel("x [m]"); ax.set_ylabel("y [m]")
        ax.set_title("Closed-loop Vehicle Trajectory")
        ax.legend()
        fig.tight_layout()
        figs.append(fig)

        # 4. Velocity comparison
        fig, ax = plt.subplots()
        ax.plot(np.diff(Xd[0])/np.diff(timepts), 'b--', label='Desired Velocity')
        ax.plot(np.diff(outputs[0])/np.diff(timepts), 'r-', label='Actual Velocity')
        ax.set_xlabel("Time index"); ax.set_ylabel("Velocity [m/s]")
        ax.set_title("Closed-loop Velocity Comparison")
        ax.legend()
        fig.tight_layout()
        figs.append(fig)

        # Convert all figs to HTML
        plot_html = "".join([mpld3.fig_to_html(f) + "<br><br>" for f in figs])

    except Exception as e:
        error = str(e)

    return render_template('control_sys.html', plot_html=plot_html, error=error,
                           defaults=defaults)

if __name__ == '__main__':
    app.run(debug=True)
