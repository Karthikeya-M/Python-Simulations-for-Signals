from flask import Flask, render_template, request
from lcapy import phasor, voltage, noisevoltage
import sympy as sp

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('homepage.html')

@app.route('/index1', methods=['GET','POST'])
def index1():
    results = []
    error = None

    if request.method == 'POST':
        try:
            mode = request.form.get("mode")

            if mode == "phasor":

                # take magnitude & angle entered by user
                mag = float(request.form['mag'])
                angle = float(request.form['angle'])
                P = phasor(mag, angle)

                results.append(f"Input Phasor = {mag}∠{angle}°")
                results.append(f"Time Function: {P.time()}")
                results.append(f"Magnitude: {P.magnitude}")
                results.append(f"Phase (rad): {P.phase}")
                results.append(f"RMS: {P.rms()}")
                results.append(f"Omega: {P.omega}")

            elif mode == "waveform":
                
                # Example waveform: V(t) = A*cos(wt + θ)
                A = float(request.form['A'])
                w = float(request.form['w'])
                phi = float(request.form['phi'])

                t = sp.symbols('t')
                expr = A * sp.cos(w*t + phi)

                P = phasor(A, phi)     # convert to phasor
                V = voltage(P)

                results.append(f"Time Function: {expr}")
                results.append(f"Magnitude: {V.magnitude}")
                results.append(f"Phase: {V.phase}")
                results.append(f"RMS: {V.rms()}")
                results.append(f"Omega: {V.omega}")

            # Noise demonstration
            noise_val = float(request.form.get("noise_val", 1))
            X = noisevoltage(noise_val)
            Y = noisevoltage(3)
            Z = X + Y

            results.append("=== Noise Signals ===")
            results.append(f"X: {X}, ID={X.nid}")
            results.append(f"Y: {Y}, ID={Y.nid}")
            results.append(f"X + Y (independent): {Z}")

        except Exception as e:
            error = str(e)

    return render_template('index1.html', results=results, error=error)


if __name__ == "__main__":
    app.run(debug=True)
