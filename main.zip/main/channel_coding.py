from flask import Flask, render_template, request
import random

app = Flask(__name__)
@app.route('/')
def index():
    return render_template('homepage.html')

# --- Huffman coding (simplified) ---
class Node:
    def __init__(self, char, freq):
        self.char = char
        self.freq = freq
        self.left = None
        self.right = None

def huffman_encode(message):
    freq = {}
    for ch in message:
        freq[ch] = freq.get(ch, 0) + 1
    nodes = [Node(ch, f) for ch, f in freq.items()]
    while len(nodes) > 1:
        nodes = sorted(nodes, key=lambda x: x.freq)
        left, right = nodes[0], nodes[1]
        newNode = Node(None, left.freq + right.freq)
        newNode.left, newNode.right = left, right
        nodes = [newNode] + nodes[2:]
    root = nodes[0]

    codes = {}
    def generate_codes(node, code=""):
        if node is None: return
        if node.char is not None: codes[node.char] = code
        generate_codes(node.left, code+"0")
        generate_codes(node.right, code+"1")
    generate_codes(root)

    encoded = "".join(codes[ch] for ch in message)
    return encoded, codes

def huffman_decode(encoded, codes):
    reverse = {v: k for k, v in codes.items()}
    decoded, buff = "", ""
    for bit in encoded:
        buff += bit
        if buff in reverse:
            decoded += reverse[buff]
            buff = ""
    return decoded

# --- RLE ---
def rle_encode(data):
    encoding = ""
    i = 0
    while i < len(data):
        count = 1
        while i + 1 < len(data) and data[i] == data[i+1]:
            i += 1
            count += 1
        encoding += str(count) + data[i]
        i += 1
    return encoding

def rle_decode(data):
    decoded = ""
    count = ""
    for char in data:
        if char.isdigit():
            count += char
        else:
            decoded += char * int(count)
            count = ""
    return decoded

# --- LZW ---
def lzw_compress(uncompressed):
    dict_size = 256
    dictionary = {chr(i): i for i in range(dict_size)}
    w, result = "", []
    for c in uncompressed:
        wc = w + c
        if wc in dictionary:
            w = wc
        else:
            result.append(dictionary[w])
            dictionary[wc] = dict_size
            dict_size += 1
            w = c
    if w:
        result.append(dictionary[w])
    return result

def lzw_decompress(compressed):
    dict_size = 256
    dictionary = {i: chr(i) for i in range(dict_size)}
    result = [dictionary[compressed[0]]]
    w = result[0]
    for k in compressed[1:]:
        if k in dictionary:
            entry = dictionary[k]
        elif k == dict_size:
            entry = w + w[0]
        else:
            raise ValueError("Bad LZW compressed k: %s" % k)
        result.append(entry)
        dictionary[dict_size] = w + entry[0]
        dict_size += 1
        w = entry
    return "".join(result)

# --- Add noise ---
def add_noise(data, probability=0.1):
    noisy = ""
    for bit in data:
        if random.random() < probability:
            noisy += "1" if bit == "0" else "0"
        else:
            noisy += bit
    return noisy

@app.route("/channel_coding", methods=["GET", "POST"])
def channel_coding():
    result = None
    error = None

    if request.method == "POST":
        algo = request.form.get("algorithm")
        message = request.form.get("message", "")
        apply_noise = request.form.get("apply_noise")

        if not message:
            error = "Message cannot be empty!"
        else:
            try:
                if algo == "huffman":
                    encoded, codes = huffman_encode(message)
                    if apply_noise:
                        noisy = add_noise(encoded)
                        decoded = huffman_decode(noisy, codes)
                        result = f"Huffman Coding\nMessage: {message}\nEncoded: {encoded}\nNoisy: {noisy}\nDecoded: {decoded}"
                    else:
                        decoded = huffman_decode(encoded, codes)
                        result = f"Huffman Coding\nMessage: {message}\nEncoded: {encoded}\nDecoded: {decoded}"

                elif algo == "rle":
                    encoded = rle_encode(message)
                    decoded = rle_decode(encoded)
                    result = f"RLE\nMessage: {message}\nEncoded: {encoded}\nDecoded: {decoded}"

                elif algo == "lzw":
                    encoded = lzw_compress(message)
                    decoded = lzw_decompress(encoded)
                    result = f"LZW\nMessage: {message}\nEncoded: {encoded}\nDecoded: {decoded}"

                else:
                    error = "Unknown algorithm!"
            except Exception as e:
                error = str(e)

    return render_template("channel_coding.html", result=result, error=error)

if __name__ == '__main__':
    app.run(debug=True)
