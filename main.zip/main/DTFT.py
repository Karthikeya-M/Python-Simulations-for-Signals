from flask import Flask, render_template, request
import sympy as sp
from lcapy import Sequence

app = Flask(__name__)

@app.route('/')
def homepage():
    return render_template("homepage.html")

@app.route("/DTFT", methods=["GET", "POST"])
def DTFT():
    result = None
    if request.method == "POST":
        try:
            seq_str = request.form["sequence"].strip()

            # Create symbolic variable for discrete time index
            n = sp.Symbol('n')

            # Detect if symbolic or numeric
            if any(sym in seq_str for sym in ["n", "sign", "cos", "sin", "u", "exp", "sinc", "delta"]):
                # Symbolic input
                s = Sequence(seq_str, var=n)
            else:
                # Numeric sequence input
                terms = [float(x) for x in seq_str.split()]
                s = Sequence(terms)

            # Compute DTFT
            X = s.DTFT()
            X_simplified = X.remove_images()

            result = {
                "input_sequence": seq_str,
                "dtft_full": str(X),
                "dtft_simplified": str(X_simplified)
            }

        except Exception as e:
            result = {"error": str(e)}

    return render_template("DTFT.html", result=result)

if __name__ == "__main__":
    app.run(debug=True)
