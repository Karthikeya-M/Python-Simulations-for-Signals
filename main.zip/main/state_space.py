from flask import Flask, render_template, request
from sympy import sympify, Matrix
import control as ct
import numpy as np
import matplotlib.pyplot as plt
import io, base64
import sys

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('homepage.html')

# ---------- Stability ----------
poles = sys.poles()   # ✅ corrected
if np.all(np.real(poles) < 0):
    stability_msg = "✅ System is **Stable** (all poles in left half plane)"
else:
    stability_msg = "❌ System is **Unstable** (poles in right half plane or on jω-axis)"

# ---------- Controllability ----------
Ctrb = ct.ctrb(sys.A, sys.B)
if np.linalg.matrix_rank(Ctrb) == sys.A.shape[0]:
    ctrl_msg = "✅ System is **Controllable**"
else:
    ctrl_msg = "⚠️ System is **Not Fully Controllable**"

# ---------- Observability ----------
Obsv = ct.obsv(sys.A, sys.C)
if np.linalg.matrix_rank(Obsv) == sys.A.shape[0]:
    obs_msg = "✅ System is **Observable**"
else:
    obs_msg = "⚠️ System is **Not Fully Observable**"

# ---------- Pole-Zero Plot ----------
fig2, ax2 = plt.subplots(figsize=(5, 5))

zeros = sys.zeros()   # ✅ corrected
for p in poles:
    ax2.plot(np.real(p), np.imag(p), 'x', markersize=10)
for z in zeros:
    ax2.plot(np.real(z), np.imag(z), 'o', markersize=8)

ax2.axhline(0); ax2.axvline(0)
ax2.set_title("Pole-Zero Plot")
ax2.set_xlabel("Real")
ax2.set_ylabel("Imag")
ax2.grid()

if __name__ == '__main__':
    app.run(debug=True)
