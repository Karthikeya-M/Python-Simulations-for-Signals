import numpy as np
import matplotlib.pyplot as plt
import mpld3
from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('homepage.html')

@app.route('/pulse_delta_mod_and_demod', methods=['GET', 'POST'])
def delta_mod_and_demod():
    plot_html = ""
    error = None

    # Default parameters
    defaults = {
        "fs": 1000,      # Sampling frequency
        "duration": 0.05, # Duration in seconds
        "fm": 5,         # Message frequency
        "Am": 1,         # Message amplitude
        "delta": 0.1     # Step size
    }

    try:
        # Get inputs from form (or use defaults)
        if request.method == 'POST':
            fs = int(request.form.get("fs", defaults["fs"]))
            duration = float(request.form.get("duration", defaults["duration"]))
            fm = float(request.form.get("fm", defaults["fm"]))
            Am = float(request.form.get("Am", defaults["Am"]))
            delta = float(request.form.get("delta", defaults["delta"]))
        else:
            fs, duration, fm, Am, delta = defaults.values()

        # Time vector
        t = np.arange(0, duration, 1/fs)

        figs = []

        # 1. Message Signal
        message = Am * np.sin(2 * np.pi * fm * t)
        fig, ax = plt.subplots(figsize=(8, 3))
        ax.plot(t, message)
        ax.set_title("Message Signal")
        ax.set_xlabel("Time (s)")
        ax.set_ylabel("Amplitude")
        figs.append(fig)

        # 2. Delta Modulation
        y = np.zeros(len(t))
        eq = np.zeros(len(t))
        for i in range(1, len(t)):
            if message[i] > y[i-1]:
                eq[i] = delta
            else:
                eq[i] = -delta
            y[i] = y[i-1] + eq[i]

        fig, ax = plt.subplots(figsize=(8, 3))
        ax.plot(t, message, label="Message")
        ax.step(t, y, label="Delta Modulated", where='post')
        ax.set_title("Delta Modulated Signal")
        ax.legend()
        figs.append(fig)

        # 3. Demodulated Signal (integrating steps)
        demodulated = np.cumsum(eq)
        fig, ax = plt.subplots(figsize=(8, 3))
        ax.plot(t, message, label="Message")
        ax.plot(t, demodulated, label="Demodulated")
        ax.set_title("Delta Demodulated Signal")
        ax.legend()
        figs.append(fig)

        # Convert all figs to HTML
        for f in figs:
            plot_html += mpld3.fig_to_html(f) + "<br><br>"

    except Exception as e:
        error = str(e)

    return render_template('pulse_delta_mod_and_demod.html',
                           plot_html=plot_html, error=error)

if __name__ == '__main__':
    app.run(debug=True)
