from flask import Flask, render_template, request
import matplotlib.pyplot as plt
import numpy as np
import mpld3

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('homepage.html')


def fourier_transfer(b, a):
    """Generates Fourier Transfer Magnitude and Phase plot as an mpld3 HTML string."""
    # Frequency range (0 to π for normalized digital frequencies)
    w = np.linspace(0, np.pi, 1024)
    jw = np.exp(1j * w)

    # Evaluate transfer function H(e^jw) = B(e^jw) / A(e^jw)
    num = np.polyval(b, jw**-1)   # numerator polynomial
    den = np.polyval(a, jw**-1)   # denominator polynomial
    H = num / den

    magnitude = np.abs(H)
    phase = np.angle(H)

    # Plot
    fig, axs = plt.subplots(2, 1, figsize=(7, 6))

    # Magnitude plot
    axs[0].plot(w, magnitude, 'b')
    axs[0].set_title("Magnitude Response |H(e^jw)|")
    axs[0].set_xlabel("Frequency (rad/sample)")
    axs[0].set_ylabel("Magnitude")
    axs[0].grid(True, linestyle=':', alpha=0.6)

    # Phase plot
    axs[1].plot(w, phase, 'r')
    axs[1].set_title("Phase Response ∠H(e^jw)")
    axs[1].set_xlabel("Frequency (rad/sample)")
    axs[1].set_ylabel("Phase (radians)")
    axs[1].grid(True, linestyle=':', alpha=0.6)

    plt.tight_layout()

    # Convert to mpld3 HTML
    plot_html = mpld3.fig_to_html(fig)
    plt.close(fig)
    return plot_html


@app.route('/fourier_transform_graph', methods=['GET', 'POST'])
def fourier_transfer_route():
    plot_html = None
    if request.method == 'POST':
        # Get coefficients from user
        numerator = request.form['numerator']
        denominator = request.form['denominator']

        # Convert input into list of floats
        b = [float(x) for x in numerator.replace(',', ' ').split()]
        a = [float(x) for x in denominator.replace(',', ' ').split()]

        plot_html = fourier_transfer(b, a)

    return render_template("fourier_transform_graph.html", plot_html=plot_html)


if __name__ == "__main__":
    app.run(debug=True)
