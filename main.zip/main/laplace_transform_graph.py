from flask import Flask, render_template, request
import sympy as sp
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import mpld3

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('homepage.html')


def laplace_surface(expr_str):
    t, s = sp.symbols('t s', real=True)

    # Parse user input
    try:
        f = sp.sympify(expr_str)
    except Exception as e:
        return None, f"Invalid expression: {e}", None

    # Laplace Transform
    try:
        F = sp.laplace_transform(f, t, s, noconds=True)
        F = sp.simplify(F)
    except Exception as e:
        return None, f"Laplace computation failed: {e}", None

    # Convert to function
    F_func = sp.lambdify(s, F, "numpy")

    # Define complex s = σ + jω grid
    sigma = np.linspace(-5, 5, 200)
    omega = np.linspace(-20, 20, 200)
    Sigma, Omega = np.meshgrid(sigma, omega)
    S = Sigma + 1j * Omega

    # Evaluate |F(s)| on grid
    try:
        Z = np.abs(F_func(S))
        Z = np.nan_to_num(Z, nan=0.0, posinf=10**6, neginf=10**6)
    except Exception:
        return None, "Error evaluating function on grid (maybe non-rational Laplace?)", None

    # Plot 3D surface
    fig = plt.figure(figsize=(8, 6))
    ax = fig.add_subplot(111, projection='3d')

    surf = ax.plot_surface(Sigma, Omega, Z, rstride=5, cstride=5, linewidth=0, antialiased=True)

    ax.set_title("|F(s)| Surface in s-plane")
    ax.set_xlabel("σ (Real axis)")
    ax.set_ylabel("ω (Imag axis)")
    ax.set_zlabel("|F(s)|")
    ax.view_init(elev=30, azim=230)

    plot_html = mpld3.fig_to_html(fig)
    plt.close(fig)

    return sp.latex(F), None, plot_html


@app.route('/laplace_transform_graph', methods=['GET', 'POST'])
def laplace_3d():
    result = None
    error = None
    plot_html = None

    if request.method == 'POST':
        expr_str = request.form['expr']
        result, error, plot_html = laplace_surface(expr_str)

    return render_template("laplace_transform_graph.html",
                           result=result,
                           error=error,
                           plot_html=plot_html)


if __name__ == "__main__":
    app.run(debug=True)
