import numpy as np
import matplotlib.pyplot as plt
import mpld3
from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('homepage.html')

@app.route('/pulse_width_mod_and_demod', methods=['GET', 'POST'])
def pwm_mod_and_demod():
    plot_html = ""
    error = None

    # Default parameters
    defaults = {
        "fs": 5000,       # Sampling frequency (Hz)
        "f_pwm": 50,      # PWM carrier frequency (Hz)
        "duration": 0.05, # Signal duration (s)
        "seed": 0         # Random seed for reproducibility
    }

    try:
        # Get inputs from form (or defaults)
        if request.method == 'POST':
            fs = int(request.form.get("fs", defaults["fs"]))
            f_pwm = float(request.form.get("f_pwm", defaults["f_pwm"]))
            duration = float(request.form.get("duration", defaults["duration"]))
            seed = int(request.form.get("seed", defaults["seed"]))
        else:
            fs, f_pwm, duration, seed = defaults.values()

        # Time vector
        t = np.linspace(0, duration, int(fs * duration), endpoint=False)

        # Random waveform
        np.random.seed(seed)
        random_wave = np.random.rand(len(t))  
        random_wave = np.convolve(random_wave, np.ones(50)/50, mode='same')  # smooth

        # Sawtooth carrier for PWM
        carrier = (t * f_pwm) % 1  

        # PWM output
        pwm_output = (random_wave > carrier).astype(float)

        figs = []

        # Plot 1: Random waveform + Carrier
        fig, ax = plt.subplots(figsize=(8, 3))
        ax.plot(t, random_wave, label='Random Waveform')
        ax.plot(t, carrier, label='Carrier (Sawtooth)', alpha=0.7)
        ax.set_title("Random Waveform vs Carrier")
        ax.legend()
        ax.grid(True)
        figs.append(fig)

        # Plot 2: PWM output
        fig, ax = plt.subplots(figsize=(8, 3))
        ax.plot(t, pwm_output, drawstyle='steps-pre', label='PWM Output')
        ax.set_title("PWM Signal")
        ax.legend()
        ax.grid(True)
        figs.append(fig)

        # Plot 3: Overlay
        fig, ax = plt.subplots(figsize=(8, 3))
        ax.plot(t, random_wave, label='Random Waveform')
        ax.plot(t, pwm_output, drawstyle='steps-pre', label='PWM Output')
        ax.set_title("Overlay of Input and PWM")
        ax.legend()
        ax.grid(True)
        figs.append(fig)

        # Convert plots to HTML
        for f in figs:
            plot_html += mpld3.fig_to_html(f) + "<br><br>"

    except Exception as e:
        error = str(e)

    return render_template("pulse_width_mod_and_demod.html", plot_html=plot_html, error=error)

if __name__ == '__main__':
    app.run(debug=True)
