app = Flask(__name__)

@app.route('/')
def homepage():
    return render_template("homepage.html")  # points to homepage

@app.route("/emft", methods=["GET", "POST"])
def emft():
    result = ""
    if request.method == "POST":
        try:
            # Get expressions as strings and convert to SymPy
            Fx = sp.sympify(request.form.get("Fx"))
            Fy = sp.sympify(request.form.get("Fy"))
            Fz = sp.sympify(request.form.get("Fz"))

            # Parse point input
            pt_in = [float(val) for val in request.form.get("point").split(",")]

            # Define symbols
            x, y, z, i, j, k = sp.symbols('x y z i j k')

            # Divergence
            divF = sp.diff(Fx, x) + sp.diff(Fy, y) + sp.diff(Fz, z)

            # Curl components
            c1 = sp.diff(Fz, y) - sp.diff(Fy, z)
            c2 = sp.diff(Fx, z) - sp.diff(Fz, x)
            c3 = sp.diff(Fy, x) - sp.diff(Fx, y)

            curlF = (c1, c2, c3)

            # Build result string
            result += f"<pre>Divergence: {divF}</pre>"
            result += f"<pre>Curl: {curlF}</pre>"

            # Substitute values at given point
            subs_dict = {x: pt_in[0], y: pt_in[1], z: pt_in[2]}
            c11 = c1.subs(subs_dict)
            c12 = c2.subs(subs_dict)
            c13 = c3.subs(subs_dict)
            divfinal = divF.subs(subs_dict)

            c_final = c11*i + c12*j + c13*k

            result += f"<pre>Divergence at point: {divfinal}</pre>"
            result += f"<pre>Curl at point: {c_final}</pre>"

        except Exception as e:
            result = f"<p style='color:red'>Error: {e}</p>"

    return render_template("emft.html", result=result)

app = Flask(__name__)

@app.route('/')
def homepage():
    return render_template("homepage.html")

@app.route("/fresnel", methods=["GET", "POST"])
def fresnel():
    result = ""
    plot_html = ""
    try:
        if request.method == "POST":
            # Get user input
            eps1 = float(sp.sympify(request.form.get("eps1")))
            mu1  = float(sp.sympify(request.form.get("mu1")))
            eps2 = float(sp.sympify(request.form.get("eps2")))
            mu2  = float(sp.sympify(request.form.get("mu2")))
            E0   = float(sp.sympify(request.form.get("E0")))

            # Compute intrinsic impedances
            eta1 = np.sqrt(mu1/eps1)
            eta2 = np.sqrt(mu2/eps2)

            # Reflection & transmission coefficients
            Gamma = (eta2 - eta1)/(eta2 + eta1)
            T = (2*eta2)/(eta2 + eta1)

            result += f"<pre>Reflection Coefficient (Γ): {Gamma:.4f}</pre>"
            result += f"<pre>Transmission Coefficient (T): {T:.4f}</pre>"

            # Time axis
            t = np.linspace(0, 20, 500)
            omega = 1.0  # normalized frequency

            # Waveforms
            Ei = E0 * np.cos(omega*t)           # incident
            Er = Gamma * E0 * np.cos(omega*t)   # reflected
            Et = T * E0 * np.cos(omega*t)       # transmitted

            # Plotting with Matplotlib
            fig, ax = plt.subplots(figsize=(7,4))
            ax.plot(t, Ei, label="Incident")
            ax.plot(t, Er, label="Reflected")
            ax.plot(t, Et, label="Transmitted")
            ax.set_xlabel("Time (normalized)")
            ax.set_ylabel("Amplitude")
            ax.set_title("Waveforms at Dielectric Boundary")
            ax.legend()

            # Convert figure to HTML
            plot_html = mpld3.fig_to_html(fig)
            plt.close(fig)

    except Exception as e:
        result = f"<p style='color:red'>Error: {e}</p>"

    return render_template("fresnel.html", result=result, plot_html=plot_html)




from flask import Flask, render_template, request
import numpy as np
import matplotlib.pyplot as plt
import sympy as sp
import mpld3
import skrf as rf

app = Flask(__name__)

@app.route('/')
def homepage():
    return render_template("homepage.html")  

@app.route("/smith", methods=["GET", "POST"])
def smith():
    result = ""
    plot_html = ""
    try:
        if request.method == "POST":
            # --- Get user inputs ---
            Z0 = float(sp.sympify(request.form.get("Z0")))     # Characteristic impedance
            RL = float(sp.sympify(request.form.get("RL")))     # Load resistance
            XL = float(sp.sympify(request.form.get("XL")))     # Load reactance

            # --- Build load impedance ---
            ZL = RL + 1j * XL

            # --- Reflection coefficient ---
            Gamma = (ZL - Z0) / (ZL + Z0)

            # --- Metrics ---
            mag_Gamma = abs(Gamma)
            phase_Gamma = np.angle(Gamma, deg=True)
            VSWR = (1 + mag_Gamma) / (1 - mag_Gamma) if mag_Gamma < 1 else np.inf
            ReturnLoss = -20 * np.log10(mag_Gamma) if mag_Gamma != 0 else np.inf
            Z_norm = ZL / Z0

            # --- Build result string ---
            result += f"<pre>Load Impedance ZL = {ZL:.3f} Ω</pre>"
            result += f"<pre>Reflection Coefficient Γ = {Gamma:.3f}</pre>"
            result += f"<pre>|Γ| = {mag_Gamma:.3f}, ∠Γ = {phase_Gamma:.2f}°</pre>"
            result += f"<pre>VSWR = {VSWR:.3f}</pre>"
            result += f"<pre>Return Loss = {ReturnLoss:.2f} dB</pre>"
            result += f"<pre>Normalized Impedance z = {Z_norm:.3f}</pre>"

            # --- Smith chart plot ---
# --- Smith chart plot ---
        fig, ax = plt.subplots(figsize=(8, 8))

        # Draw the Smith chart background
        rf.plotting.smith(ax=ax, chart_type='z', draw_labels=True)  # grid only

        # Plot the reflection coefficient point
        ax.plot(np.real(Gamma), np.imag(Gamma),
                marker='o', linestyle='None', label=f"Load Γ = {Gamma:.3f}")

        # Ensure full circle is visible
        ax.set_xlim(-1.05, 1.05)
        ax.set_ylim(-1.05, 1.05)
        ax.set_aspect('equal', adjustable='box')

        ax.set_title("Smith Chart")
        ax.legend()
        plot_html = mpld3.fig_to_html(fig)
        plt.close(fig)


    except Exception as e:
        result = f"<p style='color:red'>Error: {e}</p>"

    return render_template("smith.html", result=result, plot_html=plot_html)



from flask import Flask, render_template, request
import numpy as np
import matplotlib.pyplot as plt
import mpld3

app = Flask(__name__)

@app.route('/')
def homepage():
    return render_template("homepage.html")

@app.route("/waveguide", methods=["GET", "POST"])
def waveguide():
    result = ""
    plot_html = ""

    try:
        if request.method == "POST":
            # --- Get user inputs ---
            a = float(request.form.get("a"))  # width (m)
            b = float(request.form.get("b"))  # height (m)
            m = int(request.form.get("m"))    # mode index m
            n = int(request.form.get("n"))    # mode index n

            c = 3e8  # speed of light (m/s)

            # --- Compute cutoff frequency ---
            fc = (c / 2) * np.sqrt((m / a) ** 2 + (n / b) ** 2)

            # --- Mesh grid for field distribution ---
            x = np.linspace(0, a, 200)
            y = np.linspace(0, b, 200)
            X, Y = np.meshgrid(x, y)

            # --- Field distribution (normalized TM_mn mode) ---
            Ez = np.sin(m * np.pi * X / a) * np.sin(n * np.pi * Y / b)

            fig, ax = plt.subplots(figsize=(6, 5))
            cplot = ax.imshow(Ez, extent=[0, a, 0, b], origin="lower",
                              cmap="viridis", aspect="auto")
            fig.colorbar(cplot, ax=ax)
            ax.set_title(f"Rectangular Waveguide Mode TM({m},{n})")
            ax.set_xlabel("x (m)")
            ax.set_ylabel("y (m)")

            plot_html = mpld3.fig_to_html(fig)
            plt.close(fig)

            # --- Display cutoff frequency ---
            result += f"<pre>Cutoff Frequency: {fc/1e9:.3f} GHz</pre>"

    except Exception as e:
        result = f"<p style='color:red'>Error: {e}</p>"

    return render_template("waveguide.html", result=result, plot_html=plot_html)


from flask import Flask, render_template, request
import numpy as np
import matplotlib.pyplot as plt
import mpld3

app = Flask(__name__)

@app.route('/')
def homepage():
    return render_template("homepage.html")

@app.route("/bounce", methods=["GET", "POST"])
def bounce():
    result = ""
    plot_html = ""

    try:
        if request.method == "POST":
            # --- User inputs ---
            Z0 = float(request.form.get("Z0"))   # Line impedance (Ω)
            ZL = float(request.form.get("ZL"))   # Load impedance (Ω)
            Zs = float(request.form.get("Zs"))   # Source impedance (Ω)
            Vstep = float(request.form.get("Vstep"))  # Step voltage (V)
            td = float(request.form.get("td"))   # one-way delay (ns)
            n_reflections = int(request.form.get("n_reflections"))  # number of reflections
            observe = request.form.get("observe")  # "load" or "source"

            # --- Reflection coefficients ---
            Gamma_L = (ZL - Z0) / (ZL + Z0)   # at load
            Gamma_S = (Zs - Z0) / (Zs + Z0)   # at source

            # --- Initial forward voltage ---
            V0_plus = Vstep * Z0 / (Zs + Z0)

            times = [0]
            voltages = [V0_plus if observe == "load" else Vstep - V0_plus]

            V_current = V0_plus
            t = 0

            for k in range(1, n_reflections+1):
                if k % 2 == 1:  # odd bounce -> load reflection
                    V_current *= Gamma_L
                else:           # even bounce -> source reflection
                    V_current *= Gamma_S

                t += td
                times.append(t)

                if observe == "load":
                    voltages.append(voltages[-1] + V_current)
                else:  # at source
                    voltages.append(voltages[-1] + V_current)

            # --- Plot ---
            fig, ax = plt.subplots(figsize=(7,4))
            ax.step(times, voltages, where="post")
            ax.set_xlabel("Time (ns)")
            ax.set_ylabel("Voltage (V)")
            ax.set_title(f"Voltage Bounce Diagram ({observe.capitalize()} End)")
            ax.grid(True)

            plot_html = mpld3.fig_to_html(fig)
            plt.close(fig)

            result += f"<pre>ΓL (Load Reflection Coefficient): {Gamma_L:.3f}</pre>"
            result += f"<pre>ΓS (Source Reflection Coefficient): {Gamma_S:.3f}</pre>"
            result += f"<pre>Number of simulated bounces: {n_reflections}</pre>"

    except Exception as e:
        result = f"<p style='color:red'>Error: {e}</p>"

    return render_template("bounce.html", result=result, plot_html=plot_html)

if __name__ == '__main__':
    app.run(debug=True)
