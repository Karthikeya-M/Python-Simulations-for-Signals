import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import hilbert
import mpld3
from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('homepage.html')

@app.route('/frequency_mod_and_demod', methods=['GET', 'POST'])
def frequency_mod_and_demod():
    plot_html = ""
    error = None

    defaults = {
        "fs": 10000,
        "duration": 0.01,
        "fc": 500,
        "kf": 100,
        "fm": 50,
        "Am": 1
    }

    try:
        if request.method == 'POST':
            fs = int(request.form.get("fs", defaults["fs"]))
            duration = float(request.form.get("duration", defaults["duration"]))
            fc = float(request.form.get("fc", defaults["fc"]))
            kf = float(request.form.get("kf", defaults["kf"]))
            fm = float(request.form.get("fm", defaults["fm"]))
            Am = float(request.form.get("Am", defaults["Am"]))
        else:
            fs, duration, fc, kf, fm, Am = defaults.values()

        t = np.arange(0, duration, 1/fs)

        figs = []

        # Message signal
        message = Am * np.sin(2 * np.pi * fm * t)
        fig, ax = plt.subplots(figsize=(8,3))
        ax.plot(t[:500], message[:500])
        ax.set_title("Message Signal (time domain)")
        ax.set_xlabel("Time (s)")
        ax.set_ylabel("Amplitude")
        fig.tight_layout()
        figs.append(fig)

        # FM Modulated signal
        integrated_message = np.cumsum(message) / fs
        fm_signal = np.cos(2 * np.pi * fc * t + 2 * np.pi * kf * integrated_message)
        fig, ax = plt.subplots(figsize=(8,3))
        ax.plot(t[:500], fm_signal[:500])
        ax.set_title("FM Modulated Signal (time domain)")
        ax.set_xlabel("Time (s)")
        ax.set_ylabel("Amplitude")
        fig.tight_layout()
        figs.append(fig)

        # FM Demodulated signal
        analytic_signal = hilbert(fm_signal)
        inst_phase = np.unwrap(np.angle(analytic_signal))
        demod = np.diff(inst_phase) * fs / (2*np.pi*kf)
        demod = np.append(demod, demod[-1])
        fig, ax = plt.subplots(figsize=(8,3))
        ax.plot(t[:500], demod[:500])
        ax.set_title("FM Demodulated Signal (time domain)")
        ax.set_xlabel("Time (s)")
        ax.set_ylabel("Amplitude")
        fig.tight_layout()
        figs.append(fig)

        for f in figs:
            plot_html += mpld3.fig_to_html(f) + "<br><br>"

    except Exception as e:
        error = str(e)

    return render_template('frequency_mod_and_demod.html',
                           plot_html=plot_html, error=error)

if __name__ == "__main__":
    app.run(debug=True)
