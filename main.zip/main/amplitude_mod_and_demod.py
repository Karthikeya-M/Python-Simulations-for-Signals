import numpy as np
import matplotlib.pyplot as plt
import mpld3
from flask import Flask, render_template, request

app = Flask(__name__)  # Since your HTML is in "main/"

@app.route('/')
def index():
    return render_template('homepage.html')

@app.route('/amplitude_mod_and_demod', methods=['GET', 'POST'])
def amplitude_mod_and_demod():
    plot_html = ""
    error = None

    # Default values
    defaults = {
        "fs": 4096e6,
        "fb": 64e6,
        "A": 2,
        "N_fft": 2048,
        "fc": 900e6
    }

    try:
        if request.method == 'POST':
            fs = float(request.form.get("fs", defaults["fs"]))
            fb = float(request.form.get("fb", defaults["fb"]))
            A = float(request.form.get("A", defaults["A"]))
            N_fft = int(request.form.get("N_fft", defaults["N_fft"]))
            fc = float(request.form.get("fc", defaults["fc"]))
        else:
            fs, fb, A, N_fft, fc = defaults.values()

        # Time axis
        t = np.arange(N_fft) / fs
        freqs = np.fft.fftfreq(N_fft, 1/fs)

        figs = []  # store all matplotlib figures

        # 1. Baseband signal
        g = A * np.cos(2*np.pi*fb*t)
        g_fft_result = np.fft.fft(g, N_fft)
        fig, axs = plt.subplots(1, 2, figsize=(8, 3))
        axs[0].plot(g[:200])
        axs[0].set_title('Time Domain Baseband Signal')
        axs[0].set_xlabel('Samples')
        axs[0].set_ylabel('Amplitude')
        axs[1].plot(freqs[:N_fft//2]/1e6, np.abs(g_fft_result[:N_fft//2]))
        axs[1].set_title('One Sided FFT of Baseband Signal')
        axs[1].set_xlabel('Frequency (MHz)')
        axs[1].set_ylabel('Magnitude')
        fig.tight_layout()
        figs.append(fig)

        # 2. Carrier signal
        c = np.cos(2*np.pi*fc*t)
        c_fft_result = np.fft.fft(c, N_fft)
        fig, axs = plt.subplots(1, 2, figsize=(8, 3))
        axs[0].plot(c[:100])
        axs[0].set_title('Time Domain Carrier Signal')
        axs[0].set_xlabel('Samples')
        axs[0].set_ylabel('Amplitude')
        axs[1].plot(freqs[:N_fft//2]/1e6, np.abs(c_fft_result[:N_fft//2]))
        axs[1].set_title('One Sided FFT of Carrier Signal')
        axs[1].set_xlabel('Frequency (MHz)')
        axs[1].set_ylabel('Magnitude')
        fig.tight_layout()
        figs.append(fig)

        # 3. Modulated signal
        s = g * c
        s_fft_result = np.fft.fft(s, N_fft)
        fig, axs = plt.subplots(1, 2, figsize=(8, 3))
        axs[0].plot(s[:200])
        axs[0].set_title('Time Domain Modulated Signal')
        axs[0].set_xlabel('Samples')
        axs[0].set_ylabel('Amplitude')
        axs[1].plot(freqs[:N_fft//2]/1e6, np.abs(s_fft_result[:N_fft//2]))
        axs[1].set_title('One Sided FFT of Modulated Signal')
        axs[1].set_xlabel('Frequency (MHz)')
        axs[1].set_ylabel('Magnitude')
        fig.tight_layout()
        figs.append(fig)

        # 4. Demodulated signal (unfiltered)
        x = c * s
        x_fft_result = np.fft.fft(x, N_fft)
        fig, axs = plt.subplots(1, 2, figsize=(8, 3))
        axs[0].plot(x[:200])
        axs[0].set_title('Time Domain Unfiltered Demodulated Signal')
        axs[0].set_xlabel('Samples')
        axs[0].set_ylabel('Amplitude')
        axs[1].plot(freqs[:N_fft//2]/1e6, np.abs(x_fft_result[:N_fft//2]))
        axs[1].set_title('One Sided FFT of Unfiltered Demodulated Signal')
        axs[1].set_xlabel('Frequency (MHz)')
        axs[1].set_ylabel('Magnitude')
        fig.tight_layout()
        figs.append(fig)

        # 5. Low-pass filtered demodulated signal
        f_cutoff = 0.1  # Fraction of fs
        b = 0.08
        N = int(np.ceil((4 / b)))
        if not N % 2:
            N += 1
        n = np.arange(N)
        h = np.sinc(2 * f_cutoff * (n - (N - 1) / 2))
        w = np.blackman(N)
        h *= w
        h /= np.sum(h)
        u = np.convolve(x, h)
        u_fft_result = np.fft.fft(u, N_fft)
        fig, axs = plt.subplots(1, 2, figsize=(8, 3))
        axs[0].plot(u[:200])
        axs[0].set_title('Time Domain Lowpass Filtered Demodulated Signal')
        axs[0].set_xlabel('Samples')
        axs[0].set_ylabel('Amplitude')
        axs[1].plot(freqs[:N_fft//2]/1e6, np.abs(u_fft_result[:N_fft//2]))
        axs[1].set_title('One Sided FFT of Lowpass Filtered Demodulated Signal')
        axs[1].set_xlabel('Frequency (MHz)')
        axs[1].set_ylabel('Magnitude')
        fig.tight_layout()
        figs.append(fig)

        # Convert all figs to HTML and concatenate
        for f in figs:
            plot_html += mpld3.fig_to_html(f) + "<br><br>"

    except Exception as e:
        error = str(e)

    return render_template('amplitude_mod_and_demod.html',
                           plot_html=plot_html, error=error)

if __name__ == '__main__':
    app.run(debug=True)
