import numpy as np
import matplotlib.pyplot as plt
import traceback
import matplotlib
import mpld3
from flask import Flask, render_template, request, send_file, redirect, url_for, flash, jsonify
from scipy.signal import hilbert
import random
from scipy import signal, ndimage
import control as ct
import sympy as sp
import io, base64
from lcapy import LTIFilter
from lcapy.ltifilter import Butterworth, Bessel
import cv2
import os
from io import BytesIO
from lcapy import phasor, symbol, voltage, noisevoltage
from lcapy import StateSpace
from sympy import sympify, Matrix, simplify
import control as ct
from lcapy import texpr, s
import matplotlib.patches as patches
import skrf as rf
import math
from lcapy import symbol, nexpr, cos, sin, exp, j, sinc, rect, sincu, delta, sign, H, pi, n, f, k, dt
import html
import requests


app = Flask(__name__)  # Since your HTML is in "main/"

@app.route('/')
def index():
    return render_template('homepage.html')

@app.route('/pulse_code_mod_and_demod', methods=['GET', 'POST'])
def pcm():
    result_text = ""
    error = None

    if request.method == 'POST':
        try:
            # Read form inputs (matching HTML form)
            fs = float(request.form.get('sampling_frequency', 100))   # Sampling frequency
            fb = float(request.form.get('message_frequency', 25))     # Message frequency
            A = float(request.form.get('amplitude', 1))               # Amplitude
            bits_per_sample = int(request.form.get('bits', 3))        # Bits per sample
            duration = float(request.form.get('duration', 2))         # Duration in seconds

            # Time vector
            t = np.arange(0, duration, 1/fs)
            
            # Message signal
            message = A * np.sin(2 * np.pi * fb * t)

            # Quantization
            q_levels = 2 ** bits_per_sample
            q_min = np.min(message)
            q_max = np.max(message)
            q_step = (q_max - q_min) / (q_levels - 1)
            quantized = np.round((message - q_min) / q_step) * q_step + q_min

            # Encoding
            bit_stream = []
            for q_val in quantized:
                idx = int((q_val - q_min) / q_step)
                bit_stream.append(format(idx, f'0{bits_per_sample}b'))

            # Decoding
            decoded = []
            for bits in bit_stream:
                idx = int(bits, 2)
                decoded.append(idx * q_step + q_min)
            decoded = np.array(decoded)

            # Prepare text output
            result_text = (
                f"Sampling Frequency: {fs} Hz\n"
                f"Message Frequency: {fb} Hz\n"
                f"Amplitude: {A}\n"
                f"Quantization Levels: {q_levels}\n"
                f"Bits per sample: {bits_per_sample}\n\n"
                f"First 20 Quantized Samples: {quantized[:20]}\n\n"
                f"First 20 Encoded Bits: {bit_stream[:20]}\n\n"
                f"First 20 Decoded Samples: {decoded[:20]}\n"
            )

        except Exception as e:
            error = str(e)

    return render_template('pulse_code_mod_and_demod.html',
                           result_text=result_text, error=error)

@app.route('/amplitude_mod_and_demod', methods=['GET', 'POST'])
def amplitude_mod_and_demod():
    plot_html = ""
    error = None

    # Default values
    defaults = {
        "fs": 4096e6,
        "fb": 64e6,
        "A": 2,
        "N_fft": 2048,
        "fc": 900e6
    }

    try:
        if request.method == 'POST':
            fs = float(request.form.get("fs", defaults["fs"]))
            fb = float(request.form.get("fb", defaults["fb"]))
            A = float(request.form.get("A", defaults["A"]))
            N_fft = int(request.form.get("N_fft", defaults["N_fft"]))
            fc = float(request.form.get("fc", defaults["fc"]))
        else:
            fs, fb, A, N_fft, fc = defaults.values()

        # Time axis
        t = np.arange(N_fft) / fs
        freqs = np.fft.fftfreq(N_fft, 1/fs)

        figs = []  # store all matplotlib figures

        # 1. Baseband signal
        g = A * np.cos(2*np.pi*fb*t)
        g_fft_result = np.fft.fft(g, N_fft)
        fig, axs = plt.subplots(1, 2, figsize=(8, 3))
        axs[0].plot(g[:200])
        axs[0].set_title('Time Domain Baseband Signal')
        axs[0].set_xlabel('Samples')
        axs[0].set_ylabel('Amplitude')
        axs[1].plot(freqs[:N_fft//2]/1e6, np.abs(g_fft_result[:N_fft//2]))
        axs[1].set_title('One Sided FFT of Baseband Signal')
        axs[1].set_xlabel('Frequency (MHz)')
        axs[1].set_ylabel('Magnitude')
        fig.tight_layout()
        figs.append(fig)

        # 2. Carrier signal
        c = np.cos(2*np.pi*fc*t)
        c_fft_result = np.fft.fft(c, N_fft)
        fig, axs = plt.subplots(1, 2, figsize=(8, 3))
        axs[0].plot(c[:100])
        axs[0].set_title('Time Domain Carrier Signal')
        axs[0].set_xlabel('Samples')
        axs[0].set_ylabel('Amplitude')
        axs[1].plot(freqs[:N_fft//2]/1e6, np.abs(c_fft_result[:N_fft//2]))
        axs[1].set_title('One Sided FFT of Carrier Signal')
        axs[1].set_xlabel('Frequency (MHz)')
        axs[1].set_ylabel('Magnitude')
        fig.tight_layout()
        figs.append(fig)

        # 3. Modulated signal
        s = g * c
        s_fft_result = np.fft.fft(s, N_fft)
        fig, axs = plt.subplots(1, 2, figsize=(8, 3))
        axs[0].plot(s[:200])
        axs[0].set_title('Time Domain Modulated Signal')
        axs[0].set_xlabel('Samples')
        axs[0].set_ylabel('Amplitude')
        axs[1].plot(freqs[:N_fft//2]/1e6, np.abs(s_fft_result[:N_fft//2]))
        axs[1].set_title('One Sided FFT of Modulated Signal')
        axs[1].set_xlabel('Frequency (MHz)')
        axs[1].set_ylabel('Magnitude')
        fig.tight_layout()
        figs.append(fig)

        # 4. Demodulated signal (unfiltered)
        x = c * s
        x_fft_result = np.fft.fft(x, N_fft)
        fig, axs = plt.subplots(1, 2, figsize=(8, 3))
        axs[0].plot(x[:200])
        axs[0].set_title('Time Domain Unfiltered Demodulated Signal')
        axs[0].set_xlabel('Samples')
        axs[0].set_ylabel('Amplitude')
        axs[1].plot(freqs[:N_fft//2]/1e6, np.abs(x_fft_result[:N_fft//2]))
        axs[1].set_title('One Sided FFT of Unfiltered Demodulated Signal')
        axs[1].set_xlabel('Frequency (MHz)')
        axs[1].set_ylabel('Magnitude')
        fig.tight_layout()
        figs.append(fig)

        # 5. Low-pass filtered demodulated signal
        f_cutoff = 0.1  # Fraction of fs
        b = 0.08
        N = int(np.ceil((4 / b)))
        if not N % 2:
            N += 1
        n = np.arange(N)
        h = np.sinc(2 * f_cutoff * (n - (N - 1) / 2))
        w = np.blackman(N)
        h *= w
        h /= np.sum(h)
        u = np.convolve(x, h)
        u_fft_result = np.fft.fft(u, N_fft)
        fig, axs = plt.subplots(1, 2, figsize=(8, 3))
        axs[0].plot(u[:200])
        axs[0].set_title('Time Domain Lowpass Filtered Demodulated Signal')
        axs[0].set_xlabel('Samples')
        axs[0].set_ylabel('Amplitude')
        axs[1].plot(freqs[:N_fft//2]/1e6, np.abs(u_fft_result[:N_fft//2]))
        axs[1].set_title('One Sided FFT of Lowpass Filtered Demodulated Signal')
        axs[1].set_xlabel('Frequency (MHz)')
        axs[1].set_ylabel('Magnitude')
        fig.tight_layout()
        figs.append(fig)

        # Convert all figs to HTML and concatenate
        for f in figs:
            plot_html += mpld3.fig_to_html(f) + "<br><br>"

    except Exception as e:
        error = str(e)

    return render_template('amplitude_mod_and_demod.html',
                           plot_html=plot_html, error=error)


@app.route('/frequency_mod_and_demod', methods=['GET', 'POST'])
def frequency_mod_and_demod():
    plot_html = ""
    error = None

    defaults = {
        "fs": 10000,     # Sampling frequency
        "duration": 0.01, # Short duration for clear plotting
        "fc": 500,       # Carrier frequency
        "kf": 100,       # Frequency sensitivity
        "fm": 50,        # Message frequency
        "Am": 1          # Message amplitude
    }

    try:
        if request.method == 'POST':
            fs = int(request.form.get("fs", defaults["fs"]))
            duration = float(request.form.get("duration", defaults["duration"]))
            fc = float(request.form.get("fc", defaults["fc"]))
            kf = float(request.form.get("kf", defaults["kf"]))
            fm = float(request.form.get("fm", defaults["fm"]))
            Am = float(request.form.get("Am", defaults["Am"]))
        else:
            fs, duration, fc, kf, fm, Am = defaults.values()

        # Time vector
        t = np.arange(0, duration, 1/fs)

        figs = []

        # 1. Message signal
        message = Am * np.sin(2 * np.pi * fm * t)
        fig, ax = plt.subplots(figsize=(8, 3))
        ax.plot(t[:500], message[:500])
        ax.set_title("Message Signal (time domain)")
        ax.set_xlabel("Time (s)")
        ax.set_ylabel("Amplitude")
        fig.tight_layout()
        figs.append(fig)

        # 2. FM Modulated signal
        integrated_message = np.cumsum(message) / fs
        fm_signal = np.cos(2 * np.pi * fc * t + 2 * np.pi * kf * integrated_message)
        fig, ax = plt.subplots(figsize=(8, 3))
        ax.plot(t[:500], fm_signal[:500])
        ax.set_title("FM Modulated Signal (time domain)")
        ax.set_xlabel("Time (s)")
        ax.set_ylabel("Amplitude")
        fig.tight_layout()
        figs.append(fig)

        # 3. FM Demodulated signal
        analytic_signal = hilbert(fm_signal)
        instantaneous_phase = np.unwrap(np.angle(analytic_signal))
        demodulated = np.diff(instantaneous_phase) * fs / (2 * np.pi * kf)
        demodulated = np.append(demodulated, demodulated[-1])
        fig, ax = plt.subplots(figsize=(8, 3))
        ax.plot(t[:500], demodulated[:500])
        ax.set_title("FM Demodulated Signal (time domain)")
        ax.set_xlabel("Time (s)")
        ax.set_ylabel("Amplitude")
        fig.tight_layout()
        figs.append(fig)

        # Convert all figs to HTML
        for f in figs:
            plot_html += mpld3.fig_to_html(f) + "<br><br>"

    except Exception as e:
        error = str(e)

    return render_template('frequency_mod_and_demod.html',
                           plot_html=plot_html, error=error)

@app.route('/pulse_delta_mod_and_demod', methods=['GET', 'POST'])
def delta_mod_and_demod():
    plot_html = ""
    error = None

    # Default parameters
    defaults = {
        "fs": 1000,      # Sampling frequency
        "duration": 0.05, # Duration in seconds
        "fm": 5,         # Message frequency
        "Am": 1,         # Message amplitude
        "delta": 0.1     # Step size
    }

    try:
        # Get inputs from form (or use defaults)
        if request.method == 'POST':
            fs = int(request.form.get("fs", defaults["fs"]))
            duration = float(request.form.get("duration", defaults["duration"]))
            fm = float(request.form.get("fm", defaults["fm"]))
            Am = float(request.form.get("Am", defaults["Am"]))
            delta = float(request.form.get("delta", defaults["delta"]))
        else:
            fs, duration, fm, Am, delta = defaults.values()

        # Time vector
        t = np.arange(0, duration, 1/fs)

        figs = []

        # 1. Message Signal
        message = Am * np.sin(2 * np.pi * fm * t)
        fig, ax = plt.subplots(figsize=(8, 3))
        ax.plot(t, message)
        ax.set_title("Message Signal")
        ax.set_xlabel("Time (s)")
        ax.set_ylabel("Amplitude")
        figs.append(fig)

        # 2. Delta Modulation
        y = np.zeros(len(t))
        eq = np.zeros(len(t))
        for i in range(1, len(t)):
            if message[i] > y[i-1]:
                eq[i] = delta
            else:
                eq[i] = -delta
            y[i] = y[i-1] + eq[i]

        fig, ax = plt.subplots(figsize=(8, 3))
        ax.plot(t, message, label="Message")
        ax.step(t, y, label="Delta Modulated", where='post')
        ax.set_title("Delta Modulated Signal")
        ax.legend()
        figs.append(fig)

        # 3. Demodulated Signal (integrating steps)
        demodulated = np.cumsum(eq)
        fig, ax = plt.subplots(figsize=(8, 3))
        ax.plot(t, message, label="Message")
        ax.plot(t, demodulated, label="Demodulated")
        ax.set_title("Delta Demodulated Signal")
        ax.legend()
        figs.append(fig)

        # Convert all figs to HTML
        for f in figs:
            plot_html += mpld3.fig_to_html(f) + "<br><br>"

    except Exception as e:
        error = str(e)

    return render_template('pulse_delta_mod_and_demod.html',
                           plot_html=plot_html, error=error)

@app.route('/pulse_width_mod_and_demod', methods=['GET', 'POST'])
def pwm_mod_and_demod():
    plot_html = ""
    error = None

    # Default parameters
    defaults = {
        "fs": 5000,       # Sampling frequency (Hz)
        "f_pwm": 50,      # PWM carrier frequency (Hz)
        "duration": 0.05, # Signal duration (s)
        "seed": 0         # Random seed for reproducibility
    }

    try:
        # Get inputs from form (or defaults)
        if request.method == 'POST':
            fs = int(request.form.get("fs", defaults["fs"]))
            f_pwm = float(request.form.get("f_pwm", defaults["f_pwm"]))
            duration = float(request.form.get("duration", defaults["duration"]))
            seed = int(request.form.get("seed", defaults["seed"]))
        else:
            fs, f_pwm, duration, seed = defaults.values()

        # Time vector
        t = np.linspace(0, duration, int(fs * duration), endpoint=False)

        # Random waveform
        np.random.seed(seed)
        random_wave = np.random.rand(len(t))  
        random_wave = np.convolve(random_wave, np.ones(50)/50, mode='same')  # smooth

        # Sawtooth carrier for PWM
        carrier = (t * f_pwm) % 1  

        # PWM output
        pwm_output = (random_wave > carrier).astype(float)

        figs = []

        # Plot 1: Random waveform + Carrier
        fig, ax = plt.subplots(figsize=(8, 3))
        ax.plot(t, random_wave, label='Random Waveform')
        ax.plot(t, carrier, label='Carrier (Sawtooth)', alpha=0.7)
        ax.set_title("Random Waveform vs Carrier")
        ax.legend()
        ax.grid(True)
        figs.append(fig)

        # Plot 2: PWM output
        fig, ax = plt.subplots(figsize=(8, 3))
        ax.plot(t, pwm_output, drawstyle='steps-pre', label='PWM Output')
        ax.set_title("PWM Signal")
        ax.legend()
        ax.grid(True)
        figs.append(fig)

        # Plot 3: Overlay
        fig, ax = plt.subplots(figsize=(8, 3))
        ax.plot(t, random_wave, label='Random Waveform')
        ax.plot(t, pwm_output, drawstyle='steps-pre', label='PWM Output')
        ax.set_title("Overlay of Input and PWM")
        ax.legend()
        ax.grid(True)
        figs.append(fig)

        # Convert plots to HTML
        for f in figs:
            plot_html += mpld3.fig_to_html(f) + "<br><br>"

    except Exception as e:
        error = str(e)

    return render_template("pulse_width_mod_and_demod.html", plot_html=plot_html, error=error)

class Node:
    def __init__(self, char, freq):
        self.char = char
        self.freq = freq
        self.left = None
        self.right = None

def huffman_encode(message):
    freq = {}
    for ch in message:
        freq[ch] = freq.get(ch, 0) + 1
    nodes = [Node(ch, f) for ch, f in freq.items()]
    while len(nodes) > 1:
        nodes = sorted(nodes, key=lambda x: x.freq)
        left, right = nodes[0], nodes[1]
        newNode = Node(None, left.freq + right.freq)
        newNode.left, newNode.right = left, right
        nodes = [newNode] + nodes[2:]
    root = nodes[0]

    codes = {}
    def generate_codes(node, code=""):
        if node is None: return
        if node.char is not None: codes[node.char] = code
        generate_codes(node.left, code+"0")
        generate_codes(node.right, code+"1")
    generate_codes(root)

    encoded = "".join(codes[ch] for ch in message)
    return encoded, codes

def huffman_decode(encoded, codes):
    reverse = {v: k for k, v in codes.items()}
    decoded, buff = "", ""
    for bit in encoded:
        buff += bit
        if buff in reverse:
            decoded += reverse[buff]
            buff = ""
    return decoded

# --- RLE ---
def rle_encode(data):
    encoding = ""
    i = 0
    while i < len(data):
        count = 1
        while i + 1 < len(data) and data[i] == data[i+1]:
            i += 1
            count += 1
        encoding += str(count) + data[i]
        i += 1
    return encoding

def rle_decode(data):
    decoded = ""
    count = ""
    for char in data:
        if char.isdigit():
            count += char
        else:
            decoded += char * int(count)
            count = ""
    return decoded

# --- LZW ---
def lzw_compress(uncompressed):
    dict_size = 256
    dictionary = {chr(i): i for i in range(dict_size)}
    w, result = "", []
    for c in uncompressed:
        wc = w + c
        if wc in dictionary:
            w = wc
        else:
            result.append(dictionary[w])
            dictionary[wc] = dict_size
            dict_size += 1
            w = c
    if w:
        result.append(dictionary[w])
    return result

def lzw_decompress(compressed):
    dict_size = 256
    dictionary = {i: chr(i) for i in range(dict_size)}
    result = [dictionary[compressed[0]]]
    w = result[0]
    for k in compressed[1:]:
        if k in dictionary:
            entry = dictionary[k]
        elif k == dict_size:
            entry = w + w[0]
        else:
            raise ValueError("Bad LZW compressed k: %s" % k)
        result.append(entry)
        dictionary[dict_size] = w + entry[0]
        dict_size += 1
        w = entry
    return "".join(result)

# --- Add noise ---
def add_noise(data, probability=0.1):
    noisy = ""
    for bit in data:
        if random.random() < probability:
            noisy += "1" if bit == "0" else "0"
        else:
            noisy += bit
    return noisy

@app.route("/channel_coding", methods=["GET", "POST"])
def channel_coding():
    result = None
    error = None

    if request.method == "POST":
        algo = request.form.get("algorithm")
        message = request.form.get("message", "")
        apply_noise = request.form.get("apply_noise")

        if not message:
            error = "Message cannot be empty!"
        else:
            try:
                if algo == "huffman":
                    encoded, codes = huffman_encode(message)
                    if apply_noise:
                        noisy = add_noise(encoded)
                        decoded = huffman_decode(noisy, codes)
                        result = f"Huffman Coding\nMessage: {message}\nEncoded: {encoded}\nNoisy: {noisy}\nDecoded: {decoded}"
                    else:
                        decoded = huffman_decode(encoded, codes)
                        result = f"Huffman Coding\nMessage: {message}\nEncoded: {encoded}\nDecoded: {decoded}"

                elif algo == "rle":
                    encoded = rle_encode(message)
                    decoded = rle_decode(encoded)
                    result = f"RLE\nMessage: {message}\nEncoded: {encoded}\nDecoded: {decoded}"

                elif algo == "lzw":
                    encoded = lzw_compress(message)
                    decoded = lzw_decompress(encoded)
                    result = f"LZW\nMessage: {message}\nEncoded: {encoded}\nDecoded: {decoded}"

                else:
                    error = "Unknown algorithm!"
            except Exception as e:
                error = str(e)

    return render_template("channel_coding.html", result=result, error=error)

@app.route('/complex_QAM', methods=['GET', 'POST'])
def complex_QAM():
    plot_html = ""
    error = None

    # Default values
    defaults = {
        "fs": 4096e6,
        "fb1": 64e6,
        "fb2": 64e6,
        "A1": 2,
        "A2": 1,
        "N_fft": 2048,
        "fc": 900e6
    }

    try:
        if request.method == 'POST':
            fs = float(request.form.get("fs", defaults["fs"]))
            fb1 = float(request.form.get("fb1", defaults["fb1"]))
            fb2 = float(request.form.get("fb2", defaults["fb2"]))
            A1 = float(request.form.get("A1", defaults["A1"]))
            A2 = float(request.form.get("A2", defaults["A2"]))
            N_fft = int(request.form.get("N_fft", defaults["N_fft"]))
            fc = float(request.form.get("fc", defaults["fc"]))
        else:
            fs, fb1, fb2, A1, A2, N_fft, fc = defaults.values()

        # Time axis
        t = np.arange(N_fft) / fs

        # Signals
        g_complex = A1 * np.cos(2*np.pi*fb1*t) + 1j*A2*np.cos(2*np.pi*fb2*t)
        g_fft = np.fft.fft(g_complex, N_fft)
        freqs = np.fft.fftfreq(N_fft, 1/fs)

        c_complex = np.exp(1j*2*np.pi*fc*t)
        v = g_complex * c_complex
        y = v.real

        # Demodulation
        demod_carrier = np.exp(-1j*2*np.pi*fc*t)
        x = y * demod_carrier

        # Lowpass filter
        f_cutoff = 0.1
        b = 0.08
        N = int(np.ceil(4/b))
        if N % 2 == 0: N += 1
        n_filter = np.arange(N)
        h = np.sinc(2*f_cutoff*(n_filter-(N-1)/2)) * np.blackman(N)
        h /= np.sum(h)
        z = np.convolve(x, h)
        z_fft = np.fft.fft(z, N_fft)

        figs = []

        # Helper function
        def add_plot(x_data, y_data, title, xlabel='Samples', ylabel='Amplitude', complex_plot=False):
            fig, ax = plt.subplots(figsize=(8,3))
            if complex_plot:
                ax.plot(x_data, y_data.real)
                ax.plot(x_data, y_data.imag)
                ax.legend(['I Component','Q Component'])
            else:
                ax.plot(x_data, y_data)
            ax.set_title(title)
            ax.set_xlabel(xlabel)
            ax.set_ylabel(ylabel)
            fig.tight_layout()
            figs.append(fig)

        # Generate all plots
        add_plot(t[:200], g_complex[:200], 'Time Domain Complex Information Signal', complex_plot=True)
        add_plot(freqs[:N_fft//2]/1e6, np.abs(g_fft[:N_fft//2]), 'One Sided FFT of Complex Information Signal', 'Frequency MHz', 'Magnitude')
        add_plot(freqs/1e6, np.abs(g_fft), 'Two Sided FFT of Complex Information Signal', 'Frequency MHz', 'Magnitude')

        add_plot(t[:100], c_complex[:100], 'Time Domain Complex Carrier', complex_plot=True)
        add_plot(freqs/1e6, np.abs(np.fft.fft(c_complex,N_fft)), 'FFT of Complex Carrier', 'Frequency MHz', 'Magnitude')

        add_plot(t[:200], v[:200], 'Time Domain Complex Modulated Signal', complex_plot=True)
        add_plot(freqs/1e6, np.abs(np.fft.fft(v,N_fft)), 'FFT of Complex Modulated Signal', 'Frequency MHz', 'Magnitude')

        add_plot(t[:200], y[:200], 'Time Domain Real Modulated Signal')
        add_plot(freqs[:N_fft//2]/1e6, np.abs(np.fft.fft(y,N_fft)[:N_fft//2]), 'One Sided FFT of Real Modulated Signal', 'Frequency MHz', 'Magnitude')

        add_plot(t[:200], x[:200], 'Time Domain Complex Demodulated Signal', complex_plot=True)
        add_plot(freqs/1e6, np.abs(np.fft.fft(x,N_fft)), 'FFT of Complex Demodulated Signal', 'Frequency MHz', 'Magnitude')

        add_plot(t[:200], z[:200], 'Lowpass Filtered Complex Demodulated Signal', complex_plot=True)
        add_plot(freqs[:N_fft//2]/1e6, np.abs(z_fft[:N_fft//2]), 'FFT of Lowpass Filtered Signal', 'Frequency MHz', 'Magnitude')

        # Convert figures to HTML
        for f in figs:
            plot_html += mpld3.fig_to_html(f) + "<br><br>"

    except Exception as e:
        error = str(e)

    return render_template('complex_QAM.html', plot_html=plot_html, error=error)

@app.route('/plots')
def show_plots():
    plots = []

    T = 1
    k = 0.25
    A = 1
    border = np.pi

    def plot_to_html(fig):
        return mpld3.fig_to_html(fig)

    def draw_plot1(x_, y_, xlabel, ylabel, title=""):
        fig, ax = plt.subplots()
        ax.stem(x_, y_)
        ax.set_xlabel(xlabel)
        ax.set_ylabel(ylabel)
        ax.set_title(title)
        ax.grid()
        html = plot_to_html(fig)
        plt.close(fig)  # Close figure to avoid memory leaks
        return html

    def c_sum(array, bound):
        csum = []
        s = 0
        for i in range(len(array)):
            if i < bound:
                s += array[i]
            else:
                s = 0
            csum.append(s)
        return csum

    impulse = signal.unit_impulse(100, [0])
    m = np.arange(0, 100, 1)

    # A: simple impulse and step responses
    plots.append(draw_plot1(m, (1 / 2) * (ndimage.shift(impulse, 0, cval=0)[m] + ndimage.shift(impulse, 1, cval=0)[m]),
            'n','Response','Impulse Response'))
    plots.append(draw_plot1(m, np.cumsum((1 / 2) * (ndimage.shift(impulse, 0, cval=0)[m] + ndimage.shift(impulse, 1, cval=0)[m])),
            'n','Response','Step Response'))

    # B: another impulse difference
    plots.append(draw_plot1(m, (ndimage.shift(impulse, -1, cval=0)[m] - ndimage.shift(impulse, 0, cval=0)[m]),
            'n','Response','Impulse Response'))
    plots.append(draw_plot1(m, np.cumsum(ndimage.shift(impulse, -1, cval=0)[m] - ndimage.shift(impulse, 0, cval=0)[m]),
            'n','Response','Step Response'))

    # C: c_sum variations
    for bound in [5, 15, 20]:
        plots.append(draw_plot1(m, c_sum((1 / 2) * (ndimage.shift(impulse, 0, cval=0)[m] + ndimage.shift(impulse, 1, cval=0)[m]), bound),
                               'n', 'Response', f'A Step Response for m_u = {bound}'))
        plots.append(draw_plot1(m, c_sum((ndimage.shift(impulse, -1, cval=0)[m] - ndimage.shift(impulse, 0, cval=0)[m]), bound),
                               'n', 'Response', f'B Step Response for m_u = {bound}'))
        plots.append(draw_plot1(m, c_sum((ndimage.shift(impulse, -1, cval=0)[m] - 
                                          2*ndimage.shift(impulse, 0, cval=0)[m] + 
                                          ndimage.shift(impulse, 1, cval=0)[m]), bound),
                               'n', 'Response', f'C Step Response for m_u = {bound}'))

    return render_template("plots.html", plots=plots)

def vehicle_update(t, x, u, params):
    a = params.get('refoffset', 1.5)
    b = params.get('wheelbase', 3.0)
    maxsteer = params.get('maxsteer', 0.5)
    delta = np.clip(u[1], -maxsteer, maxsteer)
    alpha = np.arctan2(a * np.tan(delta), b)
    return np.array([
        u[0] * np.cos(x[2] + alpha),
        u[0] * np.sin(x[2] + alpha),
        (u[0] / a) * np.sin(alpha)
    ])

def vehicle_output(t, x, u, params):
    return x

@app.route('/control_sys', methods=['GET', 'POST'])
def control_sys():
    plot_html = ""
    error = None

    # Default values
    defaults = {
        "sim_time": 10.0,
        "points": 1000,
        "velocity": 10.0,
        "steer_amp": 0.1,
        "ref_offset": 1.5,
        "wheelbase": 3.0,
        "maxsteer": 0.5
    }

    try:
        if request.method == 'POST':
            sim_time = float(request.form.get("sim_time", defaults["sim_time"]))
            points = int(request.form.get("points", defaults["points"]))
            velocity = float(request.form.get("velocity", defaults["velocity"]))
            steer_amp = float(request.form.get("steer_amp", defaults["steer_amp"]))
            ref_offset = float(request.form.get("ref_offset", defaults["ref_offset"]))
            wheelbase = float(request.form.get("wheelbase", defaults["wheelbase"]))
            maxsteer = float(request.form.get("maxsteer", defaults["maxsteer"]))
        else:
            sim_time, points, velocity, steer_amp, ref_offset, wheelbase, maxsteer = defaults.values()

        # Vehicle system
        vehicle_params = {'refoffset': ref_offset, 'wheelbase': wheelbase, 'velocity': velocity, 'maxsteer': maxsteer}
        vehicle = ct.NonlinearIOSystem(
            vehicle_update, vehicle_output, states=3, name='vehicle',
            inputs=['v','delta'], outputs=['x','y','theta'], params=vehicle_params
        )

        timepts = np.linspace(0, sim_time, points)
        U = [velocity*np.ones_like(timepts), steer_amp*np.sin(timepts*2*np.pi)]

        # Open-loop simulation
        t, outputs = ct.input_output_response(vehicle, timepts, U, 0)
        figs = []

        # 1. Open-loop trajectory
        fig, ax = plt.subplots()
        ax.plot(outputs[0], outputs[1])
        ax.set_xlabel("x [m]")
        ax.set_ylabel("y [m]")
        ax.set_title("Open-loop Vehicle Trajectory")
        fig.tight_layout()
        figs.append(fig)

        # 2. Inputs over time
        fig, ax = plt.subplots()
        ax.plot(timepts, U[0], 'b-', label='Velocity [m/s]')
        ax.set_ylabel('Velocity [m/s]', color='blue')
        ax2 = ax.twinx()
        ax2.plot(timepts, U[1], 'r-', label='Steering [rad]')
        ax2.set_ylabel('Steering angle [rad]', color='red')
        ax.set_xlabel("Time [s]")
        ax.set_title("Open-loop Inputs")
        fig.tight_layout()
        figs.append(fig)

        # LQR design
        Ud = np.array([velocity*np.ones_like(timepts), np.zeros_like(timepts)])
        Xd = np.array([10*timepts, np.zeros_like(timepts), np.zeros_like(timepts)])
        linsys = vehicle.linearize(Xd[:,0], Ud[:,0])
        K, S, E = ct.lqr(linsys, np.diag([1,1,1]), np.diag([1,1]))
        vehicle_control = ct.NonlinearIOSystem(
            None,
            lambda t, x, z, params={'K':K}: z[3:5] - K@(z[5:8]-z[0:3]),
            name='control',
            inputs=['xd','yd','thetad','vd','deltad','x','y','theta'],
            outputs=['v','delta'],
        )
        vehicle_closed = ct.interconnect(
            (vehicle, vehicle_control),
            inputs=['xd','yd','thetad','vd','deltad'],
            outputs=['x','y','theta']
        )

        # Closed-loop desired trajectory
        Xd = np.array([
            10*timepts + 2*(timepts-5)*(timepts>5),
            0.5*np.sin(timepts*2*np.pi),
            np.zeros_like(timepts)
        ])
        resp = ct.input_output_response(vehicle_closed, timepts, np.vstack((Xd, Ud)), 0)
        time, outputs = resp.time, resp.outputs

        # 3. Closed-loop trajectory comparison
        fig, ax = plt.subplots()
        ax.plot(Xd[0], Xd[1], 'b--', label='Desired Trajectory')
        ax.plot(outputs[0], outputs[1], 'r-', label='Actual Trajectory')
        ax.set_xlabel("x [m]"); ax.set_ylabel("y [m]")
        ax.set_title("Closed-loop Vehicle Trajectory")
        ax.legend()
        fig.tight_layout()
        figs.append(fig)

        # 4. Velocity comparison
        fig, ax = plt.subplots()
        ax.plot(np.diff(Xd[0])/np.diff(timepts), 'b--', label='Desired Velocity')
        ax.plot(np.diff(outputs[0])/np.diff(timepts), 'r-', label='Actual Velocity')
        ax.set_xlabel("Time index"); ax.set_ylabel("Velocity [m/s]")
        ax.set_title("Closed-loop Velocity Comparison")
        ax.legend()
        fig.tight_layout()
        figs.append(fig)

        # Convert all figs to HTML
        plot_html = "".join([mpld3.fig_to_html(f) + "<br><br>" for f in figs])

    except Exception as e:
        error = str(e)

    return render_template('control_sys.html', plot_html=plot_html, error=error,
                           defaults=defaults)

@app.route("/DSP", methods=["GET", "POST"])
def DSP():
    result = None
    if request.method == "POST":
        try:
            # ----------- Get User Inputs -----------
            x = list(map(int, request.form["x_seq"].split()))
            y = list(map(int, request.form["y_seq"].split()))
            expr_input = request.form["system_expr"]

            x = np.array(x)
            y = np.array(y)

            # ----------- Convolution -----------
            lin_conv = np.convolve(x, y, mode="full")

            N = max(len(x), len(y))
            x_circ = np.pad(x, (0, N - len(x)), mode='constant')
            y_circ = np.pad(y, (0, N - len(y)), mode='constant')
            circ_conv = np.fft.ifft(np.fft.fft(x_circ) * np.fft.fft(y_circ)).real.round().astype(int)

            # ----------- System Expression -----------
            x_sym = sp.Symbol('x')
            system_expr = sp.sympify(expr_input)
            system_func = sp.lambdify(x_sym, system_expr, modules="numpy")

            # ----------- Linearity Check -----------
            x1, x2, a1, a2 = 1, 2, 3, 4  # fixed test values
            y1 = system_func(x1)
            y2 = system_func(x2)
            lhs = system_func(a1 * x1 + a2 * x2)
            rhs = a1 * y1 + a2 * y2
            linearity = "LINEAR ✅" if np.isclose(lhs, rhs) else "NOT LINEAR ❌"

            # ----------- Time Invariance Check -----------
            t0 = 2
            test_vals = [0, 1, 2, 3, 4, 5]
            passed = True
            for val in test_vals:
                y_shifted_input = system_func(val - t0)
                y_shifted_output = system_func(val - t0)
                if not np.isclose(y_shifted_input, y_shifted_output):
                    passed = False
                    break
            time_invariance = "TIME INVARIANT ✅" if passed else "TIME VARYING ❌"

            # ----------- BIBO Stability Check -----------
            bounded_input = np.linspace(-5, 5, 200)
            outputs = system_func(bounded_input)
            bibo = "BIBO STABLE ✅" if np.all(np.abs(outputs) < 1e6) else "NOT BIBO STABLE ❌"

            # ----------- Collect Results -----------
            result = {
                "lin_conv": lin_conv.tolist(),
                "circ_conv": circ_conv.tolist(),
                "system_expr": str(system_expr),
                "linearity": linearity,
                "time_invariance": time_invariance,
                "bibo": bibo
            }

        except Exception as e:
            result = {"error": str(e)}

    return render_template("DSP.html", result=result)

@app.route("/DFT", methods=["GET", "POST"])
def DFT():
    result = None
    if request.method == "POST":
        try:
            # Get user input
            seq_str = request.form["sequence"]
            x = np.array(list(map(float, seq_str.split())))
            N = len(x)

            # DFT
            X = np.fft.fft(x, N)

            # IDFT
            x_reconstructed = np.fft.ifft(X, N)

            # Prepare results
            dft_list = [f"k={k}: {X[k]:.4f}" for k in range(N)]
            idft_list = [
                f"n={n}: {x_reconstructed[n].real:.4f} + j{x_reconstructed[n].imag:.4e}"
                for n in range(N)
            ]

            result = {
                "sequence": x.tolist(),
                "dft": dft_list,
                "idft": idft_list
            }

        except Exception as e:
            result = {"error": str(e)}

    return render_template("DFT.html", result=result)

@app.route("/filters", methods=["GET", "POST"])
def filters():
    result = ""
    if request.method == "POST":
        try:
            contin = int(request.form.get("contin"))  # 0=continuous, 1=discrete

            if contin == 1:  # discrete filters
                coeff_mode = int(request.form.get("coeff_mode"))  # 1=coeff, 0=ZPK
                if coeff_mode == 1:
                    num = request.form.get("num", "")
                    den = request.form.get("den", "")
                    b = tuple(map(float, num.strip().split()))
                    a = tuple(map(float, den.strip().split()))
                    fil = LTIFilter(b, a)
                else:
                    zeros = tuple(map(lambda z: complex(z), request.form.get("zeros", "").split()))
                    poles = tuple(map(lambda p: complex(p), request.form.get("poles", "").split()))
                    gain = float(request.form.get("gain", "1"))
                    fil = LTIFilter.from_ZPK(zeros, poles, gain)

                result += f"<pre>{fil.transfer_function()}</pre>"
                result += f"<pre>{fil.frequency_response()}</pre>"
                result += f"<pre>{fil.angular_frequency_response()}</pre>"
                result += f"<pre>{fil.group_delay()}</pre>"
                result += f"<pre>{fil.impulse_response()}</pre>"
                result += f"<pre>{fil.step_response()}</pre>"

            else:  # continuous filters
                filt_type = int(request.form.get("filt_type"))  # 0=Bessel, 1=Butterworth
                omega = float(request.form.get("omega", "1"))

                if filt_type == 1:
                    B = Butterworth(N=2, Wn=omega, btype="lowpass")
                else:
                    B = Bessel(N=2, Wn=omega, btype="lowpass")

                result += f"<pre>{B.transfer_function()}</pre>"
                result += f"<pre>{B.frequency_response()}</pre>"
                result += f"<pre>{B.group_delay()}</pre>"

        except Exception as e:
            result = f"<p style='color:red'>Error: {e}</p>"

    return render_template("filters.html", result=result)


UPLOAD_FOLDER = "uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Default image path
DEFAULT_IMAGE = os.path.join(UPLOAD_FOLDER, "1.webp")

def load_image():
    img = cv2.imread(DEFAULT_IMAGE)
    if img is None:
        raise FileNotFoundError("Upload '1.webp' into uploads/ folder.")
    img = cv2.copyMakeBorder(img, 50, 50, 50, 50, cv2.BORDER_CONSTANT, value=(0, 0, 0))
    return cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

@app.route("/image_processing", methods=["GET", "POST"])
def image_processing():
    result_img = None
    operation = None

    if request.method == "POST":
        operation = request.form.get("operation")
        image_rgb = load_image()
        height, width = image_rgb.shape[:2]

        if operation == "scale":
            sx_zoom = float(request.form.get("sx_zoom", 1.5))
            sy_zoom = float(request.form.get("sy_zoom", 1.5))
            zoomed = cv2.resize(image_rgb, (int(width * sx_zoom), int(height * sy_zoom)), interpolation=cv2.INTER_CUBIC)
            result_img = zoomed

        elif operation == "rotate":
            angle = float(request.form.get("angle", 45))
            scale = float(request.form.get("scale", 1.0))
            center = (width // 2, height // 2)
            matrix = cv2.getRotationMatrix2D(center, angle, scale)
            rotated = cv2.warpAffine(image_rgb, matrix, (width, height))
            result_img = rotated

        elif operation == "translate":
            tx = int(request.form.get("tx", 50))
            ty = int(request.form.get("ty", 30))
            matrix = np.array([[1, 0, tx], [0, 1, ty]], dtype=np.float32)
            translated = cv2.warpAffine(image_rgb, matrix, (width, height))
            result_img = translated

        elif operation == "shear":
            shearX = float(request.form.get("shearX", 0.2))
            shearY = float(request.form.get("shearY", 0.2))
            matrix = np.array([[1, shearX, 0], [0, 1, shearY]], dtype=np.float32)
            sheared = cv2.warpAffine(image_rgb, matrix, (width, height))
            result_img = sheared

        elif operation == "normalize":
            b, g, r = cv2.split(image_rgb)
            b = cv2.normalize(b.astype('float'), None, 0, 1, cv2.NORM_MINMAX)
            g = cv2.normalize(g.astype('float'), None, 0, 1, cv2.NORM_MINMAX)
            r = cv2.normalize(r.astype('float'), None, 0, 1, cv2.NORM_MINMAX)
            normalized = cv2.merge((b, g, r))
            result_img = (normalized * 255).astype(np.uint8)

        elif operation == "edges":
            t1 = int(request.form.get("t1", 100))
            t2 = int(request.form.get("t2", 200))
            edges = cv2.Canny(image_rgb, t1, t2)
            result_img = cv2.cvtColor(edges, cv2.COLOR_GRAY2RGB)

        elif operation == "blur":
            blurred = cv2.GaussianBlur(image_rgb, (3, 3), 0)
            result_img = blurred

        elif operation == "morphology":
            gray = cv2.cvtColor(image_rgb, cv2.COLOR_RGB2GRAY)
            kernel = np.ones((3, 3), np.uint8)
            dilated = cv2.dilate(gray, kernel, iterations=2)
            result_img = cv2.cvtColor(dilated, cv2.COLOR_GRAY2RGB)

        if result_img is not None:
            # ✅ Return processed image directly (no matplotlib, no white space)
            _, buffer = cv2.imencode(".png", cv2.cvtColor(result_img, cv2.COLOR_RGB2BGR))
            return send_file(BytesIO(buffer), mimetype="image/png")

    return render_template("image_processing.html")
    


# Simple phasor function using your original logic
def phasor_value(magnitude=0, phase=0):
    """Return complex phasor from magnitude and phase (degrees)"""
    return magnitude * np.exp(1j * math.radians(phase))

# Dummy voltage function for compatibility
def voltage(P):
    """Return object with magnitude, phase, rms for display"""
    class V:
        def __init__(self, P):
            self.magnitude = abs(P)
            self.phase = np.angle(P)
            self.rms = abs(P)/np.sqrt(2)
    return V(P)

# Dummy noise voltage generator
class Noise:
    _nid = 0
    def __init__(self, val):
        self.val = val
        self.nid = Noise._nid
        Noise._nid += 1
    def __add__(self, other):
        return Noise(self.val + other.val)
    def __str__(self):
        return str(self.val)

def noisevoltage(val):
    return Noise(val)

# ===========================
# /index1 route
# ===========================
@app.route("/index1", methods=["GET", "POST"])
def index1():
    results = []
    plot_html = ""
    error = None

    if request.method == "POST":
        try:
            mode = (request.form.get("mode") or "phasor").lower()

            # ---- PHASOR MODE ----
            if mode == "phasor":
                mag = float(request.form.get("mag", 0))
                angle = float(request.form.get("angle", 0))
                freq = float(request.form.get("freq", 50))

                P = phasor_value(magnitude=mag, phase=angle)
                V = voltage(P)

                results.append(f"Mode: PHASOR")
                results.append(f"Input: {mag} ∠ {angle}° @ {freq} Hz")
                results.append(f"Magnitude: {V.magnitude}")
                results.append(f"Phase (rad): {V.phase}")
                results.append(f"RMS: {V.rms}")

                # ---- PLOT ----
                t = np.linspace(0, 0.04, 1000)
                y = mag * np.cos(2*np.pi*freq*t + math.radians(angle))
                plt.figure()
                plt.plot(t, y)
                plt.title(f"Phasor: {mag}∠{angle}° at {freq}Hz")
                plt.xlabel("Time (s)")
                plt.ylabel("Amplitude")
                plot_html = mpld3.fig_to_html(plt.gcf())
                plt.close()

            # ---- WAVEFORM MODE ----
            elif mode == "waveform":
                A = float(request.form.get("A", 5))
                w = float(request.form.get("omega", 314))
                phi = float(request.form.get("phi", 0))

                P = phasor_value(magnitude=A, phase=math.degrees(phi))
                V = voltage(P)

                results.append(f"Mode: WAVEFORM")
                results.append(f"Amplitude: {A}")
                results.append(f"Phase (rad): {phi}")
                results.append(f"Magnitude: {V.magnitude}")
                results.append(f"RMS: {V.rms}")
                results.append(f"Omega: {w}")

                t = np.linspace(0, 0.04, 1000)
                y = A * np.cos(w * t + phi)
                plt.figure()
                plt.plot(t, y)
                plt.title("Time Domain Waveform")
                plt.xlabel("Time (s)")
                plt.ylabel("Amplitude")
                plot_html = mpld3.fig_to_html(plt.gcf())
                plt.close()

            else:
                raise ValueError("Invalid mode. Use 'phasor' or 'waveform'.")

            # ---- Noise ----
            noise_val = float(request.form.get("noise_val", 2))
            X = noisevoltage(noise_val)
            Y = noisevoltage(4)
            Z = X + Y
            results.append("=== Noise ===")
            results.append(f"X: {X}, id={X.nid}")
            results.append(f"Y: {Y}, id={Y.nid}")
            results.append(f"X + Y = {Z}")

        except Exception as e:
            error = str(e)

    return render_template("index1.html", results=results, error=error, plot_html=plot_html)



@app.route('/qpsk', methods=['GET', 'POST'])
def qpsk():
    plot_htmls = []
    error = None

    if request.method == 'POST':
        try:
            num_symbols = int(request.form.get('num_symbols', 1000))
            noise_power = float(request.form.get('noise_power', 0.01))
            phase_noise_strength = float(request.form.get('phase_noise', 0.1))

            # QPSK symbols
            x_int = np.random.randint(0, 4, num_symbols)
            x_degrees = x_int * 360 / 4.0 + 45
            x_radians = x_degrees * np.pi / 180.0
            x_symbols = np.cos(x_radians) + 1j * np.sin(x_radians)

            fig, axs = plt.subplots(2, 2, figsize=(12, 6), constrained_layout=True)
            axs = axs.flatten()

            # 1. QPSK without noise
            axs[0].plot(np.real(x_symbols), np.imag(x_symbols), '.')
            axs[0].grid(True)
            axs[0].set_title("QPSK without noise")

            # 2. AWGN noise
            n = (np.random.randn(num_symbols) + 1j * np.random.randn(num_symbols)) / np.sqrt(2)
            r = x_symbols + n * np.sqrt(noise_power)
            axs[1].plot(np.real(r), np.imag(r), '.')
            axs[1].grid(True)
            axs[1].set_title("QPSK with AWGN noise")

            # 3. Phase noise
            phase_noise = np.random.randn(len(x_symbols)) * phase_noise_strength
            r1 = x_symbols * np.exp(1j * phase_noise)
            axs[2].plot(np.real(r1), np.imag(r1), '.')
            axs[2].grid(True)
            axs[2].set_title("QPSK with phase noise")

            # 4. Combination of both noises
            total_noise = r1 + r
            axs[3].plot(np.real(total_noise), np.imag(total_noise), '.')
            axs[3].grid(True)
            axs[3].set_title("QPSK with both phase noise and AWGN noise")

            # Convert figure to HTML base64
            buf = io.BytesIO()
            fig.savefig(buf, format="png", bbox_inches="tight")
            buf.seek(0)
            img = base64.b64encode(buf.read()).decode('utf-8')
            plt.close(fig)
            plot_htmls.append(f'<img src="data:image/png;base64,{img}">')

        except Exception as e:
            error = str(e)

    return render_template('qpsk.html', plots=plot_htmls, error=error)
########################################################################################
def matrix_to_float_np(mat):
    return np.array(Matrix(mat).applyfunc(lambda x: float(x.evalf()))).astype(np.float64)

def create_plot():
    img = io.BytesIO()
    plt.savefig(img, format='png', dpi=120, bbox_inches='tight')
    img.seek(0)
    return base64.b64encode(img.getvalue()).decode()

@app.route('/state_space', methods=['GET','POST'])
def state_space():
    plots = []
    error = None
    system_info = ""   # ✅ display system
    stability_msg = "" # ✅ stability
    ctrl_msg = ""      # ✅ controllability
    obs_msg = ""       # ✅ observability

    if request.method == 'POST':
        try:
            mode = request.form['mode']

            # ---------- Build system ----------
            if mode == '0':
                A = sympify(request.form['A']); B = sympify(request.form['B'])
                C = sympify(request.form['C']); D = sympify(request.form['D'])

                A_np = matrix_to_float_np(A)
                B_np = matrix_to_float_np(B)
                C_np = matrix_to_float_np(C)
                D_np = matrix_to_float_np(D)

                sys = ct.ss(A_np, B_np, C_np, D_np)

                system_info = f"A = {A_np}<br>B = {B_np}<br>C = {C_np}<br>D = {D_np}"

            elif mode == '1':
                b = list(map(float, request.form['b'].split()))
                a = list(map(float, request.form['a'].split()))
                sys = ct.tf(b, a)
                sys = ct.ss(sys)

                system_info = "Transfer Function:<br>Numerator = {}<br>Denominator = {}".format(b, a)

                        # ---------- Stability ----------
            # ---------- Stability ----------
            # ---------- Stability ----------
            poles = sys.poles()   # ✅ corrected
            if np.all(np.real(poles) < 0):
                stability_msg = "✅ System is **Stable** (all poles in left half plane)"
            else:
                stability_msg = "❌ System is **Unstable** (poles in right half plane or on jω-axis)"

            # ---------- Controllability ----------
            Ctrb = ct.ctrb(sys.A, sys.B)
            if np.linalg.matrix_rank(Ctrb) == sys.A.shape[0]:
                ctrl_msg = "✅ System is **Controllable**"
            else:
                ctrl_msg = "⚠️ System is **Not Fully Controllable**"

            # ---------- Observability ----------
            Obsv = ct.obsv(sys.A, sys.C)
            if np.linalg.matrix_rank(Obsv) == sys.A.shape[0]:
                obs_msg = "✅ System is **Observable**"
            else:
                obs_msg = "⚠️ System is **Not Fully Observable**"

            # ---------- Pole-Zero Plot ----------
            fig2, ax2 = plt.subplots(figsize=(5, 5))

            zeros = sys.zeros()   # ✅ corrected
            for p in poles:
                ax2.plot(np.real(p), np.imag(p), 'x', markersize=10)
            for z in zeros:
                ax2.plot(np.real(z), np.imag(z), 'o', markersize=8)

            ax2.axhline(0); ax2.axvline(0)
            ax2.set_title("Pole-Zero Plot")
            ax2.set_xlabel("Real")
            ax2.set_ylabel("Imag")
            ax2.grid()



            buf2 = io.BytesIO()
            fig2.savefig(buf2, format="png", bbox_inches="tight"); buf2.seek(0)
            plots.append(base64.b64encode(buf2.read()).decode("utf-8"))
            plt.close(fig2)

        except Exception as e:
            error = str(e)

    return render_template(
        'state_space.html', 
        plots=plots, 
        error=error,
        system_info=system_info,
        stability_msg=stability_msg,
        ctrl_msg=ctrl_msg,
        obs_msg=obs_msg
    )


from lcapy import nexpr, z
import traceback

@app.route('/z_transform', methods=['GET', 'POST'])
def z_transform():
    results = []
    error = None

    if request.method == 'POST':
        try:
            user_input = request.form['signal_expr'].strip()
            if user_input == '':
                raise ValueError("Input cannot be empty.")

            expr = nexpr(user_input)
            z_transform = expr(z).simplify()

            results.append({
                'description': 'Original signal',
                'expr': str(expr),
                'latex': expr.latex()
            })

            results.append({
                'description': 'Z-transform (symbolic)',
                'expr': str(z_transform),
                'latex': z_transform.latex()
            })

        except Exception as e:
            error = f"{e}\n{traceback.format_exc()}"

    return render_template('z_transform.html', results=results, error=error)

@app.route('/laplace_transform', methods=['GET', 'POST'])
def laplace_transform():
    results = []
    error = None

    if request.method == 'POST':
        try:
            expr_str = request.form['signal_expr'].strip()
            if expr_str == '':
                raise ValueError("Input cannot be empty.")

            # Parse the input signal
            sig = texpr(expr_str)

            # Compute Laplace transform
            transformed = sig(s).simplify()

            results.append({
                'description': 'Original signal',
                'expr': str(sig),
                'latex': sig.latex()
            })

            results.append({
                'description': 'Laplace transform (symbolic)',
                'expr': str(transformed),
                'latex': transformed.latex()
            })

        except Exception as e:
            error = f"{e}\n{traceback.format_exc()}"

    return render_template('laplace_transform.html', results=results, error=error)

# Descriptions for each plot
PLOT_DESCRIPTIONS = {
    "1": "Pole-Zero Plot: Shows the poles (X) and zeros (O) of the transfer function in the s-plane.",
    "2": "Bode Plot: Displays magnitude (dB) and phase versus frequency, useful for stability and frequency response analysis.",
    "3": "Nyquist Plot: Plots real vs imaginary parts of H(jω), used for stability margins in control systems.",
    "4": "Nichols Plot: Shows open-loop gain (dB) vs phase, combining Bode information in one plot."
}

@app.route("/transfer", methods=["GET", "POST"])
def transfer_page():
    results = []
    error = None

    if request.method == "POST":
        tf_expr = request.form.get("tf_expr", "").strip()
        choices = request.form.getlist("plots")

        if not tf_expr:
            error = "Please enter a transfer function (example: s/(s+2))."
        else:
            try:
                # Safely evaluate the transfer function
                H = eval(tf_expr, {"s": s})

                for choice in choices:
                    plot_obj = None
                    if choice == "1":
                        plot_obj = H.plot()   # Pole-zero
                    elif choice == "2":
                        plot_obj = H.bode_plot()  # Bode
                    elif choice == "3":
                        plot_obj = H.nyquist_plot((-100, 100))  # Nyquist
                    elif choice == "4":
                        plot_obj = H.nichols_plot((-100, 100))  # Nichols

                    if plot_obj is not None:
                        # If it's an Axes, grab its Figure
                        fig = plot_obj.figure if hasattr(plot_obj, "figure") else plot_obj

                        plot_html = mpld3.fig_to_html(fig)
                        results.append({
                            "description": PLOT_DESCRIPTIONS.get(choice, ""),
                            "plot_html": plot_html
                        })

                        plt.close(fig)  # cleanup

            except Exception as e:
                error = f"Error: {str(e)}"

    return render_template("transfer.html", results=results, error=error)


def compute_roc(poles, signal_type):
    pole_magnitudes = np.abs(poles)

    if signal_type == "causal":
        roc = f"|z| > {np.max(pole_magnitudes):.3f}"
        stable = np.max(pole_magnitudes) < 1
    else:  # anti-causal
        roc = f"|z| < {np.min(pole_magnitudes):.3f}"
        stable = np.min(pole_magnitudes) > 1

    stability_msg = "System is Stable ✅" if stable else "System is Unstable ❌"
    return roc, stability_msg


def z_plane(b, a, signal_type):
    zeros = np.roots(b)
    poles = np.roots(a)

    # Compute ROC & stability
    roc, stability_msg = compute_roc(poles, signal_type)

    fig, ax = plt.subplots(figsize=(6, 6))

    # Plot unit circle
    unit_circle = patches.Circle((0, 0), radius=1, fill=False,
                                 edgecolor='black', linestyle='--', alpha=0.6)
    ax.add_patch(unit_circle)

    # Plot poles & zeros
    ax.plot(zeros.real, zeros.imag, 'go', markersize=10, label='Zeros')
    ax.plot(poles.real, poles.imag, 'rx', markersize=12, label='Poles')

    # Axes format
    ax.axvline(0, color='gray', linewidth=0.5)
    ax.axhline(0, color='gray', linewidth=0.5)
    ax.grid(True, linestyle=':', alpha=0.6)
    ax.set_aspect('equal')

    r = max(2, np.max(np.abs(np.concatenate((zeros, poles)))), 1.5)
    ax.set_xlim([-r, r])
    ax.set_ylim([-r, r])

    plt.xlabel('Real Part')
    plt.ylabel('Imaginary Part')
    plt.title('Z-Transform Pole-Zero Plot')
    plt.legend()

    plot_html = mpld3.fig_to_html(fig)
    plt.close(fig)

    return plot_html, roc, stability_msg


@app.route('/z_plane1', methods=['GET', 'POST'])
def z_plane1():
    plot_html, roc, stability_msg = None, "", ""

    if request.method == 'POST':
        numerator = request.form['numerator']
        denominator = request.form['denominator']
        signal_type = request.form['signal_type']

        b = [float(x) for x in numerator.replace(',', ' ').split()]
        a = [float(x) for x in denominator.replace(',', ' ').split()]

        plot_html, roc, stability_msg = z_plane(b, a, signal_type)

    return render_template("z_plane1.html",
                           plot_html=plot_html,
                           roc=roc,
                           stability_msg=stability_msg)
#################################################################################
def fourier_transfer(b, a):
    """Generates Fourier Transfer Magnitude and Phase plot as an mpld3 HTML string."""
    # Frequency range (0 to π for normalized digital frequencies)
    w = np.linspace(0, np.pi, 1024)
    jw = np.exp(1j * w)

    # Evaluate transfer function H(e^jw) = B(e^jw) / A(e^jw)
    num = np.polyval(b, jw**-1)   # numerator polynomial
    den = np.polyval(a, jw**-1)   # denominator polynomial
    H = num / den

    magnitude = np.abs(H)
    phase = np.angle(H)

    # Plot
    fig, axs = plt.subplots(2, 1, figsize=(7, 6))

    # Magnitude plot
    axs[0].plot(w, magnitude, 'b')
    axs[0].set_title("Magnitude Response |H(e^jw)|")
    axs[0].set_xlabel("Frequency (rad/sample)")
    axs[0].set_ylabel("Magnitude")
    axs[0].grid(True, linestyle=':', alpha=0.6)

    # Phase plot
    axs[1].plot(w, phase, 'r')
    axs[1].set_title("Phase Response ∠H(e^jw)")
    axs[1].set_xlabel("Frequency (rad/sample)")
    axs[1].set_ylabel("Phase (radians)")
    axs[1].grid(True, linestyle=':', alpha=0.6)

    plt.tight_layout()

    # Convert to mpld3 HTML
    plot_html = mpld3.fig_to_html(fig)
    plt.close(fig)
    return plot_html


@app.route('/fourier_transform_graph', methods=['GET', 'POST'])
def fourier_transfer_route():
    plot_html = None
    if request.method == 'POST':
        # Get coefficients from user
        numerator = request.form['numerator']
        denominator = request.form['denominator']

        # Convert input into list of floats
        b = [float(x) for x in numerator.replace(',', ' ').split()]
        a = [float(x) for x in denominator.replace(',', ' ').split()]

        plot_html = fourier_transfer(b, a)

    return render_template("fourier_transform_graph.html", plot_html=plot_html)
##################################################################################
def laplace_transfer(b, a):
    """Generates Laplace Transfer Magnitude and Phase plot as an mpld3 HTML string."""
    # Frequency range for s = jω (continuous-time)
    w = np.linspace(0, 100, 2000)  # rad/sec (adjust upper limit if needed)
    s = 1j * w

    # Evaluate transfer function H(s) = B(s) / A(s)
    num = np.polyval(b, s)
    den = np.polyval(a, s)
    H = num / den

    magnitude = np.abs(H)
    phase = np.angle(H)

    # Plot
    fig, axs = plt.subplots(2, 1, figsize=(7, 6))

    # Magnitude plot (log scale, like Bode plot)
    axs[0].semilogx(w, 20 * np.log10(magnitude), 'b')
    axs[0].set_title("Magnitude Response |H(jω)| (dB)")
    axs[0].set_xlabel("Frequency (rad/sec)")
    axs[0].set_ylabel("Magnitude (dB)")
    axs[0].grid(True, which="both", linestyle=':', alpha=0.6)

    # Phase plot
    axs[1].semilogx(w, np.degrees(phase), 'r')
    axs[1].set_title("Phase Response ∠H(jω)")
    axs[1].set_xlabel("Frequency (rad/sec)")
    axs[1].set_ylabel("Phase (degrees)")
    axs[1].grid(True, which="both", linestyle=':', alpha=0.6)

    plt.tight_layout()

    # Convert to mpld3 HTML
    plot_html = mpld3.fig_to_html(fig)
    plt.close(fig)
    return plot_html


# ----------------- SYMPY LAPLACE FUNCTION -----------------

def sympy_laplace_transform(expr_str):
    t, s = sp.symbols('t s', real=True)
    
    # Convert string to sympy expression
    try:
        f = sp.sympify(expr_str)
    except Exception:
        return None, "Invalid expression! Please enter valid f(t).", None

    try:
        F = sp.laplace_transform(f, t, s, noconds=True)
    except Exception:
        return None, "Unable to compute Laplace transform.", None

    # Convert sympy transfer function to numerical magnitude/phase
    w = np.linspace(0.01, 100, 2000)
    s_vals = 1j * w
    
    # Lambdify F(s)
    F_func = sp.lambdify(s, F, "numpy")
    H = F_func(s_vals)

    mag = np.abs(H)
    phase = np.angle(H)

    # Plot magnitude & phase
    fig, axs = plt.subplots(2, 1, figsize=(7, 6))

    axs[0].semilogx(w, 20*np.log10(mag))
    axs[0].set_title("Magnitude Response of Laplace Transform |F(jω)| (dB)")
    axs[0].set_xlabel("ω (rad/sec)")
    axs[0].set_ylabel("Magnitude (dB)")
    axs[0].grid(True, which="both", linestyle=':')

    axs[1].semilogx(w, np.degrees(phase))
    axs[1].set_title("Phase Response ∠F(jω)")
    axs[1].set_xlabel("ω (rad/sec)")
    axs[1].set_ylabel("Phase (deg)")
    axs[1].grid(True, which="both", linestyle=':')

    plt.tight_layout()
    plot_html = mpld3.fig_to_html(fig)
    plt.close(fig)

    return sp.simplify(F), None, plot_html

@app.route('/laplace_transform_graph', methods=['GET','POST'])
def laplace_sympy():
    result = None
    error = None
    plot_html = None

    if request.method == 'POST':
        expr_str = request.form['expr']
        result, error, plot_html = sympy_laplace_transform(expr_str)

        if result is not None:
            result = sp.latex(result)  # Convert to LaTeX form for nice rendering

    return render_template("laplace_transform_graph.html", 
                           result=result, 
                           error=error, 
                           plot_html=plot_html)

######################################################################
matplotlib.use("Agg")

from circuit_models.netlist_parser import parse_netlist

app.secret_key = "supersecretkey"

UPLOAD_FOLDER = "uploads"
PLOT_FOLDER = "static/plots"
ALLOWED_EXTS = {"cir", "sp", "txt"}

os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(PLOT_FOLDER, exist_ok=True)

# session-like storage
SESSION = {"components": [], "file": None}

def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTS


@app.route("/netlist", methods=["GET", "POST"])
def netlist_home():
    """Upload and parse netlist"""
    if request.method == "POST":
        if "netlist" not in request.files:
            flash("No file uploaded", "error")
            return redirect(request.url)

        file = request.files["netlist"]
        if file.filename == "":
            flash("No file selected", "error")
            return redirect(request.url)

        if file and allowed_file(file.filename):
            filepath = os.path.join(UPLOAD_FOLDER, file.filename)
            file.save(filepath)

            try:
                comps = parse_netlist(filepath)
                SESSION["components"] = comps
                SESSION["file"] = file.filename
                return redirect(url_for("netlist_home"))
            except Exception as e:
                tb = traceback.format_exc()
                flash(f"Error parsing netlist: {e}\n{tb}", "error")
                return redirect(request.url)

        flash("Invalid file format", "error")
        return redirect(request.url)

    return render_template(
        "netlist.html",
        components=SESSION["components"],
        file_token=SESSION["file"],
        plot_image=None,
        selected=None,
    )

@app.route("/netlist/plot/<int:idx>")
def netlist_plot(idx):
    """Plot I-V curve of a component"""
    try:
        comp = SESSION["components"][idx]
    except IndexError:
        flash("Component not found", "error")
        return redirect(url_for("netlist_home"))

    if not hasattr(comp, "plot_iv"):
        flash(f"{comp.name} does not support plotting", "warning")
        return redirect(url_for("netlist_home"))

    try:
        plot_file = f"{comp.name}.png"
        plot_path = os.path.join(PLOT_FOLDER, plot_file)
        plt.clf()
        comp.plot_iv()
        plt.savefig(plot_path)

        return render_template(
            "netlist.html",
            components=SESSION["components"],
            file_token=SESSION["file"],
            plot_image=f"plots/{plot_file}",
            selected=comp.name,
        )
    except Exception as e:
        tb = traceback.format_exc()
        flash(f"Error plotting: {e}\n{tb}", "error")
        return redirect(url_for("netlist_home"))

@app.route("/emft", methods=["GET", "POST"])
def emft():
    result = ""
    if request.method == "POST":
        try:
            # Get expressions as strings and convert to SymPy
            Fx = sp.sympify(request.form.get("Fx"))
            Fy = sp.sympify(request.form.get("Fy"))
            Fz = sp.sympify(request.form.get("Fz"))

            # Parse point input
            pt_in = [float(val) for val in request.form.get("point").split(",")]

            # Define symbols
            x, y, z, i, j, k = sp.symbols('x y z i j k')

            # Divergence
            divF = sp.diff(Fx, x) + sp.diff(Fy, y) + sp.diff(Fz, z)

            # Curl components
            c1 = sp.diff(Fz, y) - sp.diff(Fy, z)
            c2 = sp.diff(Fx, z) - sp.diff(Fz, x)
            c3 = sp.diff(Fy, x) - sp.diff(Fx, y)

            curlF = (c1, c2, c3)

            # Build result string
            result += f"<pre>Divergence: {divF}</pre>"
            result += f"<pre>Curl: {curlF}</pre>"

            # Substitute values at given point
            subs_dict = {x: pt_in[0], y: pt_in[1], z: pt_in[2]}
            c11 = c1.subs(subs_dict)
            c12 = c2.subs(subs_dict)
            c13 = c3.subs(subs_dict)
            divfinal = divF.subs(subs_dict)

            c_final = c11*i + c12*j + c13*k

            result += f"<pre>Divergence at point: {divfinal}</pre>"
            result += f"<pre>Curl at point: {c_final}</pre>"

        except Exception as e:
            result = f"<p style='color:red'>Error: {e}</p>"

    return render_template("emft.html", result=result)

@app.route("/fresnel", methods=["GET", "POST"])
def fresnel():
    result = ""
    plot_html = ""
    ray_plot_html = ""
    try:
        if request.method == "POST":
            # Get user input
            eps1 = float(sp.sympify(request.form.get("eps1")))
            mu1  = float(sp.sympify(request.form.get("mu1")))
            eps2 = float(sp.sympify(request.form.get("eps2")))
            mu2  = float(sp.sympify(request.form.get("mu2")))
            E0   = float(sp.sympify(request.form.get("E0")))
            theta_i_deg = float(request.form.get("theta"))

            # Convert angle
            theta_i = np.radians(theta_i_deg)

            # Intrinsic impedances
            eta1 = np.sqrt(mu1/eps1)
            eta2 = np.sqrt(mu2/eps2)

            # Snell's law: sin(theta_t) = (n1/n2) * sin(theta_i)
            n1 = np.sqrt(mu1 * eps1)
            n2 = np.sqrt(mu2 * eps2)
            sin_theta_t = (n1/n2) * np.sin(theta_i)
            
            # Determine which medium is denser (higher refractive index)
            if n2 > n1:
                dense_side = "right"
            else:
                dense_side = "left"

            # Handle Total internal reflection
            if abs(sin_theta_t) > 1:
                result = "<p style='color:red'>Total Internal Reflection occurs! (No transmission)</p>"
                theta_t = np.nan
            else:
                theta_t = np.arcsin(sin_theta_t)

            # Fresnel coefficients
            # TE (s polarization)
            Gamma_TE = (eta2*np.cos(theta_i) - eta1*np.cos(theta_t)) / \
                       (eta2*np.cos(theta_i) + eta1*np.cos(theta_t))
            T_TE = (2*eta2*np.cos(theta_i)) / \
                   (eta2*np.cos(theta_i) + eta1*np.cos(theta_t))

            # TM (p polarization)
            Gamma_TM = (eta1*np.cos(theta_i) - eta2*np.cos(theta_t)) / \
                       (eta1*np.cos(theta_i) + eta2*np.cos(theta_t))
            T_TM = (2*eta2*np.cos(theta_i)) / \
                   (eta1*np.cos(theta_i) + eta2*np.cos(theta_t))

            # --------- Fresnel Ray Diagram Plot ---------
            # --------- Fresnel Ray Diagram Plot ---------
            fig2, ax2 = plt.subplots(figsize=(6,6))

            # Medium boundary (vertical line at x=0)
            ax2.plot([0,0],[-1,1], linewidth=2)

            # Normal (dashed)
            ax2.plot([-1,1],[0,0], linestyle="--")

            # Ray origin
            x0, y0 = -0.8, 0

            # Incident ray
            xi = x0 + np.cos(theta_i)
            yi = y0 + np.sin(theta_i)
            ax2.arrow(x0, y0, xi-x0, yi-y0, head_width=0.05, length_includes_head=True)

            # Reflected ray
            xr = x0 + np.cos(theta_i)
            yr = y0 - np.sin(theta_i)
            ax2.arrow(x0, y0, xr-x0, yr-y0, head_width=0.05, length_includes_head=True)

            # Transmitted ray (only if not TIR)
            if not np.isnan(theta_t):
                xt = 0.8*np.cos(theta_t)
                yt = -0.8*np.sin(theta_t)
                ax2.arrow(0,0, xt, yt, head_width=0.05, length_includes_head=True)

            # Labels
            ax2.text(-0.7,0.6,"Incident Wave", fontsize=10)
            ax2.text(-0.7,-0.6,"Reflected Wave", fontsize=10)
            ax2.text(0.3,-0.6,"Transmitted Wave", fontsize=10)
            ax2.text(-0.15,0.05,"Normal", fontsize=9)

            # Medium label
            ax2.text(-0.9,0.9,"Medium 1", fontsize=12)
            ax2.text(0.3,0.9,"Medium 2", fontsize=12)

            # Axis settings
            ax2.set_xlim(-1,1)
            ax2.set_ylim(-1,1)
            ax2.set_title("Fresnel Reflection & Refraction Geometry")
            ax2.set_aspect('equal')
            ax2.axis("off")

            # Background shading based on medium density
            if dense_side == "left":
                ax2.add_patch(plt.Rectangle((-1, -1), 1, 2, alpha=0.25))  # left darker
                ax2.add_patch(plt.Rectangle((0, -1), 1, 2, alpha=0.05))   # right lighter
            else:
                ax2.add_patch(plt.Rectangle((0, -1), 1, 2, alpha=0.25))   # right darker
                ax2.add_patch(plt.Rectangle((-1, -1), 1, 2, alpha=0.05))  # left lighter

            ray_plot_html = mpld3.fig_to_html(fig2)
            plt.close(fig2)


            # Time axis
            t = np.linspace(0, 20, 500)
            omega = 1.0

            Ei = E0 * np.cos(omega*t)
            Er_TE = Gamma_TE * E0 * np.cos(omega*t)
            Et_TE = T_TE * E0 * np.cos(omega*t)
            Er_TM = Gamma_TM * E0 * np.cos(omega*t)
            Et_TM = T_TM * E0 * np.cos(omega*t)

            # Store Results
            result += f"<pre>Incident Angle: {theta_i_deg:.2f}°</pre>"
            if not np.isnan(theta_t):
                result += f"<pre>Transmitted Angle: {np.degrees(theta_t):.2f}°</pre><br>"

            result += "<b>TE (s-pol)</b>"
            result += f"<pre>Γ_TE = {Gamma_TE:.4f}   T_TE = {T_TE:.4f}</pre>"
            result += "<b>TM (p-pol)</b>"
            result += f"<pre>Γ_TM = {Gamma_TM:.4f}   T_TM = {T_TM:.4f}</pre>"

            # Plot
            fig, ax = plt.subplots(figsize=(7,4))
            ax.plot(t, Ei, label="Incident")
            ax.plot(t, Er_TE, "--", label="Reflected TE")
            ax.plot(t, Et_TE, "--", label="Transmitted TE")
            ax.plot(t, Er_TM, "-.", label="Reflected TM")
            ax.plot(t, Et_TM, "-.", label="Transmitted TM")
            ax.set_xlabel("Time")
            ax.set_ylabel("Amplitude")
            ax.set_title("Fresnel Reflection & Transmission (Oblique Incidence)")
            ax.legend()

            plot_html = mpld3.fig_to_html(fig)
            plt.close(fig)

    except Exception as e:
        result = f"<p style='color:red'>Error: {e}</p>"

    return render_template("fresnel.html", result=result,
                       plot_html=plot_html,
                       ray_plot_html=ray_plot_html)
#####################################################################################


@app.route("/smith", methods=["GET", "POST"])
def smith():
    result = ""
    plot_html = ""

    import numpy as np
    import matplotlib.pyplot as plt
    import sympy as sp
    import skrf as rf
    import mpld3

    try:
        # Defaults if first load
        Z0 = float(request.form.get("Z0", 50))
        RL = float(request.form.get("RL", 100))
        XL = float(request.form.get("XL", 50))
        theta_deg = float(request.form.get("theta", 0))  # slider value

        ZL = RL + 1j * XL

        # Reflection coefficient
        Gamma = (ZL - Z0) / (ZL + Z0)
        mag_Gamma = abs(Gamma)
        phase_Gamma = np.angle(Gamma, deg=True)
        VSWR = (1 + mag_Gamma) / (1 - mag_Gamma) if mag_Gamma < 1 else np.inf
        ReturnLoss = -20 * np.log10(mag_Gamma) if mag_Gamma != 0 else np.inf

        Z_norm = ZL / Z0
        result += f"<pre>ZL = {ZL:.2f} Ω</pre>"
        result += f"<pre>Γ = {Gamma:.3f} | |Γ| = {mag_Gamma:.3f} @ {phase_Gamma:.2f}°</pre>"
        result += f"<pre>VSWR = {VSWR:.3f}</pre>"
        result += f"<pre>Return Loss = {ReturnLoss:.2f} dB</pre>"
        result += f"<pre>z = {Z_norm:.3f}</pre>"
        
        # --- L-section MATCHING ---
        # Case: RL < Z0 → series L, shunt C (high-Q)
        # Case: RL > Z0 → series C, shunt L (low-Q)

        if RL < Z0:
            Q = np.sqrt(Z0 / RL - 1)
            Xs = Q * Z0      # series reactance
            Xp = RL * Q      # shunt reactance
            match_type = "Series Inductor, Shunt Capacitor (RL < Z0)"
        else:
            Q = np.sqrt(RL / Z0 - 1)
            Xs = Z0 / Q      # series C
            Xp = RL / Q      # shunt L
            match_type = "Series Capacitor, Shunt Inductor (RL > Z0)"

        result += f"<pre>L-Match: {match_type}\nSeries Xs = {Xs:.2f} Ω, Shunt Xp = {Xp:.2f} Ω</pre>"

        # Convert matching impedance path to Gamma points
        def Z_to_Gamma(Z): return (Z - Z0) / (Z + Z0)

        # Series reactance path
        Z_series = ZL + 1j * np.linspace(0, Xs, 200)
        gamma_series = Z_to_Gamma(Z_series)

        # Shunt reactance path (move in admittance plane)
        YL = 1 / ZL
        Y_shunt = YL + 1j * np.linspace(0, 1/Xp, 200)
        Z_shunt = 1 / Y_shunt
        gamma_shunt = Z_to_Gamma(Z_shunt)

        # --- Smith chart ---
        fig, ax = plt.subplots(figsize=(8, 8))
        rf.plotting.smith(ax=ax, chart_type="z", draw_labels=True)

        # Load point
        ax.plot(np.real(Gamma), np.imag(Gamma), 'o', markersize=10, label="Load Γ")

        # VSWR circle
        th = np.linspace(0, 2*np.pi, 400)
        ax.plot(mag_Gamma * np.cos(th), mag_Gamma * np.sin(th), "--", linewidth=1)

        # L-match paths
        ax.plot(np.real(gamma_series), np.imag(gamma_series), label="Series X", linewidth=2)
        ax.plot(np.real(gamma_shunt), np.imag(gamma_shunt), label="Shunt X", linewidth=2)

        # TL rotation arc (slider)
        theta = np.deg2rad(theta_deg)
        rot_trace = Gamma * np.exp(-1j * 2 * np.linspace(0, theta, 200))
        ax.plot(np.real(rot_trace), np.imag(rot_trace), linewidth=2, label=f"TL Rotation {theta_deg}°")

        # Rotated point
        Gamma_rot = Gamma * np.exp(-1j * 2 * theta)
        ax.plot(np.real(Gamma_rot), np.imag(Gamma_rot), 's', markersize=8, label="Rotated Γ")

        ax.set_xlim(-1.05, 1.05)
        ax.set_ylim(-1.05, 1.05)
        ax.set_aspect("equal", adjustable="box")
        ax.set_title("Enhanced Smith Chart with L-Match and TL Rotation")
        ax.legend(loc="upper right", fontsize=8)

        plot_html = mpld3.fig_to_html(fig)
        plt.close(fig)

    except Exception as e:
        result = f"<p style='color:red'>Error: {e}</p>"

    return render_template("smith.html", result=result, plot_html=plot_html)


##################################################################################

@app.route("/waveguide", methods=["GET", "POST"])
def waveguide():
    result = ""
    plot_html = ""

    try:
        if request.method == "POST":

            import numpy as np
            import matplotlib.pyplot as plt
            import mpld3
            from scipy.special import jv, jn_zeros, jvp

            # User selections
            wg_type = request.form.get("wg_type", "rectangular")
            field_type = request.form.get("field_type", "E")

            c = 3e8
            mu0 = 4 * np.pi * 1e-7
            eps0 = 1 / (mu0 * c * c)

            # Mode indices
            m = int(request.form.get("m"))
            n = int(request.form.get("n"))

            # Prevent invalid mode
            if m == 0 and n == 0:
                raise ValueError("TM(0,0) mode does not physically exist.")

            # =============== RECTANGULAR WAVEGUIDE ===============
            if wg_type == "rectangular":
                a = float(request.form.get("a"))
                b = float(request.form.get("b"))

                fc = (c / 2) * np.sqrt((m / a) ** 2 + (n / b) ** 2)

                x = np.linspace(0, a, 200)
                y = np.linspace(0, b, 200)
                X, Y = np.meshgrid(x, y)

                # TM Electric field
                Ez = np.sin(m * np.pi * X / a) * np.sin(n * np.pi * Y / b)

                # Magnetic fields (from ∇Ez)
                dEz_dx = (m * np.pi / a) * np.cos(m * np.pi * X / a) * np.sin(n * np.pi * Y / b)
                dEz_dy = (n * np.pi / b) * np.sin(m * np.pi * X / a) * np.cos(n * np.pi * Y / b)

                Hx = -(1j / mu0) * dEz_dy
                Hy =  (1j / mu0) * dEz_dx

                # Correct magnitude (complex magnitude)
                H_mag = np.abs(np.sqrt(Hx**2 + Hy**2))

                field = Ez if field_type == "E" else H_mag
                title = f"Rectangular TM({m},{n}) - {'Ez' if field_type=='E' else '|H|'}"

            # =============== CIRCULAR WAVEGUIDE ===============
            else:
                radius = float(request.form.get("radius"))

                roots = jn_zeros(m, n)
                k_mn = roots[-1] / radius   # TM mode root

                fc = (c / (2*np.pi)) * k_mn

                r = np.linspace(0, radius, 200)
                theta = np.linspace(0, 2*np.pi, 200)
                R, T = np.meshgrid(r, theta)

                # TM Electric field
                Ez = jv(m, k_mn * R) * np.cos(m * T)

                # Correct derivative dEz/dr = k * Jm'(kr)
                dEz_dr = k_mn * jvp(m, k_mn * R, n=1)

                # dEz / dθ
                dEz_dθ = -m * jv(m, k_mn * R) * np.sin(m * T)

                # Avoid division by zero at r = 0
                denom = R + 1e-12
                H_mag = np.abs(np.sqrt((dEz_dr)**2 + (dEz_dθ/denom)**2))

                field = Ez if field_type == "E" else H_mag
                title = f"Circular TM({m},{n}) - {'Ez' if field_type=='E' else '|H|'}"

                # Convert polar to Cartesian for plotting
                X = R * np.cos(T)
                Y = R * np.sin(T)

            # ===== Plotting =====
            fig, ax = plt.subplots(figsize=(6,5))
            img = ax.pcolormesh(X, Y, field, shading="auto", cmap="jet")
            fig.colorbar(img, ax=ax)
            ax.set_aspect("equal", adjustable="box")
            ax.set_title(title)
            ax.set_xlabel("x (m)")
            ax.set_ylabel("y (m)")

            plot_html = mpld3.fig_to_html(fig)
            plt.close(fig)

            result += f"<pre>Cutoff Frequency: {fc/1e9:.3f} GHz</pre>"

    except Exception as e:
        result = f"<p style='color:red'>Error: {e}</p>"

    return render_template("waveguide.html", result=result, plot_html=plot_html)

###############################################################################################
@app.route("/bounce", methods=["GET", "POST"])
def bounce():
    result = ""
    plot_html = ""

    try:
        if request.method == "POST":
            mode = request.form.get("mode", "tdr")  # tdr or two_wall

            import numpy as np
            import matplotlib.pyplot as plt
            import mpld3

            td = float(request.form.get("td"))
            n_reflections = int(request.form.get("n_reflections"))

            # ---------------------------------------------------------
            # ✅ Mode 1: Standard TDR
            # ---------------------------------------------------------
            if mode == "tdr":
                Z0 = float(request.form.get("Z0"))
                ZL = float(request.form.get("ZL"))
                Zs = float(request.form.get("Zs"))
                Vstep = float(request.form.get("Vstep"))
                observe = request.form.get("observe")

                Gamma_L = (ZL - Z0) / (ZL + Z0)
                Gamma_S = (Zs - Z0) / (Zs + Z0)
                V0_plus = Vstep * Z0 / (Zs + Z0)

                times = [0]
                voltages = [V0_plus if observe == "load" else Vstep - V0_plus]

                Vcur = V0_plus
                t = 0

                for k in range(1, n_reflections + 1):
                    Vcur *= Gamma_L if k % 2 else Gamma_S
                    t += td
                    times.append(t)
                    voltages.append(voltages[-1] + Vcur)

                # --- Plot TDR curve ---
                fig, ax = plt.subplots(figsize=(7,4))
                ax.step(times, voltages, where="post")
                ax.set_xlabel("Time (ns)")
                ax.set_ylabel("Voltage (V)")
                ax.set_title("TDR Bounce Plot")
                ax.grid(True)

                result += f"<pre>ΓL={Gamma_L:.3f}, ΓS={Gamma_S:.3f}</pre>"

            # ---------------------------------------------------------
            # ✅ Mode 2: Two-Wall Zig-Zag Bounce Diagram
            # ---------------------------------------------------------
            else:
                V0 = float(request.form.get("V0"))
                Gamma_L = float(request.form.get("Gamma_L"))
                Gamma_R = float(request.form.get("Gamma_R"))

                # Zig-zag path arrays
                x = [0]  # start left
                y = [0]
                V = V0
                amplitudes = [V0]

                # Bounce propagation
                for k in range(1, n_reflections + 1):
                    if k % 2 == 1:  # hit right
                        x.append(1)
                        V = V * Gamma_R
                    else:           # hit left
                        x.append(0)
                        V = V * Gamma_L
                    y.append(k)
                    amplitudes.append(V)

                # --- Plot geometric bounce diagram ---
                fig, ax = plt.subplots(figsize=(5,8))
                ax.plot(x, y, marker='o')

                # Label amplitudes at each bounce
                for i, V in enumerate(amplitudes):
                    ax.text(
                        x[i] + (0.05 if x[i] == 0 else -0.25),
                        y[i],
                        f"{V:.3f}V",
                        fontsize=9
                    )

                ax.set_xticks([0,1])
                ax.set_xticklabels([f"Left (ΓL={Gamma_L})", f"Right (ΓR={Gamma_R})"])
                ax.set_ylabel("Bounce Index k")
                ax.set_xlabel("Position along line")
                ax.set_title("Two-Wall Voltage Bounce Diagram")
                ax.grid(True, linestyle="--", alpha=0.4)

                result += f"<pre>Γ_left={Gamma_L}, Γ_right={Gamma_R}</pre>"

            # ------------------ Convert to HTML ------------------
            plot_html = mpld3.fig_to_html(fig)
            plt.close(fig)
            result += f"<pre>Reflections simulated: {n_reflections}</pre>"

    except Exception as e:
        result = f"<p style='color:red'>Error: {e}</p>"

    return render_template("bounce.html", result=result, plot_html=plot_html)

# ---------------- CLIPPER CIRCUIT ----------------
def diode_clipper(input_signal, E1, E2, Vk):
    output_signal = input_signal.copy()
    for i in range(len(output_signal)):
        if output_signal[i] > E1 + Vk:
            output_signal[i] = E1 + Vk
        elif output_signal[i] < -(E2 + Vk):
            output_signal[i] = -(E2 + Vk)
    return output_signal

def simulate_half_wave(Vp, Vk, R, f):
    t = np.linspace(0, 1/f, 500)
    Vin = Vp * np.sin(2*np.pi*f*t)
    Vout = np.maximum(Vin - Vk, 0)
    fig, ax = plt.subplots()
    ax.plot(t, Vout)
    ax.set_title("Half-Wave Rectifier Output")
    ax.set_xlabel("Time (s)")
    ax.set_ylabel("Voltage (V)")
    return mpld3.fig_to_html(fig)

def simulate_full_wave(Vp, Vk, R, f):
    t = np.linspace(0, 1/f, 500)
    Vin = Vp * np.sin(2*np.pi*f*t)
    Vout = np.abs(Vin) - Vk
    Vout[Vout < 0] = 0
    fig, ax = plt.subplots()
    ax.plot(t, Vout)
    ax.set_title("Full-Wave Rectifier Output")
    ax.set_xlabel("Time (s)")
    ax.set_ylabel("Voltage (V)")
    return mpld3.fig_to_html(fig)

def simulate_rc(Vin, R, C, f):
    t = np.linspace(0, 1/f, 500)
    Vin_wave = Vin*np.sin(2*np.pi*f*t)
    tau = R*C
    Vout = Vin_wave/(np.sqrt(1+(2*np.pi*f*tau)**2))
    fig, ax = plt.subplots()
    ax.plot(t, Vout)
    ax.set_title("RC Low-Pass Filter Output")
    ax.set_xlabel("Time (s)")
    ax.set_ylabel("Voltage (V)")
    return mpld3.fig_to_html(fig)

def simulate_rl(Vin, R, L, f):
    t = np.linspace(0, 1/f, 500)
    Vin_wave = Vin*np.sin(2*np.pi*f*t)
    Xl = 2*np.pi*f*L
    I = Vin_wave/np.sqrt(R**2 + Xl**2)
    fig, ax = plt.subplots()
    ax.plot(t, I)
    ax.set_title("RL Circuit Current")
    ax.set_xlabel("Time (s)")
    ax.set_ylabel("Current (A)")
    return mpld3.fig_to_html(fig)

def simulate_rlc(Vin, R, L, C, f):
    t = np.linspace(0, 1/f, 500)
    Vin_wave = Vin*np.sin(2*np.pi*f*t)
    w = 2*np.pi*f
    Xl = w*L
    Xc = 1/(w*C)
    Z = np.sqrt(R**2 + (Xl-Xc)**2)
    I = Vin_wave / Z
    fig, ax = plt.subplots()
    ax.plot(t, I)
    ax.set_title("RLC Band-Pass Circuit Output Current")
    ax.set_xlabel("Time (s)")
    ax.set_ylabel("Current (A)")
    return mpld3.fig_to_html(fig)

@app.route("/clipper", methods=["GET","POST"])
def clipper():
    plot = None
    circuit = request.form.get("circuit")

    if request.method == "POST" and circuit:
        if circuit == "half":
            plot = simulate_half_wave(float(request.form["Vp"]), float(request.form["Vk"]),
                                      float(request.form["Rl"]), float(request.form["freq"]))
        elif circuit == "full":
            plot = simulate_full_wave(float(request.form["Vp"]), float(request.form["Vk"]),
                                      float(request.form["Rl"]), float(request.form["freq"]))
        elif circuit == "rc":
            plot = simulate_rc(float(request.form["Vin"]), float(request.form["R"]),
                               float(request.form["C"]), float(request.form["freq"]))
        elif circuit == "rl":
            plot = simulate_rl(float(request.form["Vin"]), float(request.form["R"]),
                               float(request.form["L"]), float(request.form["freq"]))
        elif circuit == "rlc":
            plot = simulate_rlc(float(request.form["Vin"]), float(request.form["R"]),
                                float(request.form["L"]), float(request.form["C"]),
                                float(request.form["freq"]))

    return render_template("clipper.html", plot=plot, circuit=circuit)

######################################################################################################
# Define symbols for user expressions
alpha = symbol('alpha')
m = symbol('m', integer=True)
f0 = symbol('f0')
w0 = 2 * pi * f0
No = symbol('N_o', odd=True)
Ne = symbol('N_e', even=True)
K = symbol('K')

@app.route("/DTFT", methods=["GET", "POST"])
def DTFT():
    result = None
    error = None

    if request.method == "POST":
        expr_str = request.form.get("expression")
        try:
            expr = nexpr(expr_str)  # Parse input
            f_expr = expr(f)        # DTFT

            result = {
                "original_expr": str(expr),
                "original_latex": simplify(expr).latex(),
                "transform_expr": str(f_expr),
                "transform_latex": simplify(f_expr).latex()
            }
        except Exception as e:
            error = str(e)

    return render_template("DTFT.html", result=result, error=error)
################################################################################################

def bit_reverse_indices(n):
    bits = int(math.log2(n))
    return np.array([int('{:0{w}b}'.format(i, w=bits)[::-1], 2) for i in range(n)])

def staged_fft_dit(x):
    """Return list of numpy arrays: stage0..stageK for DIT radix-2 FFT.
       stage0 = input after bit-reversal (so viewers see permutation first).
    """
    x = np.asarray(x, dtype=complex)
    N = x.size
    assert N & (N - 1) == 0, "N must be power of two"
    stages = []
    # bit-reverse input ordering (so stage0 = permuted inputs)
    br = bit_reverse_indices(N)
    state = x[br].copy()
    stages.append(state.copy())

    half_size = 1
    n_stages = int(math.log2(N))
    for stage in range(1, n_stages + 1):
        step = half_size * 2
        W_m = np.exp(-2j * np.pi / step)
        for k in range(0, N, step):
            w = 1.0 + 0j
            for j in range(half_size):
                a = state[k + j]
                b = state[k + j + half_size] * w
                state[k + j] = a + b
                state[k + j + half_size] = a - b
                w *= W_m
        stages.append(state.copy())
        half_size = step
    return stages

def svg_tree_from_stages(stages, width=1000, height_per_node=38, node_r=18):
    """
    Build an SVG string showing stages as columns. Each column shows N nodes.
    All nodes are present at all stages; node labels update to stage values.
    We include connector lines (butterfly cross) and mark which pairs are
    combined at each stage by data attributes for JS to highlight.
    """
    N = stages[0].size
    levels = len(stages)  # stage0..stageK
    canvas_width = width
    canvas_height = max(300, height_per_node * N)

    left_margin = 80
    right_margin = 60
    top_margin = 40
    bottom_margin = 40
    usable_w = canvas_width - left_margin - right_margin
    col_x = lambda s: left_margin + s * (usable_w / max(1, (levels - 1)))

    def node_y(idx):
        # distribute from top_margin..canvas_height-bottom_margin
        top = top_margin
        bottom = canvas_height - bottom_margin
        if N == 1:
            return (top + bottom) / 2
        return top + (bottom - top) * (idx / (N - 1))

    svg = []
    svg.append(f'<svg id="fft-svg" viewBox="0 0 {canvas_width} {canvas_height}" '
               f'xmlns="http://www.w3.org/2000/svg" style="background:#fff;">')

    # Stage labels
    for s in range(levels):
        x = col_x(s)
        svg.append(f'<text x="{x}" y="{top_margin/2}" font-size="14" text-anchor="middle" fill="#111">Stage {s}</text>')

    # Precompute position dict
    pos = {}
    for s in range(levels):
        x = col_x(s)
        for i in range(N):
            y = node_y(i)
            pos[(s, i)] = (x, y)

    # Draw connector lines and mark butterflies as groups
    for s in range(levels - 1):
        step = 2 ** (s)
        # group id for stage s
        for i0 in range(0, N, 2 * step):
            for j in range(step):
                i = i0 + j
                jidx = i + step
                p_a = pos[(s, i)]
                p_b = pos[(s, jidx)]
                p_a2 = pos[(s + 1, i)]
                p_b2 = pos[(s + 1, jidx)]
                # straight lines down/up
                # connections a->a2 and b->b2
                svg.append(f'<line x1="{p_a[0]+node_r}" y1="{p_a[1]}" x2="{p_a2[0]-node_r}" y2="{p_a2[1]}" stroke="#9aa5b1" stroke-width="2" />')
                svg.append(f'<line x1="{p_b[0]+node_r}" y1="{p_b[1]}" x2="{p_b2[0]-node_r}" y2="{p_b2[1]}" stroke="#9aa5b1" stroke-width="2" />')
                # cross lines for butterfly
                # a -> b2 and b -> a2 (dashed)
                svg.append(f'<line class="butterfly-line stage-{s}" data-stage="{s}" x1="{p_a[0]+node_r}" y1="{p_a[1]}" x2="{p_b2[0]-node_r}" y2="{p_b2[1]}" stroke="#cbd5e1" stroke-width="1.5" stroke-dasharray="4 4" />')
                svg.append(f'<line class="butterfly-line stage-{s}" data-stage="{s}" x1="{p_b[0]+node_r}" y1="{p_b[1]}" x2="{p_a2[0]-node_r}" y2="{p_a2[1]}" stroke="#cbd5e1" stroke-width="1.5" stroke-dasharray="4 4" />')

    # Draw nodes (circles + text). Each node group contains label placeholders for JS updates.
    for s in range(levels):
        for i in range(N):
            x, y = pos[(s, i)]
            idg = f"n{s}_{i}"
            # initial value from stages[s][i]
            val = stages[s][i]
            val_str = f"{val.real:.2f}" if abs(val.imag) < 1e-8 else f"{val.real:.2f}{val.imag:+.2f}j"
            # group with data-stage and data-idx
            svg.append(f'<g id="{idg}" class="node" data-stage="{s}" data-idx="{i}">')
            svg.append(f'  <circle cx="{x}" cy="{y}" r="{node_r}" fill="#ffffff" stroke="#1f2937" stroke-width="1.5"/>')
            svg.append(f'  <text x="{x}" y="{y-6}" font-size="10" text-anchor="middle" fill="#111">{i}</text>')
            svg.append(f'  <text class="val" x="{x}" y="{y+10}" font-size="10" text-anchor="middle"  font-weight="bold" fill="#0b1220">{html.escape(val_str)}</text>')
            svg.append('</g>')

    svg.append('</svg>')
    return '\n'.join(svg)


@app.route("/fft", methods=["GET", "POST"])
def fft():
    final_output = []
    svg_tree = None
    N_choices = [2,4,8,16]
    error = None
    chosen_N = 8
    if request.method == "POST":
        raw = request.form.get("input_values","").strip()
        chosen_N = int(request.form.get("fft_points","8"))
        if chosen_N not in N_choices:
            error = "Select FFT size 2,4,8 or 16."
        else:
            # parse inputs
            try:
                parts = [p.strip() for p in raw.split(",") if p.strip()!='']
                vals = []
                for p in parts:
                    # allow complex like 1+2j or '3' floats
                    try:
                        v = complex(p)
                    except:
                        v = complex(float(p), 0.0)
                    vals.append(v)
                # pad or trim to chosen_N
                if len(vals) < chosen_N:
                    vals += [0]*(chosen_N - len(vals))
                else:
                    vals = vals[:chosen_N]
                stages = staged_fft_dit(vals)
                svg_tree = svg_tree_from_stages(stages)
                final_vals = stages[-1]
                for i, v in enumerate(final_vals):
                    val_str = f"{v.real:.2f}" if abs(v.imag) < 1e-8 else f"{v.real:.2f}{v.imag:+.2f}j"
                    final_output.append((i, val_str))
            except Exception as e:
                error = "Failed to parse inputs. Use comma-separated numbers, complex allowed like 1+2j."
    else:
        # default example
        chosen_N = 8
        vals = [1.0 * np.sin(2*np.pi*1*k/chosen_N) + 0.5*np.sin(2*np.pi*2*k/chosen_N) for k in range(chosen_N)]
        stages = staged_fft_dit(vals)
        svg_tree = svg_tree_from_stages(stages)

    return render_template("fft.html", svg_tree=svg_tree, error=error, chosen_N=chosen_N, final_output=final_output)
###################################################################################################
# cpu8085.py
# Simple 8085 CPU emulator (educational, not cycle-accurate).
# Supports a practical subset of instructions: MOV, MVI, LXI, LDA, STA,
# LHLD/SHLD, ADD/ADI, SUB/SUI, INR/DCR, INX/DCX, JMP, JZ/JNZ, JC/JNC,
# CALL/RET, PUSH/POP, HLT, NOP, CMP/CPI, ANI/ORI/XRA/ANA, OUT/IN, RLC/RRC, CMA.
# Extend opcode table and behavior as needed.

from typing import List, Tuple, Dict

REG_ORDER = ["B","C","D","E","H","L","M","A"]  # for encoding convenience

def word(high, low):
    return ((high & 0xFF) << 8) | (low & 0xFF)

class CPU8085:
    def __init__(self, mem_size=65536):
        self.reg = {r:0 for r in ["A","B","C","D","E","H","L"]}
        self.flags = {"Z":0, "S":0, "P":0, "CY":0, "AC":0}
        self.PC = 0
        self.SP = 0xFFFE
        self.memory = [0]*mem_size
        self.halted = False
        self.output_log = []
        self.input_ports = {}
        # simple opcode dispatch table will be built later if needed

    def reset(self):
        for r in self.reg: self.reg[r]=0
        for f in self.flags: self.flags[f]=0
        self.PC = 0
        self.SP = 0xFFFE
        self.memory = [0]*len(self.memory)
        self.halted = False
        self.output_log = []

    def load_program(self, code: List[int], addr=0x0000):
        for i, b in enumerate(code):
            self.memory[addr+i] = b & 0xFF
        self.PC = addr
        self.halted = False

    def read_mem(self, addr):
        return self.memory[addr & 0xFFFF]

    def write_mem(self, addr, val):
        self.memory[addr & 0xFFFF] = val & 0xFF

    def get_reg_pair(self, rp):
        if rp == "B":
            return (self.reg["B"]<<8) | self.reg["C"]
        if rp == "D":
            return (self.reg["D"]<<8) | self.reg["E"]
        if rp == "H":
            return (self.reg["H"]<<8) | self.reg["L"]
        if rp == "PSW":
            return (self.reg["A"]<<8) | self._flags_to_byte()
        return 0

    def set_reg_pair(self, rp, val):
        val &= 0xFFFF
        if rp == "B":
            self.reg["B"] = (val>>8)&0xFF; self.reg["C"]=val&0xFF
        if rp == "D":
            self.reg["D"] = (val>>8)&0xFF; self.reg["E"]=val&0xFF
        if rp == "H":
            self.reg["H"] = (val>>8)&0xFF; self.reg["L"]=val&0xFF
        if rp == "PSW":
            self.reg["A"] = (val>>8)&0xFF; self._byte_to_flags(val&0xFF)

    def _flags_to_byte(self):
        b = 0
        b |= (self.flags["S"]<<7)
        b |= (self.flags["Z"]<<6)
        b |= (0<<5)  # x (unused)
        b |= (self.flags["AC"]<<4)
        b |= (0<<3)  # x
        b |= (self.flags["P"]<<2)
        b |= (1<<1)  # always 1 in PSW? (not exact) - keep placeholder
        b |= (self.flags["CY"]<<0)
        return b

    def _byte_to_flags(self, b):
        self.flags["S"] = (b>>7)&1
        self.flags["Z"] = (b>>6)&1
        self.flags["AC"] = (b>>4)&1
        self.flags["P"] = (b>>2)&1
        self.flags["CY"] = b&1

    def _set_flag_szp(self, value):
        v = value & 0xFF
        self.flags["Z"] = 1 if v==0 else 0
        self.flags["S"] = 1 if (v & 0x80)!=0 else 0
        # parity
        self.flags["P"] = 1 if bin(v).count("1") % 2 == 0 else 0

    def push_word(self, val):
        self.SP = (self.SP - 1) & 0xFFFF
        self.write_mem(self.SP, (val>>8)&0xFF)
        self.SP = (self.SP - 1) & 0xFFFF
        self.write_mem(self.SP, val&0xFF)

    def pop_word(self):
        low = self.read_mem(self.SP); self.SP = (self.SP + 1)&0xFFFF
        high = self.read_mem(self.SP); self.SP = (self.SP + 1)&0xFFFF
        return (high<<8)|low

    def fetch(self):
        b = self.read_mem(self.PC)
        self.PC = (self.PC+1) & 0xFFFF
        return b

    def step(self) -> Tuple[bool,str]:
        """Execute single instruction. Returns (halted, message)."""
        if self.halted:
            return True, "HALTED"

        op = self.fetch()
        # NOP
        if op == 0x00:
            return False, "NOP"

        # HLT
        if op == 0x76:
            self.halted = True
            return True, "HLT"

        # MVI r, data8 : 0x06, 0x0E, 0x16, 0x1E, 0x26, 0x2E, 0x36, 0x3E
        if op in (0x06,0x0E,0x16,0x1E,0x26,0x2E,0x36,0x3E):
            idx = (op>>3)&0x07
            reg = REG_ORDER[idx]
            data = self.fetch()
            if reg == "M":
                addr = (self.reg["H"]<<8)|self.reg["L"]
                self.write_mem(addr, data)
            else:
                self.reg[reg] = data
            return False, f"MVI {reg},#{data:02X}"

        # MOV r1,r2 : 0x40 - 0x7F (except 0x76 handled above)
        if 0x40 <= op <= 0x7F:
            dst = (op>>3)&0x07
            src = op & 0x07
            dst_r = REG_ORDER[dst]; src_r = REG_ORDER[src]
            val = None
            if src_r == "M":
                addr = (self.reg["H"]<<8)|self.reg["L"]; val = self.read_mem(addr)
            else:
                val = self.reg[src_r]
            if dst_r == "M":
                addr = (self.reg["H"]<<8)|self.reg["L"]; self.write_mem(addr, val)
            else:
                self.reg[dst_r] = val
            return False, f"MOV {dst_r},{src_r}"

        # LXI rp, word : 0x01,0x11,0x21,0x31  (B, D, H, SP)
        if op in (0x01,0x11,0x21,0x31):
            low = self.fetch(); high = self.fetch()
            val = (high<<8)|low
            if op == 0x01: self.set_reg_pair("B", val)
            elif op == 0x11: self.set_reg_pair("D", val)
            elif op == 0x21: self.set_reg_pair("H", val)
            elif op == 0x31: self.SP = val
            return False, f"LXI {op:02X} #{val:04X}"

        # LDA addr (3A), STA (32)
        if op == 0x3A:
            low = self.fetch(); high = self.fetch(); addr = (high<<8)|low
            self.reg["A"] = self.read_mem(addr)
            return False, f"LDA {addr:04X}"
        if op == 0x32:
            low = self.fetch(); high = self.fetch(); addr = (high<<8)|low
            self.write_mem(addr, self.reg["A"])
            return False, f"STA {addr:04X}"

        # LHLD (2A) / SHLD (22)
        if op == 0x2A:
            low = self.fetch(); high = self.fetch(); addr = (high<<8)|low
            self.reg["L"] = self.read_mem(addr)
            self.reg["H"] = self.read_mem((addr+1)&0xFFFF)
            return False, f"LHLD {addr:04X}"
        if op == 0x22:
            low = self.fetch(); high = self.fetch(); addr = (high<<8)|low
            self.write_mem(addr, self.reg["L"]); self.write_mem((addr+1)&0xFFFF, self.reg["H"])
            return False, f"SHLD {addr:04X}"

        # ADD r (80-87) / ADI (C6)
        if 0x80 <= op <= 0x87:
            src = op & 0x07
            r = REG_ORDER[src]
            val = self.reg[r] if r!="M" else self.read_mem((self.reg["H"]<<8)|self.reg["L"])
            res = self.reg["A"] + val
            self.flags["CY"] = 1 if res>0xFF else 0
            self.reg["A"] = res & 0xFF
            self._set_flag_szp(self.reg["A"])
            return False, f"ADD {r}"
        if op == 0xC6:
            data = self.fetch()
            res = self.reg["A"] + data
            self.flags["CY"] = 1 if res>0xFF else 0
            self.reg["A"] = res & 0xFF
            self._set_flag_szp(self.reg["A"])
            return False, f"ADI #{data:02X}"

        # SUB r (90-97) / SUI (D6)
        if 0x90 <= op <= 0x97:
            src = op & 0x07
            r = REG_ORDER[src]
            val = self.reg[r] if r!="M" else self.read_mem((self.reg["H"]<<8)|self.reg["L"])
            res = (self.reg["A"] - val) & 0x1FF
            self.flags["CY"] = 1 if self.reg["A"] < val else 0
            self.reg["A"] = res & 0xFF
            self._set_flag_szp(self.reg["A"]); return False, f"SUB {r}"
        if op == 0xD6:
            data = self.fetch()
            res = (self.reg["A"] - data) & 0x1FF
            self.flags["CY"] = 1 if self.reg["A"] < data else 0
            self.reg["A"] = res & 0xFF
            self._set_flag_szp(self.reg["A"]); return False, f"SUI #{data:02X}"

        # INR r (04,0C,14,1C,24,2C,34,3C) / DCR r (05,0D,15,...)
        if op in (0x04,0x0C,0x14,0x1C,0x24,0x2C,0x34,0x3C):
            idx = (op>>3)&0x07; r = REG_ORDER[idx]
            if r=="M":
                addr = (self.reg["H"]<<8)|self.reg["L"]; v = (self.read_mem(addr)+1)&0xFF; self.write_mem(addr, v)
                self._set_flag_szp(v)
            else:
                self.reg[r] = (self.reg[r]+1)&0xFF
                self._set_flag_szp(self.reg[r])
            return False, f"INR {r}"
        if op in (0x05,0x0D,0x15,0x1D,0x25,0x2D,0x35,0x3D):
            idx = (op>>3)&0x07; r = REG_ORDER[idx]
            if r=="M":
                addr = (self.reg["H"]<<8)|self.reg["L"]; v = (self.read_mem(addr)-1)&0xFF; self.write_mem(addr, v)
                self._set_flag_szp(v)
            else:
                self.reg[r] = (self.reg[r]-1)&0xFF
                self._set_flag_szp(self.reg[r])
            return False, f"DCR {r}"

        # INX rp (03,13,23,33) DCX rp (0B,1B,2B,3B)
        if op in (0x03,0x13,0x23,0x33):
            if op==0x03: rp="B"
            elif op==0x13: rp="D"
            elif op==0x23: rp="H"
            else: rp="SP"
            if rp=="SP":
                self.SP = (self.SP + 1)&0xFFFF
            else:
                v = self.get_reg_pair(rp)+1; self.set_reg_pair(rp, v&0xFFFF)
            return False, f"INX {rp}"
        if op in (0x0B,0x1B,0x2B,0x3B):
            if op==0x0B: rp="B"
            elif op==0x1B: rp="D"
            elif op==0x2B: rp="H"
            else: rp="SP"
            if rp=="SP":
                self.SP = (self.SP - 1)&0xFFFF
            else:
                v = (self.get_reg_pair(rp)-1)&0xFFFF; self.set_reg_pair(rp, v)
            return False, f"DCX {rp}"

        # JMP, JZ, JNZ, JC, JNC
        if op in (0xC3, 0xCA, 0xC2, 0xDA, 0xD2):
            low = self.fetch(); high = self.fetch(); addr = (high<<8)|low
            if op==0xC3:
                self.PC = addr; return False, f"JMP {addr:04X}"
            if op==0xC2:
                if self.flags["Z"]==0: self.PC = addr; return False, f"JNZ {addr:04X}"
                return False, f"JNZ (no)"
            if op==0xCA:
                if self.flags["Z"]==1: self.PC = addr; return False, f"JZ {addr:04X}"
                return False, f"JZ (no)"
            if op==0xD2:
                if self.flags["CY"]==0: self.PC = addr; return False, f"JNC {addr:04X}"
                return False, f"JNC (no)"
            if op==0xDA:
                if self.flags["CY"]==1: self.PC = addr; return False, f"JC {addr:04X}"
                return False, f"JC (no)"

        # CALL (CD) / RET (C9)
        if op == 0xCD:
            low = self.fetch(); high = self.fetch(); addr = (high<<8)|low
            ret = self.PC
            self.push_word(ret)
            self.PC = addr
            return False, f"CALL {addr:04X}"
        if op == 0xC9:
            self.PC = self.pop_word()
            return False, "RET"

        # PUSH rp (C5, D5, E5, F5) POP rp (C1, D1, E1, F1)
        if op in (0xC5,0xD5,0xE5,0xF5):
            if op==0xC5: rp="B"
            elif op==0xD5: rp="D"
            elif op==0xE5: rp="H"
            else: rp="PSW"
            if rp=="PSW":
                self.push_word((self.reg["A"]<<8) | self._flags_to_byte())
            else:
                self.push_word(self.get_reg_pair(rp))
            return False, f"PUSH {rp}"
        if op in (0xC1,0xD1,0xE1,0xF1):
            if op==0xC1: rp="B"
            elif op==0xD1: rp="D"
            elif op==0xE1: rp="H"
            else: rp="PSW"
            val = self.pop_word()
            if rp=="PSW":
                self.reg["A"] = (val>>8)&0xFF; self._byte_to_flags(val&0xFF)
            else:
                self.set_reg_pair(rp, val)
            return False, f"POP {rp}"

        # CMP r (B8-BF) CPI D? (FE)
        if 0xB8 <= op <= 0xBF:
            src = op & 0x07; r = REG_ORDER[src]
            val = self.reg[r] if r!="M" else self.read_mem((self.reg["H"]<<8)|self.reg["L"])
            res = (self.reg["A"] - val) & 0xFF
            self.flags["CY"] = 1 if self.reg["A"] < val else 0
            self._set_flag_szp(res)
            return False, f"CMP {r}"
        if op == 0xFE:
            data = self.fetch()
            res = (self.reg["A"] - data) & 0xFF
            self.flags["CY"] = 1 if self.reg["A"] < data else 0
            self._set_flag_szp(res)
            return False, f"CPI #{data:02X}"

        # ANI, ORI, XRA, ANA immediate
        if op == 0xE6: # ANI
            data = self.fetch(); self.reg["A"] &= data; self._set_flag_szp(self.reg["A"]); self.flags["CY"]=0; return False, f"ANI #{data:02X}"
        if op == 0xF6: # ORI
            data = self.fetch(); self.reg["A"] |= data; self._set_flag_szp(self.reg["A"]); self.flags["CY"]=0; return False, f"ORI #{data:02X}"
        if op == 0xEE: # XRI
            data = self.fetch(); self.reg["A"] ^= data; self._set_flag_szp(self.reg["A"]); self.flags["CY"]=0; return False, f"XRI #{data:02X}"
        if op == 0xE0: # RST / OUT/IN not covered here
            pass

        # OUT (D3) IN (DB)
        if op == 0xD3:
            port = self.fetch()
            self.output_log.append(("OUT", port, self.reg["A"]))
            return False, f"OUT #{port:02X}"
        if op == 0xDB:
            port = self.fetch()
            val = self.input_ports.get(port, 0)
            self.reg["A"] = val & 0xFF
            return False, f"IN #{port:02X}"

        # RLC (07), RRC (0F), CMA (2F)
        if op == 0x07:
            a = self.reg["A"]
            carry = (a>>7)&1
            a = ((a<<1)&0xFF) | carry
            self.reg["A"] = a; self.flags["CY"]=carry
            return False, "RLC"
        if op == 0x0F:
            a = self.reg["A"]
            carry = a&1
            a = (a>>1) | (carry<<7)
            self.reg["A"] = a; self.flags["CY"]=carry
            return False, "RRC"
        if op == 0x2F:
            self.reg["A"] = (~self.reg["A"]) & 0xFF
            return False, "CMA"

        # If unknown:
        return False, f"UNKNOWN OPCODE {op:02X}"

    def run(self, max_steps=100000):
        trace = []
        steps = 0
        while not self.halted and steps < max_steps:
            steps += 1
            halted, msg = self.step()
            trace.append((self.PC, msg))
            if halted: break
        return trace

#########################################
# assembler.py
# Very small assembler: labels, simple parsing, directives: ORG, DB, DW.
# Produces list of bytes. Supports a subset of mnemonics matching our emulator.

import re

# small opcode map for implemented instructions (subset)
OPC = {
    "NOP": [0x00],
    "HLT": [0x76],
    "RLC": [0x07], "RRC": [0x0F], "CMA": [0x2F],
    # MOV r1,r2  base 0x40 .. 0x7F
    # we'll compute MOV in code
    # MVI r, data (0x06 + r*0x08)
    # LXI
    "LXI B": [0x01], "LXI D": [0x11], "LXI H": [0x21], "LXI SP": [0x31],
    "LDA": [0x3A], "STA": [0x32], "LHLD": [0x2A], "SHLD": [0x22],
    "ADI": [0xC6], "SUI": [0xD6], "ANI": [0xE6], "ORI": [0xF6], "XRI": [0xEE],
    "JMP": [0xC3], "JNZ":[0xC2], "JZ":[0xCA], "JNC":[0xD2], "JC":[0xDA],
    "CALL":[0xCD], "RET":[0xC9],
    "PUSH B":[0xC5],"PUSH D":[0xD5],"PUSH H":[0xE5],"PUSH PSW":[0xF5],
    "POP B":[0xC1],"POP D":[0xD1],"POP H":[0xE1],"POP PSW":[0xF1],
    "IN": [0xDB], "OUT":[0xD3],
    "ADI": [0xC6], "CPI":[0xFE],
}

REG_ENC = {"B":0,"C":1,"D":2,"E":3,"H":4,"L":5,"M":6,"A":7}

def tokenize(line):
    # remove comments ; or //
    line = re.sub(r";.*","",line)
    line = re.sub(r"//.*","",line)
    return line.strip()

def assemble(text: str, base=0x0000):
    lines = text.splitlines()
    # First pass: labels
    addr = base
    labels = {}
    processed = []
    for raw in lines:
        s = tokenize(raw)
        if s=="":
            continue
        if ":" in s:
            lab, rest = s.split(":",1); labels[lab.strip()] = addr; s = rest.strip()
            if s=="":
                continue
        parts = s.split()
        mnemonic = parts[0].upper()
        # directives
        if mnemonic == "ORG":
            addr = int(parts[1],0); continue
        if mnemonic == "DB":
            # bytes
            args = " ".join(parts[1:]).split(",")
            for a in args:
                a=a.strip()
                if a.startswith("'") and a.endswith("'"):
                    b = ord(a[1:-1])
                else:
                    b = int(a,0)
                addr += 1
            processed.append(("DB", args))
            continue
        # estimate size for labels pass
        if mnemonic == "DB":
            pass
        elif mnemonic in ("LXI","LDA","STA","LHLD","SHLD","JMP","JNZ","JZ","JC","JNC","CALL"):
            if mnemonic in ("LXI",):
                addr += 3
            else:
                addr += 3
        elif mnemonic in ("MVI",):
            addr += 2
        elif mnemonic in ("ADI","SUI","ANI","ORI","XRI","CPI","IN","OUT"):
            addr += 2
        elif mnemonic in ("PUSH","POP","RET","RST","NOP","HLT","RLC","RRC","CMA"):
            addr += 1
        elif mnemonic == "MOV":
            addr += 1
        else:
            addr += 1
        processed.append((mnemonic, parts[1:] if len(parts)>1 else []))

    # Second pass: emit bytes
    addr = base
    out = []
    for item in processed:
        mnemonic = item[0]; args = item[1]
        if mnemonic == "DB":
            for a in args:
                a=a.strip()
                if a.startswith("'") and a.endswith("'"):
                    b = ord(a[1:-1])
                else:
                    b = int(a,0)
                out.append(b & 0xFF); addr+=1
            continue
        if mnemonic == "ORG":
            addr = int(args[0],0); continue

        if mnemonic == "MOV":
            # args like B,A
            a = "".join(args)
            dst,src = [x.strip().upper() for x in a.split(",")]
            opcode = 0x40 | (REG_ENC[dst]<<3) | REG_ENC[src]
            out.append(opcode); addr+=1; continue

        if mnemonic == "MVI":
            a = "".join(args)
            dst,imm = [x.strip().upper() for x in a.split(",")]
            opcode = 0x06 | (REG_ENC[dst]<<3)
            out.append(opcode); out.append(int(imm,0)&0xFF); addr+=2; continue

        if mnemonic in ("LXI",):
            rp = args[0].upper().strip(",")
            imm = int(args[1],0)
            if rp=="B": opc=0x01
            elif rp=="D": opc=0x11
            elif rp=="H": opc=0x21
            elif rp=="SP": opc=0x31
            else: opc=0x00
            out += [opc, imm & 0xFF, (imm>>8)&0xFF]; addr+=3; continue

        if mnemonic in ("LDA","STA","LHLD","SHLD","JMP","JNZ","JZ","JC","JNC","CALL"):
            label_or_addr = args[0]
            val = None
            if label_or_addr in labels:
                val = labels[label_or_addr]
            else:
                val = int(label_or_addr,0)
            baseopc = {"LDA":0x3A,"STA":0x32,"LHLD":0x2A,"SHLD":0x22,
                       "JMP":0xC3,"JNZ":0xC2,"JZ":0xCA,"JC":0xDA,"JNC":0xD2,"CALL":0xCD}[mnemonic]
            out += [baseopc, val & 0xFF, (val>>8)&0xFF]; addr+=3; continue

        if mnemonic in ("ADI","SUI","ANI","ORI","XRI","CPI","IN","OUT"):
            imm = args[0]
            if mnemonic in ("IN","OUT"):
                val = int(imm,0)
                opc = {"OUT":0xD3,"IN":0xDB}[mnemonic]
                out += [opc, val & 0xFF]; addr+=2; continue
            val = int(imm,0)
            opc = {"ADI":0xC6,"SUI":0xD6,"ANI":0xE6,"ORI":0xF6,"XRI":0xEE,"CPI":0xFE}[mnemonic]
            out += [opc, val & 0xFF]; addr+=2; continue

        if mnemonic in ("PUSH","POP"):
            arg = "".join(args).upper()
            m = {"PUSHB":0xC5,"PUSHD":0xD5,"PUSHH":0xE5,"PUSHP":0xF5,
                 "POPB":0xC1,"POPD":0xD1,"POPH":0xE1,"POPP":0xF1}
            key = mnemonic + arg
            # support PUSH B as "PUSH B"
            key = mnemonic + arg
            if key in {"PUSHB","PUSHD","PUSHH","PUSHP","POPB","POPD","POPH","POPP"}:
                opc = {"PUSHB":0xC5,"PUSHD":0xD5,"PUSHH":0xE5,"PUSHP":0xF5,
                       "POPB":0xC1,"POPD":0xD1,"POPH":0xE1,"POPP":0xF1}[key]
                out.append(opc); addr+=1; continue
            # alternate: PUSH PSW
            if arg=="PSW" and mnemonic=="PUSH":
                out.append(0xF5); addr+=1; continue
            if arg=="PSW" and mnemonic=="POP":
                out.append(0xF1); addr+=1; continue

        if mnemonic in ("RET","NOP","HLT","RLC","RRC","CMA"):
            out.append(OPC[mnemonic][0]); addr+=1; continue

        # default unknown: try opcode map
        if mnemonic in OPC:
            out += OPC[mnemonic]; addr += len(OPC[mnemonic]); continue

        # if unknown, ignore (could raise)
        raise ValueError(f"Unknown mnemonic '{mnemonic}'")

    return out

##########################################
@app.route("/8085", methods=["GET", "POST"])
def sim8085():
    result = None
    error = None

    # 8085 Register Set
    registers = {"A": 0, "B": 0, "C": 0, "D": 0, "E": 0, "H": 0, "L": 0}
    memory = [0] * 65536
    pc = 0  # Program Counter

    def execute_instruction(instr):
        parts = instr.strip().split()
        opcode = parts[0].upper()

        # MOV r1,r2
        if opcode == "MOV":
            dst, src = parts[1].split(",")
            registers[dst] = registers[src]

        # MVI r, data
        elif opcode == "MVI":
            dst, data = parts[1].split(",")
            registers[dst] = int(data, 16)

        # ADD r
        elif opcode == "ADD":
            r = parts[1]
            registers["A"] = (registers["A"] + registers[r]) & 0xFF

        # INR r
        elif opcode == "INR":
            r = parts[1]
            registers[r] = (registers[r] + 1) & 0xFF

        # HLT
        elif opcode == "HLT":
            return False

        else:
            raise Exception(f"Unsupported instruction: {instr}")

        return True

    if request.method == "POST":
        code = request.form.get("program")
        try:
            instructions = code.split("\n")

            for instr in instructions:
                instr = instr.strip()
                if instr == "":
                    continue
                if not execute_instruction(instr):
                    break

            result = {
                "registers": registers,
                "memory_sample": memory[:20]  # show small chunk
            }

        except Exception as e:
            error = str(e)

    return render_template("8085.html", result=result, error=error)

###################################################################################################
if __name__ == "__main__":
    app.run(debug=True)
