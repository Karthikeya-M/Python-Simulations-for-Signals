from flask import Flask, render_template, request
import numpy as np
import sympy as sp

app = Flask(__name__)
@app.route('/')
def homepage():
    return render_template('homepage.html')

@app.route("/DSP", methods=["GET", "POST"])
def DSP():
    result = None
    if request.method == "POST":
        try:
            # ----------- Get User Inputs -----------
            x = list(map(int, request.form["x_seq"].split()))
            y = list(map(int, request.form["y_seq"].split()))
            expr_input = request.form["system_expr"]

            x = np.array(x)
            y = np.array(y)

            # ----------- Convolution -----------
            lin_conv = np.convolve(x, y, mode="full")

            N = max(len(x), len(y))
            x_circ = np.pad(x, (0, N - len(x)), mode='constant')
            y_circ = np.pad(y, (0, N - len(y)), mode='constant')
            circ_conv = np.fft.ifft(np.fft.fft(x_circ) * np.fft.fft(y_circ)).real.round().astype(int)

            # ----------- System Expression -----------
            x_sym = sp.Symbol('x')
            system_expr = sp.sympify(expr_input)
            system_func = sp.lambdify(x_sym, system_expr, modules="numpy")

            # ----------- Linearity Check -----------
            # ----------- Linearity Check -----------
            n = sp.Symbol('n')  # use n as base variable
            system_expr = sp.sympify(expr_input.replace('^', '**'))  # allow ^ for power
            system_func = sp.lambdify(n, system_expr, modules="numpy")

            # Fixed test values for linearity check
            n1, n2, a1, a2 = 1, 2, 3, 4
            y1 = system_func(n1)
            y2 = system_func(n2)
            lhs = system_func(a1 * n1 + a2 * n2)
            rhs = a1 * y1 + a2 * y2
            linearity = "LINEAR " if np.isclose(lhs, rhs) else "NOT LINEAR "

            # ----------- Time Invariance Check -----------
            t0 = 2
            test_vals = np.arange(0, 6)
            passed = True
            for val in test_vals:
                # y[n - t0]
                shifted_input = system_func(val - t0)
                # shift output: y[n] shifted by t0
                shifted_output = system_func(val)
                if not np.isclose(shifted_input, shifted_output):
                    passed = False
                    break
            time_invariance = "TIME INVARIANT " if passed else "TIME VARYING "


            # ----------- BIBO Stability Check -----------
            bounded_input = np.linspace(-5, 5, 200)
            outputs = system_func(bounded_input)
            bibo = "BIBO STABLE " if np.all(np.abs(outputs) < 1e6) else "NOT BIBO STABLE "

            # ----------- Collect Results -----------
            result = {
                "lin_conv": lin_conv.tolist(),
                "circ_conv": circ_conv.tolist(),
                "system_expr": str(system_expr),
                "linearity": linearity,
                "time_invariance": time_invariance,
                "bibo": bibo
            }

        except Exception as e:
            result = {"error": str(e)}

    return render_template("DSP.html", result=result)


if __name__ == "__main__":
    app.run(debug=True)
