from flask import Flask, render_template, request
from lcapy import texpr, s
import traceback

app = Flask(__name__)
@app.route('/')
def index():
    return render_template('homepage.html')

@app.route('/laplace_transform', methods=['GET', 'POST'])
def laplace_transform():
    results = []
    error = None

    if request.method == 'POST':
        try:
            expr_str = request.form['signal_expr'].strip()
            if expr_str == '':
                raise ValueError("Input cannot be empty.")

            # Parse the input signal
            sig = texpr(expr_str)

            # Compute Laplace transform
            transformed = sig(s).simplify()

            results.append({
                'description': 'Original signal',
                'expr': str(sig),
                'latex': sig.latex()
            })

            results.append({
                'description': 'Laplace transform (symbolic)',
                'expr': str(transformed),
                'latex': transformed.latex()
            })

        except Exception as e:
            error = f"{e}\n{traceback.format_exc()}"

    return render_template('laplace_transform.html', results=results, error=error)


if __name__ == '__main__':
    app.run(debug=True)
