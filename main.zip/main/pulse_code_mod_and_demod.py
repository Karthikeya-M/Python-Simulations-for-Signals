from flask import Flask, render_template, request
import numpy as np
app = Flask(__name__)  # Since your HTML is in "main/"

@app.route('/')
def index():
    return render_template('homepage.html')


@app.route('/pulse_code_mod_and_demod', methods=['GET', 'POST'])
def pcm():
    result_text = ""
    error = None

    if request.method == 'POST':
        try:
            # Read form inputs (matching HTML form)
            fs = float(request.form.get('sampling_frequency', 100))   # Sampling frequency
            fb = float(request.form.get('message_frequency', 25))     # Message frequency
            A = float(request.form.get('amplitude', 1))               # Amplitude
            bits_per_sample = int(request.form.get('bits', 3))        # Bits per sample
            duration = float(request.form.get('duration', 2))         # Duration in seconds

            # Time vector
            t = np.arange(0, duration, 1/fs)
            
            # Message signal
            message = A * np.sin(2 * np.pi * fb * t)

            # Quantization
            q_levels = 2 ** bits_per_sample
            q_min = np.min(message)
            q_max = np.max(message)
            q_step = (q_max - q_min) / (q_levels - 1)
            quantized = np.round((message - q_min) / q_step) * q_step + q_min

            # Encoding
            bit_stream = []
            for q_val in quantized:
                idx = int((q_val - q_min) / q_step)
                bit_stream.append(format(idx, f'0{bits_per_sample}b'))

            # Decoding
            decoded = []
            for bits in bit_stream:
                idx = int(bits, 2)
                decoded.append(idx * q_step + q_min)
            decoded = np.array(decoded)

            # Prepare text output
            result_text = (
                f"Sampling Frequency: {fs} Hz\n"
                f"Message Frequency: {fb} Hz\n"
                f"Amplitude: {A}\n"
                f"Quantization Levels: {q_levels}\n"
                f"Bits per sample: {bits_per_sample}\n\n"
                f"First 20 Quantized Samples: {quantized[:20]}\n\n"
                f"First 20 Encoded Bits: {bit_stream[:20]}\n\n"
                f"First 20 Decoded Samples: {decoded[:20]}\n"
            )

        except Exception as e:
            error = str(e)

    return render_template('pulse_code_mod_and_demod.html',
                           result_text=result_text, error=error)


if __name__ == '__main__':
    app.run(debug=True)
