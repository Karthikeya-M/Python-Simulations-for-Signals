from flask import Flask, render_template, request
import sympy as sp
from sympy.integrals.transforms import inverse_fourier_transform as sympy_ifourier

app = Flask(__name__)
@app.route('/')
def index():
    return render_template('homepage.html')

# Symbols
omega, t = sp.symbols('omega t', real=True)

def residue_at(f, var, pole, mult):
    """Residue of f at 'pole' of multiplicity 'mult'."""
    s = mult
    res = (var - pole)**s * f
    for _ in range(s - 1):
        res = sp.diff(res, var)
    res = res.subs(var, pole) / sp.factorial(s - 1)
    return sp.simplify(res)

def inverse_fourier_residue(expr):
    """
    Compute inverse FT: f(t) = (1/(2π)) ∫ F(ω) e^{i ω t} dω
    using residues with correct half-plane selection:
      t > 0: close UHP  -> +i * sum Residues(UHP)
      t < 0: close LHP  -> -i * sum Residues(LHP)
    """
    expr = sp.simplify(expr)
    # If no omega in expr -> constant -> delta(t)
    if not expr.has(omega):
        return sp.simplify(expr * sp.DiracDelta(t))

    f = sp.simplify(expr * sp.exp(sp.I * omega * t))
    numer, denom = f.as_numer_denom()

    # Need a polynomial (or factorable) denominator in omega for residues
    # Try exact roots first; if none found, raise to trigger fallback.
    roots = sp.roots(denom, omega)
    if len(roots) == 0:
        raise ValueError("No algebraic poles found for residue method.")

    sum_upper = 0
    sum_lower = 0

    for p, mult in roots.items():
        # Determine which half-plane the pole is in
        im_p = sp.im(p)
        if im_p.is_positive:         # strictly in UHP
            sum_upper += residue_at(f, omega, p, mult)
        elif im_p.is_negative:       # strictly in LHP
            sum_lower += residue_at(f, omega, p, mult)
        else:
            # Real-axis pole: out of scope for basic residue inversion
            # Let SymPy handle via fallback if such poles exist.
            raise ValueError("Real-axis (or undetermined) pole encountered.")

    # Assemble piecewise via Heaviside(t)
    res = sp.I * sum_upper * sp.Heaviside(t) - sp.I * sum_lower * sp.Heaviside(-t)
    return sp.simplify(res)

def compute_inverse(expr_str):
    # Parse user input with 'omega' available
    expr = sp.sympify(expr_str, locals={"omega": omega})
    try:
        inv_res = inverse_fourier_residue(expr) / (2 * sp.pi)
        # Try to simplify to a nice closed form
        inv_res = sp.simplify(inv_res.rewrite(sp.Abs))
        return inv_res
    except Exception:
        # Fallback to SymPy's built-in inverse FT with the same convention
        return sp.simplify(sympy_ifourier(expr, omega, t))

@app.route("/inverse_fourier", methods=["GET", "POST"])
def inverse_fourier():
    result = None
    expr = ""
    latex = None

    if request.method == "POST":
        expr = request.form.get("expression", "").strip()
        if expr:
            try:
                res = compute_inverse(expr)
                result = sp.sstr(res)          # readable string
                latex = sp.latex(res)          # optional: pretty math (add MathJax if you like)
            except Exception as e:
                result = f"Error: {e}"

    return render_template("inverse_fourier.html", result=result, expr=expr, latex=latex)

if __name__ == "__main__":
    app.run(debug=True)
