from flask import Flask, render_template, request
import matplotlib.pyplot as plt
import mpld3
from lcapy import s
from matplotlib.figure import Figure
import numpy as np
import control  # for bode plots

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('homepage.html')

PLOT_DESCRIPTIONS = {
    "1": "Pole-Zero Plot: Shows poles (X) and zeros (O) in s-plane.",
    "2": "Bode Plot: Magnitude (dB) and phase vs frequency.",
    "3": "Nyquist Plot.",
    "4": "Nichols Plot."
}

# Safely get figure object from Lcapy return type
def get_figure(obj):
    while isinstance(obj, (list, tuple)):
        obj = obj[0]
    if hasattr(obj, "figure"):
        return obj.figure
    if isinstance(obj, Figure):
        return obj
    return plt.gcf()

# Convert Lcapy transfer function to python-control TF
def convert_lcapy_to_control(H):
    try:
        H_tf = H.tf()  # force rational TF
        num = [float(c) for c in H_tf.num.coeffs]
        den = [float(c) for c in H_tf.den.coeffs]
        return control.tf(num, den)
    except:
        raise ValueError(
            "⚠️ Could not convert TF to rational form.\n"
            "Enter rational TF like: s/(s+2) or (s+1)/(s*(s+2))"
        )

@app.route("/transfer", methods=["GET", "POST"])
def transfer_page():
    results = []
    error = None

    if request.method == "POST":
        tf_expr = request.form.get("tf_expr", "").strip()
        choices = request.form.getlist("plots")

        if not tf_expr:
            error = "Please enter a transfer function."
        else:
            for choice in choices:
                try:
                    # Handle Lcapy-based plots
                    if choice in ["1","3","4"]:
                        H = eval(tf_expr, {"s": s})

                        if choice == "1":
                            obj = H.plot()
                        elif choice == "3":
                            obj = H.nyquist_plot()
                        elif choice == "4":
                            obj = H.nichols_plot()

                        fig = get_figure(obj)

                    # Handle Bode via control library
                    elif choice == "2":
                        H_lcapy = eval(tf_expr, {"s": s})
                        Hc = convert_lcapy_to_control(H_lcapy)

                        omega = np.logspace(-2, 3, 800)
                        mag, phase, omega = control.bode(Hc, omega, dB=True, Plot=False)

                        fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(6,4))
                        ax1.semilogx(omega, 20*np.log10(mag))
                        ax1.set_ylabel("Magnitude (dB)")
                        ax1.set_title("Bode Plot")

                        ax2.semilogx(omega, phase * 180/np.pi)
                        ax2.set_ylabel("Phase (deg)")
                        ax2.set_xlabel("Frequency (rad/s)")
                        fig.tight_layout()

                    plot_html = mpld3.fig_to_html(fig)
                    results.append({
                        "description": PLOT_DESCRIPTIONS.get(choice, ""),
                        "plot_html": plot_html
                    })
                    plt.close(fig)

                except Exception as e:
                    results = []
                    error = f"Error: {str(e)}"
                    break

    return render_template("transfer.html", results=results, error=error)

if __name__ == "__main__":
    app.run(debug=True)
