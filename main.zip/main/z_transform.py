from flask import Flask, render_template, request
from lcapy import nexpr, z
import traceback

app = Flask(__name__)
@app.route('/')
def index():
    return render_template('homepage.html')

@app.route('/z_transform', methods=['GET', 'POST'])
def z_transform():
    results = []
    error = None

    if request.method == 'POST':
        try:
            user_input = request.form['signal_expr'].strip()
            if user_input == '':
                raise ValueError("Input cannot be empty.")

            expr = nexpr(user_input)
            z_transform = expr(z).simplify()

            results.append({
                'description': 'Original signal',
                'expr': str(expr),
                'latex': expr.latex()
            })

            results.append({
                'description': 'Z-transform (symbolic)',
                'expr': str(z_transform),
                'latex': z_transform.latex()
            })

        except Exception as e:
            error = f"{e}\n{traceback.format_exc()}"

    return render_template('z_transform.html', results=results, error=error)


if __name__ == '__main__':
    app.run(debug=True)
