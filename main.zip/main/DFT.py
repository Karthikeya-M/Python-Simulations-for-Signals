from flask import Flask, render_template, request
from lcapy import expr
import sympy as sp

app = Flask(__name__)

@app.route('/')
def homepage():
    return render_template("homepage.html")

@app.route("/DTFT", methods=["GET", "POST"])
def DTFT():
    result = None
    if request.method == "POST":
        try:
            # Get user input signal (symbolic)
            signal_expr = request.form["signal_expr"]

            # Parse symbolic expression using lcapy
            x = expr(signal_expr)

            # Compute the DTFT
            X = x.dtft()

            # Simplify result and get LaTeX
            simplified = sp.simplify(X.expr)
            latex_expr = sp.latex(simplified)

            result = {
                "input_signal": signal_expr,
                "dtft_expr": str(simplified),
                "latex": f"\\[{latex_expr}\\]"
            }

        except Exception as e:
            result = {"error": str(e)}

    return render_template("DTFT.html", result=result)

if __name__ == "__main__":
    app.run(debug=True)
