from flask import Flask, render_template, request
from lcapy import LTIFilter
from lcapy.ltifilter import Butterworth, Bessel

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def filters():
    result = ""
    if request.method == "POST":
        try:
            contin = int(request.form.get("contin"))  # 0=continuous, 1=discrete

            if contin == 1:  # discrete filters
                coeff_mode = int(request.form.get("coeff_mode"))  # 1=coeff, 0=ZPK
                if coeff_mode == 1:
                    num = request.form.get("num", "")
                    den = request.form.get("den", "")
                    b = tuple(map(float, num.strip().split()))
                    a = tuple(map(float, den.strip().split()))
                    fil = LTIFilter(b, a)
                else:
                    zeros = tuple(map(lambda z: complex(z), request.form.get("zeros", "").split()))
                    poles = tuple(map(lambda p: complex(p), request.form.get("poles", "").split()))
                    gain = float(request.form.get("gain", "1"))
                    fil = LTIFilter.from_ZPK(zeros, poles, gain)

                result += f"<pre>{fil.transfer_function()}</pre>"
                result += f"<pre>{fil.frequency_response()}</pre>"
                result += f"<pre>{fil.angular_frequency_response()}</pre>"
                result += f"<pre>{fil.group_delay()}</pre>"
                result += f"<pre>{fil.impulse_response()}</pre>"
                result += f"<pre>{fil.step_response()}</pre>"

            else:  # continuous filters
                filt_type = int(request.form.get("filt_type"))  # 0=Bessel, 1=Butterworth
                omega = float(request.form.get("omega", "1"))

                if filt_type == 1:
                    B = Butterworth(N=2, Wn=omega, btype="lowpass")
                else:
                    B = Bessel(N=2, Wn=omega, btype="lowpass")

                result += f"<pre>{B.transfer_function()}</pre>"
                result += f"<pre>{B.frequency_response()}</pre>"
                result += f"<pre>{B.group_delay()}</pre>"

        except Exception as e:
            result = f"<p style='color:red'>Error: {e}</p>"

    return render_template("filters.html", result=result)


if __name__ == "__main__":
    app.run(debug=True)
