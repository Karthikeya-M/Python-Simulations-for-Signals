#from circuit_models.diode import Diode
#import numpy as np

#def test_diode_zero_voltage():
#    d = Diode()
#    assert np.isclose(d.current(0), 0.0, atol=1e-12)
