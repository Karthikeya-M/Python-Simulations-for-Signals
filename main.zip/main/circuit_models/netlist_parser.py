from circuit_models.components.diode import Diode
from circuit_models.components.bjt import BJT
from circuit_models.components.mosfet import MOSFET
from circuit_models.components.Resistor import Resistor
from circuit_models.components.Capacitor import Capacitor
from circuit_models.components.inductor import Inductor
from circuit_models.components.zener_diode import ZenerDiode
from circuit_models.components.voltage_source import VoltageSource
from circuit_models.components.opamp import IdealOpAmp
from circuit_models.components.current_source import CurrentSource
from circuit_models.components.opamp_n import OpAmp


def parse_netlist(filepath):
    components = []

    with open(filepath, 'r') as file:
        for line in file:
            line = line.strip()
            if not line or line.startswith('*'):
                continue  # Skip comments or empty lines

            tokens = line.split()
            name = tokens[0].upper()

            # Identify component type by its name prefix
            if name.startswith('D'):
                anode, cathode = tokens[1], tokens[2]
                params = parse_params(tokens[3:])
                comp = Diode(name, cathode, anode, **params)

            elif name.startswith('Q'):  # BJT
                collector, base, emitter = tokens[1], tokens[2], tokens[3]
                bjt_type = tokens[4].upper() #PNP/NPN
                params = parse_params(tokens[4:])
                comp = BJT(name, collector, base, emitter, type=bjt_type, **params)

            elif name.startswith('M'):  # MOSFET
                drain, gate, source, body = tokens[1], tokens[2], tokens[3], tokens[4]
                mos_type = tokens[5].upper()  # NMOS/PMOS
                params = parse_params(tokens[6:])
                comp = MOSFET(name, drain, gate, source, body, type=mos_type, **params)

            elif name.startswith('R'):  # ✅ Handle Resistor
                node1, node2 = tokens[1], tokens[2]
                params = parse_params(tokens[3:])
                comp = Resistor(name, **params)

            elif name.startswith('C'):  # Capacitor
                n1, n2 = tokens[1], tokens[2]
                params = parse_params(tokens[3:])
                comp = Capacitor(name, n1, n2, **params)

            elif name.startswith("L"):
                n1, n2 = tokens[1], tokens[2]
                params = parse_params(tokens[3:])
                comp = Inductor(name, n1, n2, **params)

            elif name.startswith("ZD"):  # e.g. ZD1
                n_anode, n_cathode = tokens[1], tokens[2]
                params = parse_params(tokens[3:])
                comp = ZenerDiode(name, n_anode, n_cathode, **params)
            elif name.startswith("V"):  # Voltage source
                n_pos, n_neg = tokens[1], tokens[2]
                params = parse_params(tokens[3:])
                comp = VoltageSource(name, n_pos, n_neg, **params)

            elif name.startswith("OP"):
                v_plus, v_minus, v_out = tokens[1], tokens[2], tokens[3]
                params = parse_params(tokens[4:])
                comp = IdealOpAmp(name, v_plus, v_minus, v_out, **params)

            elif name.startswith('I'):  # Current source
                pos_node, neg_node = tokens[1], tokens[2]
                params = parse_params(tokens[3:])
                comp = CurrentSource(name, pos_node, neg_node, **params)

            elif name.startswith('U'):  # OpAmp, e.g., U1
                non_inverting, inverting, output = tokens[1], tokens[2], tokens[3]
                params = parse_params(tokens[4:])
                comp = OpAmp(name, non_inverting, inverting, output, **params)

            else:
                raise ValueError(f"Unsupported component: {name}")

            components.append(comp)

    return components

def parse_params(param_tokens):
    """Convert key=value tokens into a dictionary."""
    params = {}
    for token in param_tokens:
        if '=' in token:
            key, value = token.split('=')
            try:
                value = float(value)
            except ValueError:
                pass  # keep it as string
            params[key.lower()] = value
    return params
