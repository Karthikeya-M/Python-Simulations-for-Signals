from flask import Flask, render_template, request
import numpy as np
import matplotlib.pyplot as plt
import io, base64

app = Flask(__name__)
@app.route('/')
def index():
    return render_template('homepage.html')

@app.route('/qpsk', methods=['GET', 'POST'])
def qpsk():
    plot_htmls = []
    error = None

    if request.method == 'POST':
        try:
            num_symbols = int(request.form.get('num_symbols', 1000))
            noise_power = float(request.form.get('noise_power', 0.01))
            phase_noise_strength = float(request.form.get('phase_noise', 0.1))

            # QPSK symbols
            x_int = np.random.randint(0, 4, num_symbols)
            x_degrees = x_int * 360 / 4.0 + 45
            x_radians = x_degrees * np.pi / 180.0
            x_symbols = np.cos(x_radians) + 1j * np.sin(x_radians)

            fig, axs = plt.subplots(2, 2, figsize=(12, 6), constrained_layout=True)
            axs = axs.flatten()

            # 1. QPSK without noise
            axs[0].plot(np.real(x_symbols), np.imag(x_symbols), '.')
            axs[0].grid(True)
            axs[0].set_title("QPSK without noise")

            # 2. AWGN noise
            n = (np.random.randn(num_symbols) + 1j * np.random.randn(num_symbols)) / np.sqrt(2)
            r = x_symbols + n * np.sqrt(noise_power)
            axs[1].plot(np.real(r), np.imag(r), '.')
            axs[1].grid(True)
            axs[1].set_title("QPSK with AWGN noise")

            # 3. Phase noise
            phase_noise = np.random.randn(len(x_symbols)) * phase_noise_strength
            r1 = x_symbols * np.exp(1j * phase_noise)
            axs[2].plot(np.real(r1), np.imag(r1), '.')
            axs[2].grid(True)
            axs[2].set_title("QPSK with phase noise")

            # 4. Combination of both noises
            total_noise = r1 + r
            axs[3].plot(np.real(total_noise), np.imag(total_noise), '.')
            axs[3].grid(True)
            axs[3].set_title("QPSK with both phase noise and AWGN noise")

            # Convert figure to HTML base64
            buf = io.BytesIO()
            fig.savefig(buf, format="png", bbox_inches="tight")
            buf.seek(0)
            img = base64.b64encode(buf.read()).decode('utf-8')
            plt.close(fig)
            plot_htmls.append(f'<img src="data:image/png;base64,{img}">')

        except Exception as e:
            error = str(e)

    return render_template('qpsk.html', plots=plot_htmls, error=error)

if __name__ == '__main__':
    app.run(debug=True)
