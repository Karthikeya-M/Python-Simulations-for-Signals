import os, traceback
from flask import Flask, request, render_template, redirect, url_for, flash
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from circuit_models.netlist_parser import parse_netlist

app = Flask(__name__)
app.secret_key = "supersecretkey"

UPLOAD_FOLDER = "uploads"
PLOT_FOLDER = "static/plots"
ALLOWED_EXTS = {"cir", "sp", "txt"}

os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(PLOT_FOLDER, exist_ok=True)

# session-like storage
SESSION = {"components": [], "file": None}

def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTS

# ----------------- ROUTES -------------------

@app.route("/")
def index():
    """Homepage"""
    return render_template("homepage.html")

@app.route("/netlist", methods=["GET", "POST"])
def netlist_home():
    """Upload and parse netlist"""
    if request.method == "POST":
        if "netlist" not in request.files:
            flash("No file uploaded", "error")
            return redirect(request.url)

        file = request.files["netlist"]
        if file.filename == "":
            flash("No file selected", "error")
            return redirect(request.url)

        if file and allowed_file(file.filename):
            filepath = os.path.join(UPLOAD_FOLDER, file.filename)
            file.save(filepath)

            try:
                comps = parse_netlist(filepath)
                SESSION["components"] = comps
                SESSION["file"] = file.filename
                return redirect(url_for("netlist_home"))
            except Exception as e:
                tb = traceback.format_exc()
                flash(f"Error parsing netlist: {e}\n{tb}", "error")
                return redirect(request.url)

        flash("Invalid file format", "error")
        return redirect(request.url)

    return render_template(
        "netlist.html",
        components=SESSION["components"],
        file_token=SESSION["file"],
        plot_image=None,
        selected=None,
    )

@app.route("/netlist/plot/<int:idx>")
def netlist_plot(idx):
    """Plot I-V curve of a component"""
    try:
        comp = SESSION["components"][idx]
    except IndexError:
        flash("Component not found", "error")
        return redirect(url_for("netlist_home"))

    if not hasattr(comp, "plot_iv"):
        flash(f"{comp.name} does not support plotting", "warning")
        return redirect(url_for("netlist_home"))

    try:
        plot_file = f"{comp.name}.png"
        plot_path = os.path.join(PLOT_FOLDER, plot_file)
        plt.clf()
        comp.plot_iv()
        plt.savefig(plot_path)

        return render_template(
            "netlist.html",
            components=SESSION["components"],
            file_token=SESSION["file"],
            plot_image=f"plots/{plot_file}",
            selected=comp.name,
        )
    except Exception as e:
        tb = traceback.format_exc()
        flash(f"Error plotting: {e}\n{tb}", "error")
        return redirect(url_for("netlist_home"))

if __name__ == "__main__":
    app.run(debug=True)
