from flask import Flask, render_template, request, send_file
import cv2
import numpy as np
import os
from io import BytesIO

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('homepage.html')


UPLOAD_FOLDER = "uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Default image path
DEFAULT_IMAGE = os.path.join(UPLOAD_FOLDER, "1.webp")

def load_image():
    img = cv2.imread(DEFAULT_IMAGE)
    if img is None:
        raise FileNotFoundError("Upload '1.webp' into uploads/ folder.")
    img = cv2.copyMakeBorder(img, 50, 50, 50, 50, cv2.BORDER_CONSTANT, value=(0, 0, 0))
    return cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

@app.route("/image_processing", methods=["GET", "POST"])
def image_processing():
    result_img = None
    operation = None

    if request.method == "POST":
        operation = request.form.get("operation")
        image_rgb = load_image()
        height, width = image_rgb.shape[:2]

        if operation == "scale":
            sx_zoom = float(request.form.get("sx_zoom", 1.5))
            sy_zoom = float(request.form.get("sy_zoom", 1.5))
            zoomed = cv2.resize(image_rgb, (int(width * sx_zoom), int(height * sy_zoom)), interpolation=cv2.INTER_CUBIC)
            result_img = zoomed

        elif operation == "rotate":
            angle = float(request.form.get("angle", 45))
            scale = float(request.form.get("scale", 1.0))
            center = (width // 2, height // 2)
            matrix = cv2.getRotationMatrix2D(center, angle, scale)
            rotated = cv2.warpAffine(image_rgb, matrix, (width, height))
            result_img = rotated

        elif operation == "translate":
            tx = int(request.form.get("tx", 50))
            ty = int(request.form.get("ty", 30))
            matrix = np.array([[1, 0, tx], [0, 1, ty]], dtype=np.float32)
            translated = cv2.warpAffine(image_rgb, matrix, (width, height))
            result_img = translated

        elif operation == "shear":
            shearX = float(request.form.get("shearX", 0.2))
            shearY = float(request.form.get("shearY", 0.2))
            matrix = np.array([[1, shearX, 0], [0, 1, shearY]], dtype=np.float32)
            sheared = cv2.warpAffine(image_rgb, matrix, (width, height))
            result_img = sheared

        elif operation == "normalize":
            b, g, r = cv2.split(image_rgb)
            b = cv2.normalize(b.astype('float'), None, 0, 1, cv2.NORM_MINMAX)
            g = cv2.normalize(g.astype('float'), None, 0, 1, cv2.NORM_MINMAX)
            r = cv2.normalize(r.astype('float'), None, 0, 1, cv2.NORM_MINMAX)
            normalized = cv2.merge((b, g, r))
            result_img = (normalized * 255).astype(np.uint8)

        elif operation == "edges":
            t1 = int(request.form.get("t1", 100))
            t2 = int(request.form.get("t2", 200))
            edges = cv2.Canny(image_rgb, t1, t2)
            result_img = cv2.cvtColor(edges, cv2.COLOR_GRAY2RGB)

        elif operation == "blur":
            blurred = cv2.GaussianBlur(image_rgb, (3, 3), 0)
            result_img = blurred

        elif operation == "morphology":
            gray = cv2.cvtColor(image_rgb, cv2.COLOR_RGB2GRAY)
            kernel = np.ones((3, 3), np.uint8)
            dilated = cv2.dilate(gray, kernel, iterations=2)
            result_img = cv2.cvtColor(dilated, cv2.COLOR_GRAY2RGB)

        if result_img is not None:
            # ✅ Return processed image directly (no matplotlib, no white space)
            _, buffer = cv2.imencode(".png", cv2.cvtColor(result_img, cv2.COLOR_RGB2BGR))
            return send_file(BytesIO(buffer), mimetype="image/png")

    return render_template("image_processing.html")
    

if __name__ == "__main__":
    app.run(debug=True)
