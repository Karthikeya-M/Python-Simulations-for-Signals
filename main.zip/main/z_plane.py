from flask import Flask, render_template, request
import matplotlib.pyplot as plt
import matplotlib.patches as patches
import numpy as np
import mpld3

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('homepage.html')


def compute_roc(poles, signal_type):
    pole_magnitudes = np.abs(poles)

    if signal_type == "causal":
        roc = f"|z| > {np.max(pole_magnitudes):.3f}"
        stable = np.max(pole_magnitudes) < 1
    else:  # anti-causal
        roc = f"|z| < {np.min(pole_magnitudes):.3f}"
        stable = np.min(pole_magnitudes) > 1

    stability_msg = "System is Stable ✅" if stable else "System is Unstable ❌"
    return roc, stability_msg


def z_plane(b, a, signal_type):
    zeros = np.roots(b)
    poles = np.roots(a)

    # Compute ROC & stability
    roc, stability_msg = compute_roc(poles, signal_type)

    fig, ax = plt.subplots(figsize=(6, 6))

    # Plot unit circle
    unit_circle = patches.Circle((0, 0), radius=1, fill=False,
                                 edgecolor='black', linestyle='--', alpha=0.6)
    ax.add_patch(unit_circle)

    # Plot poles & zeros
    ax.plot(zeros.real, zeros.imag, 'go', markersize=10, label='Zeros')
    ax.plot(poles.real, poles.imag, 'rx', markersize=12, label='Poles')

    # Axes format
    ax.axvline(0, color='gray', linewidth=0.5)
    ax.axhline(0, color='gray', linewidth=0.5)
    ax.grid(True, linestyle=':', alpha=0.6)
    ax.set_aspect('equal')

    r = max(2, np.max(np.abs(np.concatenate((zeros, poles)))), 1.5)
    ax.set_xlim([-r, r])
    ax.set_ylim([-r, r])

    plt.xlabel('Real Part')
    plt.ylabel('Imaginary Part')
    plt.title('Z-Transform Pole-Zero Plot')
    plt.legend()

    plot_html = mpld3.fig_to_html(fig)
    plt.close(fig)

    return plot_html, roc, stability_msg


@app.route('/z_plane1', methods=['GET', 'POST'])
def z_plane1():
    plot_html, roc, stability_msg = None, "", ""

    if request.method == 'POST':
        numerator = request.form['numerator']
        denominator = request.form['denominator']
        signal_type = request.form['signal_type']

        b = [float(x) for x in numerator.replace(',', ' ').split()]
        a = [float(x) for x in denominator.replace(',', ' ').split()]

        plot_html, roc, stability_msg = z_plane(b, a, signal_type)

    return render_template("z_plane1.html",
                           plot_html=plot_html,
                           roc=roc,
                           stability_msg=stability_msg)


if __name__ == "__main__":
    app.run(debug=True)
