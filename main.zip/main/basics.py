from flask import Flask, render_template
import numpy as np
import matplotlib.pyplot as plt
import mpld3
from scipy import signal, ndimage

app = Flask(__name__)

@app.route('/')
def homepage():
    return render_template("homepage.html")  # points to homepage

@app.route('/plots')
def show_plots():
    plots = []

    T = 1
    k = 0.25
    A = 1
    border = np.pi

    def plot_to_html(fig):
        return mpld3.fig_to_html(fig)

    def draw_plot1(x_, y_, xlabel, ylabel, title=""):
        fig, ax = plt.subplots()
        ax.stem(x_, y_)
        ax.set_xlabel(xlabel)
        ax.set_ylabel(ylabel)
        ax.set_title(title)
        ax.grid()
        html = plot_to_html(fig)
        plt.close(fig)  # Close figure to avoid memory leaks
        return html

    def c_sum(array, bound):
        csum = []
        s = 0
        for i in range(len(array)):
            if i < bound:
                s += array[i]
            else:
                s = 0
            csum.append(s)
        return csum

    impulse = signal.unit_impulse(100, [0])
    m = np.arange(0, 100, 1)

    # A: simple impulse and step responses
    plots.append(draw_plot1(m, (1 / 2) * (ndimage.shift(impulse, 0, cval=0)[m] + ndimage.shift(impulse, 1, cval=0)[m]),
            'n','Response','Impulse Response'))
    plots.append(draw_plot1(m, np.cumsum((1 / 2) * (ndimage.shift(impulse, 0, cval=0)[m] + ndimage.shift(impulse, 1, cval=0)[m])),
            'n','Response','Step Response'))

    # B: another impulse difference
    plots.append(draw_plot1(m, (ndimage.shift(impulse, -1, cval=0)[m] - ndimage.shift(impulse, 0, cval=0)[m]),
            'n','Response','Impulse Response'))
    plots.append(draw_plot1(m, np.cumsum(ndimage.shift(impulse, -1, cval=0)[m] - ndimage.shift(impulse, 0, cval=0)[m]),
            'n','Response','Step Response'))

    # C: c_sum variations
    for bound in [5, 15, 20]:
        plots.append(draw_plot1(m, c_sum((1 / 2) * (ndimage.shift(impulse, 0, cval=0)[m] + ndimage.shift(impulse, 1, cval=0)[m]), bound),
                               'n', 'Response', f'A Step Response for m_u = {bound}'))
        plots.append(draw_plot1(m, c_sum((ndimage.shift(impulse, -1, cval=0)[m] - ndimage.shift(impulse, 0, cval=0)[m]), bound),
                               'n', 'Response', f'B Step Response for m_u = {bound}'))
        plots.append(draw_plot1(m, c_sum((ndimage.shift(impulse, -1, cval=0)[m] - 
                                          2*ndimage.shift(impulse, 0, cval=0)[m] + 
                                          ndimage.shift(impulse, 1, cval=0)[m]), bound),
                               'n', 'Response', f'C Step Response for m_u = {bound}'))

    return render_template("plots.html", plots=plots)

if __name__ == '__main__':
    app.run(debug=True)
